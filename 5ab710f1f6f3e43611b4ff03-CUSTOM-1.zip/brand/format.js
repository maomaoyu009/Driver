!
function(t) {
    "function" != typeof t.matches && (t.matches = t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector ||
    function(t) {
        for (var e = (this.document || this.ownerDocument).querySelectorAll(t), r = 0; e[r] && e[r] !== this;)++r;
        return Boolean(e[r])
    }),
    "function" != typeof t.closest && (t.closest = function(t) {
        for (var e = this; e && 1 === e.nodeType;) {
            if (e.matches(t)) return e;
            e = e.parentNode
        }
        return null
    })
} (window.Element.prototype),
window.matchMedia || (window.matchMedia = function() {
    "use strict";
    var t = window.styleMedia || window.media;
    if (!t) {
        var e, r = document.createElement("style"),
        n = document.getElementsByTagName("script")[0];
        r.type = "text/css",
        r.id = "matchmediajs-test",
        n ? n.parentNode.insertBefore(r, n) : document.head.appendChild(r),
        e = "getComputedStyle" in window && window.getComputedStyle(r, null) || r.currentStyle,
        t = {
            matchMedium: function(t) {
                var n = "@media " + t + "{ #matchmediajs-test { width: 1px; } }";
                return r.styleSheet ? r.styleSheet.cssText = n: r.textContent = n,
                "1px" === e.width
            }
        }
    }
    return function(e) {
        return {
            matches: t.matchMedium(e || "all"),
            media: e || "all"
        }
    }
} ()),
function(t, e) {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? exports.Handlebars = e() : t.Handlebars = e()
} (this,
function() {
    return function(t) {
        var e = {};
        function r(n) {
            if (e[n]) return e[n].exports;
            var a = e[n] = {
                exports: {},
                id: n,
                loaded: !1
            };
            return t[n].call(a.exports, a, a.exports, r),
            a.loaded = !0,
            a.exports
        }
        return r.m = t,
        r.c = e,
        r.p = "",
        r(0)
    } ([function(t, e, r) {
        "use strict";
        var n = r(1).
    default,
        a = r(2).
    default;
        e.__esModule = !0;
        var o = n(r(3)),
        i = a(r(20)),
        u = a(r(5)),
        s = n(r(4)),
        l = n(r(21)),
        c = a(r(33));
        function f() {
            var t = new o.HandlebarsEnvironment;
            return s.extend(t, o),
            t.SafeString = i.
        default,
            t.Exception = u.
        default,
            t.Utils = s,
            t.escapeExpression = s.escapeExpression,
            t.VM = l,
            t.template = function(e) {
                return l.template(e, t)
            },
            t
        }
        var d = f();
        d.create = f,
        c.
    default(d),
        d.
    default = d,
        e.
    default = d,
        t.exports = e.
    default
    },
    function(t, e) {
        "use strict";
        e.
    default = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e.
        default = t,
            e
        },
        e.__esModule = !0
    },
    function(t, e) {
        "use strict";
        e.
    default = function(t) {
            return t && t.__esModule ? t: {
            default:
                t
            }
        },
        e.__esModule = !0
    },
    function(t, e, r) {
        "use strict";
        var n = r(2).
    default;
        e.__esModule = !0,
        e.HandlebarsEnvironment = l;
        var a = r(4),
        o = n(r(5)),
        i = r(9),
        u = r(17),
        s = n(r(19));
        e.VERSION = "4.1.2";
        e.COMPILER_REVISION = 7;
        e.REVISION_CHANGES = {
            1 : "<= 1.0.rc.2",
            2 : "== 1.0.0-rc.3",
            3 : "== 1.0.0-rc.4",
            4 : "== 1.x.x",
            5 : "== 2.0.0-alpha.x",
            6 : ">= 2.0.0-beta.1",
            7 : ">= 4.0.0"
        };
        function l(t, e, r) {
            this.helpers = t || {},
            this.partials = e || {},
            this.decorators = r || {},
            i.registerDefaultHelpers(this),
            u.registerDefaultDecorators(this)
        }
        l.prototype = {
            constructor: l,
            logger: s.
        default,
            log: s.
        default.log,
            registerHelper: function(t, e) {
                if ("[object Object]" === a.toString.call(t)) {
                    if (e) throw new o.
                default("Arg not supported with multiple helpers");
                    a.extend(this.helpers, t)
                } else this.helpers[t] = e
            },
            unregisterHelper: function(t) {
                delete this.helpers[t]
            },
            registerPartial: function(t, e) {
                if ("[object Object]" === a.toString.call(t)) a.extend(this.partials, t);
                else {
                    if (void 0 === e) throw new o.
                default('Attempting to register a partial called "' + t + '" as undefined');
                    this.partials[t] = e
                }
            },
            unregisterPartial: function(t) {
                delete this.partials[t]
            },
            registerDecorator: function(t, e) {
                if ("[object Object]" === a.toString.call(t)) {
                    if (e) throw new o.
                default("Arg not supported with multiple decorators");
                    a.extend(this.decorators, t)
                } else this.decorators[t] = e
            },
            unregisterDecorator: function(t) {
                delete this.decorators[t]
            }
        };
        var c = s.
    default.log;
        e.log = c,
        e.createFrame = a.createFrame,
        e.logger = s.
    default
    },
    function(t, e) {
        "use strict";
        e.__esModule = !0,
        e.extend = i,
        e.indexOf = function(t, e) {
            for (var r = 0,
            n = t.length; r < n; r++) if (t[r] === e) return r;
            return - 1
        },
        e.escapeExpression = function(t) {
            if ("string" != typeof t) {
                if (t && t.toHTML) return t.toHTML();
                if (null == t) return "";
                if (!t) return t + "";
                t = "" + t
            }
            if (!a.test(t)) return t;
            return t.replace(n, o)
        },
        e.isEmpty = function(t) {
            return ! t && 0 !== t || !(!l(t) || 0 !== t.length)
        },
        e.createFrame = function(t) {
            var e = i({},
            t);
            return e._parent = t,
            e
        },
        e.blockParams = function(t, e) {
            return t.path = e,
            t
        },
        e.appendContextPath = function(t, e) {
            return (t ? t + ".": "") + e
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;",
            "=": "&#x3D;"
        },
        n = /[&<>"'`=]/g,
        a = /[&<>"'`=]/;
        function o(t) {
            return r[t]
        }
        function i(t) {
            for (var e = 1; e < arguments.length; e++) for (var r in arguments[e]) Object.prototype.hasOwnProperty.call(arguments[e], r) && (t[r] = arguments[e][r]);
            return t
        }
        var u = Object.prototype.toString;
        e.toString = u;
        var s = function(t) {
            return "function" == typeof t
        };
        s(/x/) && (e.isFunction = s = function(t) {
            return "function" == typeof t && "[object Function]" === u.call(t)
        }),
        e.isFunction = s;
        var l = Array.isArray ||
        function(t) {
            return ! (!t || "object" != typeof t) && "[object Array]" === u.call(t)
        };
        e.isArray = l
    },
    function(t, e, r) {
        "use strict";
        var n = r(6).
    default;
        e.__esModule = !0;
        var a = ["description", "fileName", "lineNumber", "message", "name", "number", "stack"];
        function o(t, e) {
            var r = e && e.loc,
            i = void 0,
            u = void 0;
            r && (t += " - " + (i = r.start.line) + ":" + (u = r.start.column));
            for (var s = Error.prototype.constructor.call(this, t), l = 0; l < a.length; l++) this[a[l]] = s[a[l]];
            Error.captureStackTrace && Error.captureStackTrace(this, o);
            try {
                r && (this.lineNumber = i, n ? Object.defineProperty(this, "column", {
                    value: u,
                    enumerable: !0
                }) : this.column = u)
            } catch(t) {}
        }
        o.prototype = new Error,
        e.
    default = o,
        t.exports = e.
    default
    },
    function(t, e, r) {
        t.exports = {
        default:
            r(7),
            __esModule: !0
        }
    },
    function(t, e, r) {
        var n = r(8);
        t.exports = function(t, e, r) {
            return n.setDesc(t, e, r)
        }
    },
    function(t, e) {
        var r = Object;
        t.exports = {
            create: r.create,
            getProto: r.getPrototypeOf,
            isEnum: {}.propertyIsEnumerable,
            getDesc: r.getOwnPropertyDescriptor,
            setDesc: r.defineProperty,
            setDescs: r.defineProperties,
            getKeys: r.keys,
            getNames: r.getOwnPropertyNames,
            getSymbols: r.getOwnPropertySymbols,
            each: [].forEach
        }
    },
    function(t, e, r) {
        "use strict";
        var n = r(2).
    default;
        e.__esModule = !0,
        e.registerDefaultHelpers = function(t) {
            a.
        default(t),
            o.
        default(t),
            i.
        default(t),
            u.
        default(t),
            s.
        default(t),
            l.
        default(t),
            c.
        default(t)
        };
        var a = n(r(10)),
        o = n(r(11)),
        i = n(r(12)),
        u = n(r(13)),
        s = n(r(14)),
        l = n(r(15)),
        c = n(r(16))
    },
    function(t, e, r) {
        "use strict";
        e.__esModule = !0;
        var n = r(4);
        e.
    default = function(t) {
            t.registerHelper("blockHelperMissing",
            function(e, r) {
                var a = r.inverse,
                o = r.fn;
                if (!0 === e) return o(this);
                if (!1 === e || null == e) return a(this);
                if (n.isArray(e)) return e.length > 0 ? (r.ids && (r.ids = [r.name]), t.helpers.each(e, r)) : a(this);
                if (r.data && r.ids) {
                    var i = n.createFrame(r.data);
                    i.contextPath = n.appendContextPath(r.data.contextPath, r.name),
                    r = {
                        data: i
                    }
                }
                return o(e, r)
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        var n = r(2).
    default;
        e.__esModule = !0;
        var a = r(4),
        o = n(r(5));
        e.
    default = function(t) {
            t.registerHelper("each",
            function(t, e) {
                if (!e) throw new o.
            default("Must pass iterator to #each");
                var r = e.fn,
                n = e.inverse,
                i = 0,
                u = "",
                s = void 0,
                l = void 0;
                function c(e, n, o) {
                    s && (s.key = e, s.index = n, s.first = 0 === n, s.last = !!o, l && (s.contextPath = l + e)),
                    u += r(t[e], {
                        data: s,
                        blockParams: a.blockParams([t[e], e], [l + e, null])
                    })
                }
                if (e.data && e.ids && (l = a.appendContextPath(e.data.contextPath, e.ids[0]) + "."), a.isFunction(t) && (t = t.call(this)), e.data && (s = a.createFrame(e.data)), t && "object" == typeof t) if (a.isArray(t)) for (var f = t.length; i < f; i++) i in t && c(i, i, i === t.length - 1);
                else {
                    var d = void 0;
                    for (var p in t) t.hasOwnProperty(p) && (void 0 !== d && c(d, i - 1), d = p, i++);
                    void 0 !== d && c(d, i - 1, !0)
                }
                return 0 === i && (u = n(this)),
                u
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        var n = r(2).
    default;
        e.__esModule = !0;
        var a = n(r(5));
        e.
    default = function(t) {
            t.registerHelper("helperMissing",
            function() {
                if (1 !== arguments.length) throw new a.
            default('Missing helper: "' + arguments[arguments.length - 1].name + '"')
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        e.__esModule = !0;
        var n = r(4);
        e.
    default = function(t) {
            t.registerHelper("if",
            function(t, e) {
                return n.isFunction(t) && (t = t.call(this)),
                !e.hash.includeZero && !t || n.isEmpty(t) ? e.inverse(this) : e.fn(this)
            }),
            t.registerHelper("unless",
            function(e, r) {
                return t.helpers.
                if.call(this, e, {
                    fn: r.inverse,
                    inverse: r.fn,
                    hash: r.hash
                })
            })
        },
        t.exports = e.
    default
    },
    function(t, e) {
        "use strict";
        e.__esModule = !0,
        e.
    default = function(t) {
            t.registerHelper("log",
            function() {
                for (var e = [void 0], r = arguments[arguments.length - 1], n = 0; n < arguments.length - 1; n++) e.push(arguments[n]);
                var a = 1;
                null != r.hash.level ? a = r.hash.level: r.data && null != r.data.level && (a = r.data.level),
                e[0] = a,
                t.log.apply(t, e)
            })
        },
        t.exports = e.
    default
    },
    function(t, e) {
        "use strict";
        e.__esModule = !0,
        e.
    default = function(t) {
            t.registerHelper("lookup",
            function(t, e) {
                return t ? "constructor" !== e || t.propertyIsEnumerable(e) ? t[e] : void 0 : t
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        e.__esModule = !0;
        var n = r(4);
        e.
    default = function(t) {
            t.registerHelper("with",
            function(t, e) {
                n.isFunction(t) && (t = t.call(this));
                var r = e.fn;
                if (n.isEmpty(t)) return e.inverse(this);
                var a = e.data;
                return e.data && e.ids && ((a = n.createFrame(e.data)).contextPath = n.appendContextPath(e.data.contextPath, e.ids[0])),
                r(t, {
                    data: a,
                    blockParams: n.blockParams([t], [a && a.contextPath])
                })
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        var n = r(2).
    default;
        e.__esModule = !0,
        e.registerDefaultDecorators = function(t) {
            a.
        default(t)
        };
        var a = n(r(18))
    },
    function(t, e, r) {
        "use strict";
        e.__esModule = !0;
        var n = r(4);
        e.
    default = function(t) {
            t.registerDecorator("inline",
            function(t, e, r, a) {
                var o = t;
                return e.partials || (e.partials = {},
                o = function(a, o) {
                    var i = r.partials;
                    r.partials = n.extend({},
                    i, e.partials);
                    var u = t(a, o);
                    return r.partials = i,
                    u
                }),
                e.partials[a.args[0]] = a.fn,
                o
            })
        },
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        e.__esModule = !0;
        var n = r(4),
        a = {
            methodMap: ["debug", "info", "warn", "error"],
            level: "info",
            lookupLevel: function(t) {
                if ("string" == typeof t) {
                    var e = n.indexOf(a.methodMap, t.toLowerCase());
                    t = e >= 0 ? e: parseInt(t, 10)
                }
                return t
            },
            log: function(t) {
                if (t = a.lookupLevel(t), "undefined" != typeof console && a.lookupLevel(a.level) <= t) {
                    var e = a.methodMap[t];
                    console[e] || (e = "log");
                    for (var r = arguments.length,
                    n = Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) n[o - 1] = arguments[o];
                    console[e].apply(console, n)
                }
            }
        };
        e.
    default = a,
        t.exports = e.
    default
    },
    function(t, e) {
        "use strict";
        function r(t) {
            this.string = t
        }
        e.__esModule = !0,
        r.prototype.toString = r.prototype.toHTML = function() {
            return "" + this.string
        },
        e.
    default = r,
        t.exports = e.
    default
    },
    function(t, e, r) {
        "use strict";
        var n = r(22).
    default,
        a = r(1).
    default,
        o = r(2).
    default;
        e.__esModule = !0,
        e.checkRevision = function(t) {
            var e = t && t[0] || 1,
            r = s.COMPILER_REVISION;
            if (e !== r) {
                if (e < r) {
                    var n = s.REVISION_CHANGES[r],
                    a = s.REVISION_CHANGES[e];
                    throw new u.
                default("Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version (" + n + ") or downgrade your runtime to an older version (" + a + ").")
                }
                throw new u.
            default("Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version (" + t[1] + ").")
            }
        },
        e.template = function(t, e) {
            if (!e) throw new u.
        default("No environment passed to template");
            if (!t || !t.main) throw new u.
        default("Unknown template object: " + typeof t);
            t.main.decorator = t.main_d,
            e.VM.checkRevision(t.compiler);
            var r = {
                strict: function(t, e) {
                    if (! (e in t)) throw new u.
                default('"' + e + '" not defined in ' + t);
                    return t[e]
                },
                lookup: function(t, e) {
                    for (var r = t.length,
                    n = 0; n < r; n++) if (t[n] && null != t[n][e]) return t[n][e]
                },
                lambda: function(t, e) {
                    return "function" == typeof t ? t.call(e) : t
                },
                escapeExpression: i.escapeExpression,
                invokePartial: function(r, n, a) {
                    a.hash && (n = i.extend({},
                    n, a.hash), a.ids && (a.ids[0] = !0));
                    r = e.VM.resolvePartial.call(this, r, n, a);
                    var o = e.VM.invokePartial.call(this, r, n, a);
                    null == o && e.compile && (a.partials[a.name] = e.compile(r, t.compilerOptions, e), o = a.partials[a.name](n, a));
                    if (null != o) {
                        if (a.indent) {
                            for (var s = o.split("\n"), l = 0, c = s.length; l < c && (s[l] || l + 1 !== c); l++) s[l] = a.indent + s[l];
                            o = s.join("\n")
                        }
                        return o
                    }
                    throw new u.
                default("The partial " + a.name + " could not be compiled when running in runtime-only mode")
                },
                fn: function(e) {
                    var r = t[e];
                    return r.decorator = t[e + "_d"],
                    r
                },
                programs: [],
                program: function(t, e, r, n, a) {
                    var o = this.programs[t],
                    i = this.fn(t);
                    return e || a || n || r ? o = l(this, t, i, e, r, n, a) : o || (o = this.programs[t] = l(this, t, i)),
                    o
                },
                data: function(t, e) {
                    for (; t && e--;) t = t._parent;
                    return t
                },
                merge: function(t, e) {
                    var r = t || e;
                    return t && e && t !== e && (r = i.extend({},
                    e, t)),
                    r
                },
                nullContext: n({}),
                noop: e.VM.noop,
                compilerInfo: t.compiler
            };
            function a(e) {
                var n = arguments.length <= 1 || void 0 === arguments[1] ? {}: arguments[1],
                o = n.data;
                a._setup(n),
                !n.partial && t.useData && (o = function(t, e) {
                    e && "root" in e || ((e = e ? s.createFrame(e) : {}).root = t);
                    return e
                } (e, o));
                var i = void 0,
                u = t.useBlockParams ? [] : void 0;
                function l(e) {
                    return "" + t.main(r, e, r.helpers, r.partials, o, u, i)
                }
                return t.useDepths && (i = n.depths ? e != n.depths[0] ? [e].concat(n.depths) : n.depths: [e]),
                (l = f(t.main, l, r, n.depths || [], o, u))(e, n)
            }
            return a.isTop = !0,
            a._setup = function(n) {
                n.partial ? (r.helpers = n.helpers, r.partials = n.partials, r.decorators = n.decorators) : (r.helpers = r.merge(n.helpers, e.helpers), t.usePartial && (r.partials = r.merge(n.partials, e.partials)), (t.usePartial || t.useDecorators) && (r.decorators = r.merge(n.decorators, e.decorators)))
            },
            a._child = function(e, n, a, o) {
                if (t.useBlockParams && !a) throw new u.
            default("must pass block params");
                if (t.useDepths && !o) throw new u.
            default("must pass parent depths");
                return l(r, e, t[e], n, 0, a, o)
            },
            a
        },
        e.wrapProgram = l,
        e.resolvePartial = function(t, e, r) {
            t ? t.call || r.name || (r.name = t, t = r.partials[t]) : t = "@partial-block" === r.name ? r.data["partial-block"] : r.partials[r.name];
            return t
        },
        e.invokePartial = function(t, e, r) {
            var n = r.data && r.data["partial-block"];
            r.partial = !0,
            r.ids && (r.data.contextPath = r.ids[0] || r.data.contextPath);
            var a = void 0;
            r.fn && r.fn !== c &&
            function() {
                r.data = s.createFrame(r.data);
                var t = r.fn;
                a = r.data["partial-block"] = function(e) {
                    var r = arguments.length <= 1 || void 0 === arguments[1] ? {}: arguments[1];
                    return r.data = s.createFrame(r.data),
                    r.data["partial-block"] = n,
                    t(e, r)
                },
                t.partials && (r.partials = i.extend({},
                r.partials, t.partials))
            } ();
            void 0 === t && a && (t = a);
            if (void 0 === t) throw new u.
        default("The partial " + r.name + " could not be found");
            if (t instanceof Function) return t(e, r)
        },
        e.noop = c;
        var i = a(r(4)),
        u = o(r(5)),
        s = r(3);
        function l(t, e, r, n, a, o, i) {
            function u(e) {
                var a = arguments.length <= 1 || void 0 === arguments[1] ? {}: arguments[1],
                u = i;
                return ! i || e == i[0] || e === t.nullContext && null === i[0] || (u = [e].concat(i)),
                r(t, e, t.helpers, t.partials, a.data || n, o && [a.blockParams].concat(o), u)
            }
            return (u = f(r, u, t, i, n, o)).program = e,
            u.depth = i ? i.length: 0,
            u.blockParams = a || 0,
            u
        }
        function c() {
            return ""
        }
        function f(t, e, r, n, a, o) {
            if (t.decorator) {
                var u = {};
                e = t.decorator(e, u, r, n && n[0], a, o, n),
                i.extend(e, u)
            }
            return e
        }
    },
    function(t, e, r) {
        t.exports = {
        default:
            r(23),
            __esModule: !0
        }
    },
    function(t, e, r) {
        r(24),
        t.exports = r(29).Object.seal
    },
    function(t, e, r) {
        var n = r(25);
        r(26)("seal",
        function(t) {
            return function(e) {
                return t && n(e) ? t(e) : e
            }
        })
    },
    function(t, e) {
        t.exports = function(t) {
            return "object" == typeof t ? null !== t: "function" == typeof t
        }
    },
    function(t, e, r) {
        var n = r(27),
        a = r(29),
        o = r(32);
        t.exports = function(t, e) {
            var r = (a.Object || {})[t] || Object[t],
            i = {};
            i[t] = e(r),
            n(n.S + n.F * o(function() {
                r(1)
            }), "Object", i)
        }
    },
    function(t, e, r) {
        var n = r(28),
        a = r(29),
        o = r(30),
        i = function(t, e, r) {
            var u, s, l, c = t & i.F,
            f = t & i.G,
            d = t & i.S,
            p = t & i.P,
            h = t & i.B,
            v = t & i.W,
            m = f ? a: a[e] || (a[e] = {}),
            g = f ? n: d ? n[e] : (n[e] || {}).prototype;
            for (u in f && (r = e), r)(s = !c && g && u in g) && u in m || (l = s ? g[u] : r[u], m[u] = f && "function" != typeof g[u] ? r[u] : h && s ? o(l, n) : v && g[u] == l ?
            function(t) {
                var e = function(e) {
                    return this instanceof t ? new t(e) : t(e)
                };
                return e.prototype = t.prototype,
                e
            } (l) : p && "function" == typeof l ? o(Function.call, l) : l, p && ((m.prototype || (m.prototype = {}))[u] = l))
        };
        i.F = 1,
        i.G = 2,
        i.S = 4,
        i.P = 8,
        i.B = 16,
        i.W = 32,
        t.exports = i
    },
    function(t, e) {
        var r = t.exports = "undefined" != typeof window && window.Math == Math ? window: "undefined" != typeof self && self.Math == Math ? self: Function("return this")();
        "number" == typeof __g && (__g = r)
    },
    function(t, e) {
        var r = t.exports = {
            version: "1.2.6"
        };
        "number" == typeof __e && (__e = r)
    },
    function(t, e, r) {
        var n = r(31);
        t.exports = function(t, e, r) {
            if (n(t), void 0 === e) return t;
            switch (r) {
            case 1:
                return function(r) {
                    return t.call(e, r)
                };
            case 2:
                return function(r, n) {
                    return t.call(e, r, n)
                };
            case 3:
                return function(r, n, a) {
                    return t.call(e, r, n, a)
                }
            }
            return function() {
                return t.apply(e, arguments)
            }
        }
    },
    function(t, e) {
        t.exports = function(t) {
            if ("function" != typeof t) throw TypeError(t + " is not a function!");
            return t
        }
    },
    function(t, e) {
        t.exports = function(t) {
            try {
                return !! t()
            } catch(t) {
                return ! 0
            }
        }
    },
    function(t, e) { (function(r) {
            "use strict";
            e.__esModule = !0,
            e.
        default = function(t) {
                var e = void 0 !== r ? r: window,
                n = e.Handlebars;
                t.noConflict = function() {
                    return e.Handlebars === t && (e.Handlebars = n),
                    t
                }
            },
            t.exports = e.
        default
        }).call(e,
        function() {
            return this
        } ())
    }])
}); < /script>
    
    <script>!function(e){var t={};function n(i){if(t[i])return t[i].exports;var o=t[i]={i:i,l:!1,exports:{}};return e[i].call(o.exports,o,o.exports,n),o.l=!0,o.exports}n.m=e,n.c=t,n.d=function(e,t,i){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:i})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(n.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(i,o,function(t){return e[t]}.bind(null,o));return i},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=18)}([function(e,t,n){var i;
/ * !Hammer.JS - v2.0.7 - 2016 - 04 - 22 * http: //hammerjs.github.io/
* *Copyright(c) 2016 Jorik Tangelder; * Licensed under the MIT license * /
/ * !Hammer.JS - v2.0.7 - 2016 - 04 - 22 * http: //hammerjs.github.io/
* *Copyright(c) 2016 Jorik Tangelder; * Licensed under the MIT license * /
!function(o,r,s,a){"use strict";var l,c=["","webkit","Moz","MS","ms","o"],u=r.createElement("div"),h="function",d=Math.round,p=Math.abs,f=Date.now;function v(e,t,n){return setTimeout(T(e,n),t)}function y(e,t,n){return!!Array.isArray(e)&&(g(e,n[t],n),!0)}function g(e,t,n){var i;if(e)if(e.forEach)e.forEach(t,n);else if(e.length!==a)for(i=0;i<e.length;)t.call(n,e[i],i,e),i++;else for(i in e)e.hasOwnProperty(i)&&t.call(n,e[i],i,e)}function m(e,t,n){var i="DEPRECATED METHOD: "+t+"\n"+n+" AT \n";return function(){var t=new Error("get-stack-trace"),n=t&&t.stack?t.stack.replace(/ ^ [ ^ \ (] + ?[\n$] / gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace",
r = o.console && (o.console.warn || o.console.log);
return r && r.call(o.console, i, n),
e.apply(this, arguments)
}
}
l = "function" != typeof Object.assign ?
function(e) {
    if (e === a || null === e) throw new TypeError("Cannot convert undefined or null to object");
    for (var t = Object(e), n = 1; n < arguments.length; n++) {
        var i = arguments[n];
        if (i !== a && null !== i) for (var o in i) i.hasOwnProperty(o) && (t[o] = i[o])
    }
    return t
}: Object.assign;
var b = m(function(e, t, n) {
    for (var i = Object.keys(t), o = 0; o < i.length;)(!n || n && e[i[o]] === a) && (e[i[o]] = t[i[o]]),
    o++;
    return e
},
"extend", "Use `assign`."), E = m(function(e, t) {
    return b(e, t, !0)
},
"merge", "Use `assign`.");
function w(e, t, n) {
    var i, o = t.prototype; (i = e.prototype = Object.create(o)).constructor = e,
    i._super = o,
    n && l(i, n)
}
function T(e, t) {
    return function() {
        return e.apply(t, arguments)
    }
}
function C(e, t) {
    return typeof e == h ? e.apply(t && t[0] || a, t) : e
}
function O(e, t) {
    return e === a ? t: e
}
function I(e, t, n) {
    g(D(t),
    function(t) {
        e.addEventListener(t, n, !1)
    })
}
function k(e, t, n) {
    g(D(t),
    function(t) {
        e.removeEventListener(t, n, !1)
    })
}
function A(e, t) {
    for (; e;) {
        if (e == t) return ! 0;
        e = e.parentNode
    }
    return ! 1
}
function x(e, t) {
    return e.indexOf(t) > -1
}
function D(e) {
    return e.trim().split(/\s+/g)
}
function B(e, t, n) {
    if (e.indexOf && !n) return e.indexOf(t);
    for (var i = 0; i < e.length;) {
        if (n && e[i][n] == t || !n && e[i] === t) return i;
        i++
    }
    return - 1
}
function S(e) {
    return Array.prototype.slice.call(e, 0)
}
function R(e, t, n) {
    for (var i = [], o = [], r = 0; r < e.length;) {
        var s = t ? e[r][t] : e[r];
        B(o, s) < 0 && i.push(e[r]),
        o[r] = s,
        r++
    }
    return n && (i = t ? i.sort(function(e, n) {
        return e[t] > n[t]
    }) : i.sort()),
    i
}
function P(e, t) {
    for (var n, i, o = t[0].toUpperCase() + t.slice(1), r = 0; r < c.length;) {
        if ((i = (n = c[r]) ? n + o: t) in e) return i;
        r++
    }
    return a
}
var _ = 1;
function L(e) {
    var t = e.ownerDocument || e;
    return t.defaultView || t.parentWindow || o
}
var M = "ontouchstart" in o,
N = P(o, "PointerEvent") !== a, V = M && /mobile|tablet|ip(ad|hone|od)|android/i.test(navigator.userAgent), j = 25, z = 1, U = 2, H = 4, F = 8, G = 1, q = 2, X = 4, Y = 8, W = 16, K = q | X, $ = Y | W, Z = K | $, J = ["x", "y"], Q = ["clientX", "clientY"];
function ee(e, t) {
    var n = this;
    this.manager = e,
    this.callback = t,
    this.element = e.element,
    this.target = e.options.inputTarget,
    this.domHandler = function(t) {
        C(e.options.enable, [e]) && n.handler(t)
    },
    this.init()
}
function te(e, t, n) {
    var i = n.pointers.length,
    o = n.changedPointers.length,
    r = t & z && i - o == 0,
    s = t & (H | F) && i - o == 0;
    n.isFirst = !!r,
    n.isFinal = !!s,
    r && (e.session = {}),
    n.eventType = t,
    function(e, t) {
        var n = e.session,
        i = t.pointers,
        o = i.length;
        n.firstInput || (n.firstInput = ne(t));
        o > 1 && !n.firstMultiple ? n.firstMultiple = ne(t) : 1 === o && (n.firstMultiple = !1);
        var r = n.firstInput,
        s = n.firstMultiple,
        l = s ? s.center: r.center,
        c = t.center = ie(i);
        t.timeStamp = f(),
        t.deltaTime = t.timeStamp - r.timeStamp,
        t.angle = ae(l, c),
        t.distance = se(l, c),
        function(e, t) {
            var n = t.center,
            i = e.offsetDelta || {},
            o = e.prevDelta || {},
            r = e.prevInput || {};
            t.eventType !== z && r.eventType !== H || (o = e.prevDelta = {
                x: r.deltaX || 0,
                y: r.deltaY || 0
            },
            i = e.offsetDelta = {
                x: n.x,
                y: n.y
            });
            t.deltaX = o.x + (n.x - i.x),
            t.deltaY = o.y + (n.y - i.y)
        } (n, t),
        t.offsetDirection = re(t.deltaX, t.deltaY);
        var u = oe(t.deltaTime, t.deltaX, t.deltaY);
        t.overallVelocityX = u.x,
        t.overallVelocityY = u.y,
        t.overallVelocity = p(u.x) > p(u.y) ? u.x: u.y,
        t.scale = s ? (h = s.pointers, d = i, se(d[0], d[1], Q) / se(h[0], h[1], Q)) : 1,
        t.rotation = s ?
        function(e, t) {
            return ae(t[1], t[0], Q) + ae(e[1], e[0], Q)
        } (s.pointers, i) : 0,
        t.maxPointers = n.prevInput ? t.pointers.length > n.prevInput.maxPointers ? t.pointers.length: n.prevInput.maxPointers: t.pointers.length,
        function(e, t) {
            var n, i, o, r, s = e.lastInterval || t,
            l = t.timeStamp - s.timeStamp;
            if (t.eventType != F && (l > j || s.velocity === a)) {
                var c = t.deltaX - s.deltaX,
                u = t.deltaY - s.deltaY,
                h = oe(l, c, u);
                i = h.x,
                o = h.y,
                n = p(h.x) > p(h.y) ? h.x: h.y,
                r = re(c, u),
                e.lastInterval = t
            } else n = s.velocity,
            i = s.velocityX,
            o = s.velocityY,
            r = s.direction;
            t.velocity = n,
            t.velocityX = i,
            t.velocityY = o,
            t.direction = r
        } (n, t);
        var h, d;
        var v = e.element;
        A(t.srcEvent.target, v) && (v = t.srcEvent.target);
        t.target = v
    } (e, n),
    e.emit("hammer.input", n),
    e.recognize(n),
    e.session.prevInput = n
}
function ne(e) {
    for (var t = [], n = 0; n < e.pointers.length;) t[n] = {
        clientX: d(e.pointers[n].clientX),
        clientY: d(e.pointers[n].clientY)
    },
    n++;
    return {
        timeStamp: f(),
        pointers: t,
        center: ie(t),
        deltaX: e.deltaX,
        deltaY: e.deltaY
    }
}
function ie(e) {
    var t = e.length;
    if (1 === t) return {
        x: d(e[0].clientX),
        y: d(e[0].clientY)
    };
    for (var n = 0,
    i = 0,
    o = 0; o < t;) n += e[o].clientX,
    i += e[o].clientY,
    o++;
    return {
        x: d(n / t),
        y: d(i / t)
    }
}
function oe(e, t, n) {
    return {
        x: t / e || 0,
        y: n / e || 0
    }
}
function re(e, t) {
    return e === t ? G: p(e) >= p(t) ? e < 0 ? q: X: t < 0 ? Y: W
}
function se(e, t, n) {
    n || (n = J);
    var i = t[n[0]] - e[n[0]],
    o = t[n[1]] - e[n[1]];
    return Math.sqrt(i * i + o * o)
}
function ae(e, t, n) {
    n || (n = J);
    var i = t[n[0]] - e[n[0]],
    o = t[n[1]] - e[n[1]];
    return 180 * Math.atan2(o, i) / Math.PI
}
ee.prototype = {
    handler: function() {},
    init: function() {
        this.evEl && I(this.element, this.evEl, this.domHandler),
        this.evTarget && I(this.target, this.evTarget, this.domHandler),
        this.evWin && I(L(this.element), this.evWin, this.domHandler)
    },
    destroy: function() {
        this.evEl && k(this.element, this.evEl, this.domHandler),
        this.evTarget && k(this.target, this.evTarget, this.domHandler),
        this.evWin && k(L(this.element), this.evWin, this.domHandler)
    }
};
var le = {
    mousedown: z,
    mousemove: U,
    mouseup: H
},
ce = "mousedown", ue = "mousemove mouseup";
function he() {
    this.evEl = ce,
    this.evWin = ue,
    this.pressed = !1,
    ee.apply(this, arguments)
}
w(he, ee, {
    handler: function(e) {
        var t = le[e.type];
        t & z && 0 === e.button && (this.pressed = !0),
        t & U && 1 !== e.which && (t = H),
        this.pressed && (t & H && (this.pressed = !1), this.callback(this.manager, t, {
            pointers: [e],
            changedPointers: [e],
            pointerType: "mouse",
            srcEvent: e
        }))
    }
});
var de = {
    pointerdown: z,
    pointermove: U,
    pointerup: H,
    pointercancel: F,
    pointerout: F
},
pe = {
    2 : "touch",
    3 : "pen",
    4 : "mouse",
    5 : "kinect"
},
fe = "pointerdown", ve = "pointermove pointerup pointercancel";
function ye() {
    this.evEl = fe,
    this.evWin = ve,
    ee.apply(this, arguments),
    this.store = this.manager.session.pointerEvents = []
}
o.MSPointerEvent && !o.PointerEvent && (fe = "MSPointerDown", ve = "MSPointerMove MSPointerUp MSPointerCancel"), w(ye, ee, {
    handler: function(e) {
        var t = this.store,
        n = !1,
        i = e.type.toLowerCase().replace("ms", ""),
        o = de[i],
        r = pe[e.pointerType] || e.pointerType,
        s = "touch" == r,
        a = B(t, e.pointerId, "pointerId");
        o & z && (0 === e.button || s) ? a < 0 && (t.push(e), a = t.length - 1) : o & (H | F) && (n = !0),
        a < 0 || (t[a] = e, this.callback(this.manager, o, {
            pointers: t,
            changedPointers: [e],
            pointerType: r,
            srcEvent: e
        }), n && t.splice(a, 1))
    }
});
var ge = {
    touchstart: z,
    touchmove: U,
    touchend: H,
    touchcancel: F
},
me = "touchstart", be = "touchstart touchmove touchend touchcancel";
function Ee() {
    this.evTarget = me,
    this.evWin = be,
    this.started = !1,
    ee.apply(this, arguments)
}
w(Ee, ee, {
    handler: function(e) {
        var t = ge[e.type];
        if (t === z && (this.started = !0), this.started) {
            var n = function(e, t) {
                var n = S(e.touches),
                i = S(e.changedTouches);
                t & (H | F) && (n = R(n.concat(i), "identifier", !0));
                return [n, i]
            }.call(this, e, t);
            t & (H | F) && n[0].length - n[1].length == 0 && (this.started = !1),
            this.callback(this.manager, t, {
                pointers: n[0],
                changedPointers: n[1],
                pointerType: "touch",
                srcEvent: e
            })
        }
    }
});
var we = {
    touchstart: z,
    touchmove: U,
    touchend: H,
    touchcancel: F
},
Te = "touchstart touchmove touchend touchcancel";
function Ce() {
    this.evTarget = Te,
    this.targetIds = {},
    ee.apply(this, arguments)
}
w(Ce, ee, {
    handler: function(e) {
        var t = we[e.type],
        n = function(e, t) {
            var n = S(e.touches),
            i = this.targetIds;
            if (t & (z | U) && 1 === n.length) return i[n[0].identifier] = !0,
            [n, n];
            var o, r, s = S(e.changedTouches),
            a = [],
            l = this.target;
            if (r = n.filter(function(e) {
                return A(e.target, l)
            }), t === z) for (o = 0; o < r.length;) i[r[o].identifier] = !0,
            o++;
            o = 0;
            for (; o < s.length;) i[s[o].identifier] && a.push(s[o]),
            t & (H | F) && delete i[s[o].identifier],
            o++;
            if (!a.length) return;
            return [R(r.concat(a), "identifier", !0), a]
        }.call(this, e, t);
        n && this.callback(this.manager, t, {
            pointers: n[0],
            changedPointers: n[1],
            pointerType: "touch",
            srcEvent: e
        })
    }
});
var Oe = 2500,
Ie = 25;
function ke() {
    ee.apply(this, arguments);
    var e = T(this.handler, this);
    this.touch = new Ce(this.manager, e),
    this.mouse = new he(this.manager, e),
    this.primaryTouch = null,
    this.lastTouches = []
}
function Ae(e) {
    var t = e.changedPointers[0];
    if (t.identifier === this.primaryTouch) {
        var n = {
            x: t.clientX,
            y: t.clientY
        };
        this.lastTouches.push(n);
        var i = this.lastTouches;
        setTimeout(function() {
            var e = i.indexOf(n);
            e > -1 && i.splice(e, 1)
        },
        Oe)
    }
}
w(ke, ee, {
    handler: function(e, t, n) {
        var i = "touch" == n.pointerType,
        o = "mouse" == n.pointerType;
        if (! (o && n.sourceCapabilities && n.sourceCapabilities.firesTouchEvents)) {
            if (i)(function(e, t) {
                e & z ? (this.primaryTouch = t.changedPointers[0].identifier, Ae.call(this, t)) : e & (H | F) && Ae.call(this, t)
            }).call(this, t, n);
            else if (o &&
            function(e) {
                for (var t = e.srcEvent.clientX,
                n = e.srcEvent.clientY,
                i = 0; i < this.lastTouches.length; i++) {
                    var o = this.lastTouches[i],
                    r = Math.abs(t - o.x),
                    s = Math.abs(n - o.y);
                    if (r <= Ie && s <= Ie) return ! 0
                }
                return ! 1
            }.call(this, n)) return;
            this.callback(e, t, n)
        }
    },
    destroy: function() {
        this.touch.destroy(),
        this.mouse.destroy()
    }
});
var xe = P(u.style, "touchAction"), De = xe !== a, Be = "auto", Se = "manipulation", Re = "none", Pe = "pan-x", _e = "pan-y", Le = function() {
    if (!De) return ! 1;
    var e = {},
    t = o.CSS && o.CSS.supports;
    return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(n) {
        e[n] = !t || o.CSS.supports("touch-action", n)
    }),
    e
} ();
function Me(e, t) {
    this.manager = e,
    this.set(t)
}
Me.prototype = {
    set: function(e) {
        "compute" == e && (e = this.compute()),
        De && this.manager.element.style && Le[e] && (this.manager.element.style[xe] = e),
        this.actions = e.toLowerCase().trim()
    },
    update: function() {
        this.set(this.manager.options.touchAction)
    },
    compute: function() {
        var e = [];
        return g(this.manager.recognizers,
        function(t) {
            C(t.options.enable, [t]) && (e = e.concat(t.getTouchAction()))
        }),
        function(e) {
            if (x(e, Re)) return Re;
            var t = x(e, Pe),
            n = x(e, _e);
            if (t && n) return Re;
            if (t || n) return t ? Pe: _e;
            if (x(e, Se)) return Se;
            return Be
        } (e.join(" "))
    },
    preventDefaults: function(e) {
        var t = e.srcEvent,
        n = e.offsetDirection;
        if (this.manager.session.prevented) t.preventDefault();
        else {
            var i = this.actions,
            o = x(i, Re) && !Le[Re],
            r = x(i, _e) && !Le[_e],
            s = x(i, Pe) && !Le[Pe];
            if (o) {
                var a = 1 === e.pointers.length,
                l = e.distance < 2,
                c = e.deltaTime < 250;
                if (a && l && c) return
            }
            if (!s || !r) return o || r && n & K || s && n & $ ? this.preventSrc(t) : void 0
        }
    },
    preventSrc: function(e) {
        this.manager.session.prevented = !0,
        e.preventDefault()
    }
};
var Ne = 1,
Ve = 2,
je = 4,
ze = 8,
Ue = ze,
He = 16;
function Fe(e) {
    this.options = l({},
    this.defaults, e || {}),
    this.id = _++,
    this.manager = null,
    this.options.enable = O(this.options.enable, !0),
    this.state = Ne,
    this.simultaneous = {},
    this.requireFail = []
}
function Ge(e) {
    return e & He ? "cancel": e & ze ? "end": e & je ? "move": e & Ve ? "start": ""
}
function qe(e) {
    return e == W ? "down": e == Y ? "up": e == q ? "left": e == X ? "right": ""
}
function Xe(e, t) {
    var n = t.manager;
    return n ? n.get(e) : e
}
function Ye() {
    Fe.apply(this, arguments)
}
function We() {
    Ye.apply(this, arguments),
    this.pX = null,
    this.pY = null
}
function Ke() {
    Ye.apply(this, arguments)
}
function $e() {
    Fe.apply(this, arguments),
    this._timer = null,
    this._input = null
}
function Ze() {
    Ye.apply(this, arguments)
}
function Je() {
    Ye.apply(this, arguments)
}
function Qe() {
    Fe.apply(this, arguments),
    this.pTime = !1,
    this.pCenter = !1,
    this._timer = null,
    this._input = null,
    this.count = 0
}
function et(e, t) {
    return (t = t || {}).recognizers = O(t.recognizers, et.defaults.preset),
    new tt(e, t)
}
Fe.prototype = {
    defaults: {},
    set: function(e) {
        return l(this.options, e),
        this.manager && this.manager.touchAction.update(),
        this
    },
    recognizeWith: function(e) {
        if (y(e, "recognizeWith", this)) return this;
        var t = this.simultaneous;
        return t[(e = Xe(e, this)).id] || (t[e.id] = e, e.recognizeWith(this)),
        this
    },
    dropRecognizeWith: function(e) {
        return y(e, "dropRecognizeWith", this) ? this: (e = Xe(e, this), delete this.simultaneous[e.id], this)
    },
    requireFailure: function(e) {
        if (y(e, "requireFailure", this)) return this;
        var t = this.requireFail;
        return - 1 === B(t, e = Xe(e, this)) && (t.push(e), e.requireFailure(this)),
        this
    },
    dropRequireFailure: function(e) {
        if (y(e, "dropRequireFailure", this)) return this;
        e = Xe(e, this);
        var t = B(this.requireFail, e);
        return t > -1 && this.requireFail.splice(t, 1),
        this
    },
    hasRequireFailures: function() {
        return this.requireFail.length > 0
    },
    canRecognizeWith: function(e) {
        return !! this.simultaneous[e.id]
    },
    emit: function(e) {
        var t = this,
        n = this.state;
        function i(n) {
            t.manager.emit(n, e)
        }
        n < ze && i(t.options.event + Ge(n)),
        i(t.options.event),
        e.additionalEvent && i(e.additionalEvent),
        n >= ze && i(t.options.event + Ge(n))
    },
    tryEmit: function(e) {
        if (this.canEmit()) return this.emit(e);
        this.state = 32
    },
    canEmit: function() {
        for (var e = 0; e < this.requireFail.length;) {
            if (! (this.requireFail[e].state & (32 | Ne))) return ! 1;
            e++
        }
        return ! 0
    },
    recognize: function(e) {
        var t = l({},
        e);
        if (!C(this.options.enable, [this, t])) return this.reset(),
        void(this.state = 32);
        this.state & (Ue | He | 32) && (this.state = Ne),
        this.state = this.process(t),
        this.state & (Ve | je | ze | He) && this.tryEmit(t)
    },
    process: function(e) {},
    getTouchAction: function() {},
    reset: function() {}
},
w(Ye, Fe, {
    defaults: {
        pointers: 1
    },
    attrTest: function(e) {
        var t = this.options.pointers;
        return 0 === t || e.pointers.length === t
    },
    process: function(e) {
        var t = this.state,
        n = e.eventType,
        i = t & (Ve | je),
        o = this.attrTest(e);
        return i && (n & F || !o) ? t | He: i || o ? n & H ? t | ze: t & Ve ? t | je: Ve: 32
    }
}), w(We, Ye, {
    defaults: {
        event: "pan",
        threshold: 10,
        pointers: 1,
        direction: Z
    },
    getTouchAction: function() {
        var e = this.options.direction,
        t = [];
        return e & K && t.push(_e),
        e & $ && t.push(Pe),
        t
    },
    directionTest: function(e) {
        var t = this.options,
        n = !0,
        i = e.distance,
        o = e.direction,
        r = e.deltaX,
        s = e.deltaY;
        return o & t.direction || (t.direction & K ? (o = 0 === r ? G: r < 0 ? q: X, n = r != this.pX, i = Math.abs(e.deltaX)) : (o = 0 === s ? G: s < 0 ? Y: W, n = s != this.pY, i = Math.abs(e.deltaY))),
        e.direction = o,
        n && i > t.threshold && o & t.direction
    },
    attrTest: function(e) {
        return Ye.prototype.attrTest.call(this, e) && (this.state & Ve || !(this.state & Ve) && this.directionTest(e))
    },
    emit: function(e) {
        this.pX = e.deltaX,
        this.pY = e.deltaY;
        var t = qe(e.direction);
        t && (e.additionalEvent = this.options.event + t),
        this._super.emit.call(this, e)
    }
}), w(Ke, Ye, {
    defaults: {
        event: "pinch",
        threshold: 0,
        pointers: 2
    },
    getTouchAction: function() {
        return [Re]
    },
    attrTest: function(e) {
        return this._super.attrTest.call(this, e) && (Math.abs(e.scale - 1) > this.options.threshold || this.state & Ve)
    },
    emit: function(e) {
        if (1 !== e.scale) {
            var t = e.scale < 1 ? "in": "out";
            e.additionalEvent = this.options.event + t
        }
        this._super.emit.call(this, e)
    }
}), w($e, Fe, {
    defaults: {
        event: "press",
        pointers: 1,
        time: 251,
        threshold: 9
    },
    getTouchAction: function() {
        return [Be]
    },
    process: function(e) {
        var t = this.options,
        n = e.pointers.length === t.pointers,
        i = e.distance < t.threshold,
        o = e.deltaTime > t.time;
        if (this._input = e, !i || !n || e.eventType & (H | F) && !o) this.reset();
        else if (e.eventType & z) this.reset(),
        this._timer = v(function() {
            this.state = Ue,
            this.tryEmit()
        },
        t.time, this);
        else if (e.eventType & H) return Ue;
        return 32
    },
    reset: function() {
        clearTimeout(this._timer)
    },
    emit: function(e) {
        this.state === Ue && (e && e.eventType & H ? this.manager.emit(this.options.event + "up", e) : (this._input.timeStamp = f(), this.manager.emit(this.options.event, this._input)))
    }
}), w(Ze, Ye, {
    defaults: {
        event: "rotate",
        threshold: 0,
        pointers: 2
    },
    getTouchAction: function() {
        return [Re]
    },
    attrTest: function(e) {
        return this._super.attrTest.call(this, e) && (Math.abs(e.rotation) > this.options.threshold || this.state & Ve)
    }
}), w(Je, Ye, {
    defaults: {
        event: "swipe",
        threshold: 10,
        velocity: .3,
        direction: K | $,
        pointers: 1
    },
    getTouchAction: function() {
        return We.prototype.getTouchAction.call(this)
    },
    attrTest: function(e) {
        var t, n = this.options.direction;
        return n & (K | $) ? t = e.overallVelocity: n & K ? t = e.overallVelocityX: n & $ && (t = e.overallVelocityY),
        this._super.attrTest.call(this, e) && n & e.offsetDirection && e.distance > this.options.threshold && e.maxPointers == this.options.pointers && p(t) > this.options.velocity && e.eventType & H
    },
    emit: function(e) {
        var t = qe(e.offsetDirection);
        t && this.manager.emit(this.options.event + t, e),
        this.manager.emit(this.options.event, e)
    }
}), w(Qe, Fe, {
    defaults: {
        event: "tap",
        pointers: 1,
        taps: 1,
        interval: 300,
        time: 250,
        threshold: 9,
        posThreshold: 10
    },
    getTouchAction: function() {
        return [Se]
    },
    process: function(e) {
        var t = this.options,
        n = e.pointers.length === t.pointers,
        i = e.distance < t.threshold,
        o = e.deltaTime < t.time;
        if (this.reset(), e.eventType & z && 0 === this.count) return this.failTimeout();
        if (i && o && n) {
            if (e.eventType != H) return this.failTimeout();
            var r = !this.pTime || e.timeStamp - this.pTime < t.interval,
            s = !this.pCenter || se(this.pCenter, e.center) < t.posThreshold;
            if (this.pTime = e.timeStamp, this.pCenter = e.center, s && r ? this.count += 1 : this.count = 1, this._input = e, 0 === this.count % t.taps) return this.hasRequireFailures() ? (this._timer = v(function() {
                this.state = Ue,
                this.tryEmit()
            },
            t.interval, this), Ve) : Ue
        }
        return 32
    },
    failTimeout: function() {
        return this._timer = v(function() {
            this.state = 32
        },
        this.options.interval, this),
        32
    },
    reset: function() {
        clearTimeout(this._timer)
    },
    emit: function() {
        this.state == Ue && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
    }
}), et.VERSION = "2.0.7", et.defaults = {
    domEvents: !1,
    touchAction: "compute",
    enable: !0,
    inputTarget: null,
    inputClass: null,
    preset: [[Ze, {
        enable: !1
    }], [Ke, {
        enable: !1
    },
    ["rotate"]], [Je, {
        direction: K
    }], [We, {
        direction: K
    },
    ["swipe"]], [Qe], [Qe, {
        event: "doubletap",
        taps: 2
    },
    ["tap"]], [$e]],
    cssProps: {
        userSelect: "none",
        touchSelect: "none",
        touchCallout: "none",
        contentZooming: "none",
        userDrag: "none",
        tapHighlightColor: "rgba(0,0,0,0)"
    }
};
function tt(e, t) {
    var n;
    this.options = l({},
    et.defaults, t || {}),
    this.options.inputTarget = this.options.inputTarget || e,
    this.handlers = {},
    this.session = {},
    this.recognizers = [],
    this.oldCssProps = {},
    this.element = e,
    this.input = new((n = this).options.inputClass || (N ? ye: V ? Ce: M ? ke: he))(n, te),
    this.touchAction = new Me(this, this.options.touchAction),
    nt(this, !0),
    g(this.options.recognizers,
    function(e) {
        var t = this.add(new e[0](e[1]));
        e[2] && t.recognizeWith(e[2]),
        e[3] && t.requireFailure(e[3])
    },
    this)
}
function nt(e, t) {
    var n, i = e.element;
    i.style && (g(e.options.cssProps,
    function(o, r) {
        n = P(i.style, r),
        t ? (e.oldCssProps[n] = i.style[n], i.style[n] = o) : i.style[n] = e.oldCssProps[n] || ""
    }), t || (e.oldCssProps = {}))
}
tt.prototype = {
    set: function(e) {
        return l(this.options, e),
        e.touchAction && this.touchAction.update(),
        e.inputTarget && (this.input.destroy(), this.input.target = e.inputTarget, this.input.init()),
        this
    },
    stop: function(e) {
        this.session.stopped = e ? 2 : 1
    },
    recognize: function(e) {
        var t = this.session;
        if (!t.stopped) {
            var n;
            this.touchAction.preventDefaults(e);
            var i = this.recognizers,
            o = t.curRecognizer; (!o || o && o.state & Ue) && (o = t.curRecognizer = null);
            for (var r = 0; r < i.length;) n = i[r],
            2 === t.stopped || o && n != o && !n.canRecognizeWith(o) ? n.reset() : n.recognize(e),
            !o && n.state & (Ve | je | ze) && (o = t.curRecognizer = n),
            r++
        }
    },
    get: function(e) {
        if (e instanceof Fe) return e;
        for (var t = this.recognizers,
        n = 0; n < t.length; n++) if (t[n].options.event == e) return t[n];
        return null
    },
    add: function(e) {
        if (y(e, "add", this)) return this;
        var t = this.get(e.options.event);
        return t && this.remove(t),
        this.recognizers.push(e),
        e.manager = this,
        this.touchAction.update(),
        e
    },
    remove: function(e) {
        if (y(e, "remove", this)) return this;
        if (e = this.get(e)) {
            var t = this.recognizers,
            n = B(t, e); - 1 !== n && (t.splice(n, 1), this.touchAction.update())
        }
        return this
    },
    on: function(e, t) {
        if (e !== a && t !== a) {
            var n = this.handlers;
            return g(D(e),
            function(e) {
                n[e] = n[e] || [],
                n[e].push(t)
            }),
            this
        }
    },
    off: function(e, t) {
        if (e !== a) {
            var n = this.handlers;
            return g(D(e),
            function(e) {
                t ? n[e] && n[e].splice(B(n[e], t), 1) : delete n[e]
            }),
            this
        }
    },
    emit: function(e, t) {
        this.options.domEvents &&
        function(e, t) {
            var n = r.createEvent("Event");
            n.initEvent(e, !0, !0),
            n.gesture = t,
            t.target.dispatchEvent(n)
        } (e, t);
        var n = this.handlers[e] && this.handlers[e].slice();
        if (n && n.length) {
            t.type = e,
            t.preventDefault = function() {
                t.srcEvent.preventDefault()
            };
            for (var i = 0; i < n.length;) n[i](t),
            i++
        }
    },
    destroy: function() {
        this.element && nt(this, !1),
        this.handlers = {},
        this.session = {},
        this.input.destroy(),
        this.element = null
    }
},
l(et, {
    INPUT_START: z,
    INPUT_MOVE: U,
    INPUT_END: H,
    INPUT_CANCEL: F,
    STATE_POSSIBLE: Ne,
    STATE_BEGAN: Ve,
    STATE_CHANGED: je,
    STATE_ENDED: ze,
    STATE_RECOGNIZED: Ue,
    STATE_CANCELLED: He,
    STATE_FAILED: 32,
    DIRECTION_NONE: G,
    DIRECTION_LEFT: q,
    DIRECTION_RIGHT: X,
    DIRECTION_UP: Y,
    DIRECTION_DOWN: W,
    DIRECTION_HORIZONTAL: K,
    DIRECTION_VERTICAL: $,
    DIRECTION_ALL: Z,
    Manager: tt,
    Input: ee,
    TouchAction: Me,
    TouchInput: Ce,
    MouseInput: he,
    PointerEventInput: ye,
    TouchMouseInput: ke,
    SingleTouchInput: Ee,
    Recognizer: Fe,
    AttrRecognizer: Ye,
    Tap: Qe,
    Pan: We,
    Swipe: Je,
    Pinch: Ke,
    Rotate: Ze,
    Press: $e,
    on: I,
    off: k,
    each: g,
    merge: E,
    extend: b,
    assign: l,
    inherit: w,
    bindFn: T,
    prefixed: P
}), (void 0 !== o ? o: "undefined" != typeof self ? self: {}).Hammer = et, (i = function() {
    return et
}.call(t, n, t, e)) === a || (e.exports = i)
} (window, document)
},
function(e, t, n) { (function(n) {
        var i;
        t = e.exports = p,
        i = "object" == typeof n && n.env && n.env.NODE_DEBUG && /\bsemver\b/i.test(n.env.NODE_DEBUG) ?
        function() {
            var e = Array.prototype.slice.call(arguments, 0);
            e.unshift("SEMVER"),
            console.log.apply(console, e)
        }: function() {},
        t.SEMVER_SPEC_VERSION = "2.0.0";
        var o = 256,
        r = Number.MAX_SAFE_INTEGER || 9007199254740991,
        s = t.re = [],
        a = t.src = [],
        l = t.tokens = {},
        c = 0;
        function u(e) {
            l[e] = c++
        }
        u("NUMERICIDENTIFIER"),
        a[l.NUMERICIDENTIFIER] = "0|[1-9]\\d*",
        u("NUMERICIDENTIFIERLOOSE"),
        a[l.NUMERICIDENTIFIERLOOSE] = "[0-9]+",
        u("NONNUMERICIDENTIFIER"),
        a[l.NONNUMERICIDENTIFIER] = "\\d*[a-zA-Z-][a-zA-Z0-9-]*",
        u("MAINVERSION"),
        a[l.MAINVERSION] = "(" + a[l.NUMERICIDENTIFIER] + ")\\.(" + a[l.NUMERICIDENTIFIER] + ")\\.(" + a[l.NUMERICIDENTIFIER] + ")",
        u("MAINVERSIONLOOSE"),
        a[l.MAINVERSIONLOOSE] = "(" + a[l.NUMERICIDENTIFIERLOOSE] + ")\\.(" + a[l.NUMERICIDENTIFIERLOOSE] + ")\\.(" + a[l.NUMERICIDENTIFIERLOOSE] + ")",
        u("PRERELEASEIDENTIFIER"),
        a[l.PRERELEASEIDENTIFIER] = "(?:" + a[l.NUMERICIDENTIFIER] + "|" + a[l.NONNUMERICIDENTIFIER] + ")",
        u("PRERELEASEIDENTIFIERLOOSE"),
        a[l.PRERELEASEIDENTIFIERLOOSE] = "(?:" + a[l.NUMERICIDENTIFIERLOOSE] + "|" + a[l.NONNUMERICIDENTIFIER] + ")",
        u("PRERELEASE"),
        a[l.PRERELEASE] = "(?:-(" + a[l.PRERELEASEIDENTIFIER] + "(?:\\." + a[l.PRERELEASEIDENTIFIER] + ")*))",
        u("PRERELEASELOOSE"),
        a[l.PRERELEASELOOSE] = "(?:-?(" + a[l.PRERELEASEIDENTIFIERLOOSE] + "(?:\\." + a[l.PRERELEASEIDENTIFIERLOOSE] + ")*))",
        u("BUILDIDENTIFIER"),
        a[l.BUILDIDENTIFIER] = "[0-9A-Za-z-]+",
        u("BUILD"),
        a[l.BUILD] = "(?:\\+(" + a[l.BUILDIDENTIFIER] + "(?:\\." + a[l.BUILDIDENTIFIER] + ")*))",
        u("FULL"),
        u("FULLPLAIN"),
        a[l.FULLPLAIN] = "v?" + a[l.MAINVERSION] + a[l.PRERELEASE] + "?" + a[l.BUILD] + "?",
        a[l.FULL] = "^" + a[l.FULLPLAIN] + "$",
        u("LOOSEPLAIN"),
        a[l.LOOSEPLAIN] = "[v=\\s]*" + a[l.MAINVERSIONLOOSE] + a[l.PRERELEASELOOSE] + "?" + a[l.BUILD] + "?",
        u("LOOSE"),
        a[l.LOOSE] = "^" + a[l.LOOSEPLAIN] + "$",
        u("GTLT"),
        a[l.GTLT] = "((?:<|>)?=?)",
        u("XRANGEIDENTIFIERLOOSE"),
        a[l.XRANGEIDENTIFIERLOOSE] = a[l.NUMERICIDENTIFIERLOOSE] + "|x|X|\\*",
        u("XRANGEIDENTIFIER"),
        a[l.XRANGEIDENTIFIER] = a[l.NUMERICIDENTIFIER] + "|x|X|\\*",
        u("XRANGEPLAIN"),
        a[l.XRANGEPLAIN] = "[v=\\s]*(" + a[l.XRANGEIDENTIFIER] + ")(?:\\.(" + a[l.XRANGEIDENTIFIER] + ")(?:\\.(" + a[l.XRANGEIDENTIFIER] + ")(?:" + a[l.PRERELEASE] + ")?" + a[l.BUILD] + "?)?)?",
        u("XRANGEPLAINLOOSE"),
        a[l.XRANGEPLAINLOOSE] = "[v=\\s]*(" + a[l.XRANGEIDENTIFIERLOOSE] + ")(?:\\.(" + a[l.XRANGEIDENTIFIERLOOSE] + ")(?:\\.(" + a[l.XRANGEIDENTIFIERLOOSE] + ")(?:" + a[l.PRERELEASELOOSE] + ")?" + a[l.BUILD] + "?)?)?",
        u("XRANGE"),
        a[l.XRANGE] = "^" + a[l.GTLT] + "\\s*" + a[l.XRANGEPLAIN] + "$",
        u("XRANGELOOSE"),
        a[l.XRANGELOOSE] = "^" + a[l.GTLT] + "\\s*" + a[l.XRANGEPLAINLOOSE] + "$",
        u("COERCE"),
        a[l.COERCE] = "(^|[^\\d])(\\d{1,16})(?:\\.(\\d{1,16}))?(?:\\.(\\d{1,16}))?(?:$|[^\\d])",
        u("COERCERTL"),
        s[l.COERCERTL] = new RegExp(a[l.COERCE], "g"),
        u("LONETILDE"),
        a[l.LONETILDE] = "(?:~>?)",
        u("TILDETRIM"),
        a[l.TILDETRIM] = "(\\s*)" + a[l.LONETILDE] + "\\s+",
        s[l.TILDETRIM] = new RegExp(a[l.TILDETRIM], "g");
        u("TILDE"),
        a[l.TILDE] = "^" + a[l.LONETILDE] + a[l.XRANGEPLAIN] + "$",
        u("TILDELOOSE"),
        a[l.TILDELOOSE] = "^" + a[l.LONETILDE] + a[l.XRANGEPLAINLOOSE] + "$",
        u("LONECARET"),
        a[l.LONECARET] = "(?:\\^)",
        u("CARETTRIM"),
        a[l.CARETTRIM] = "(\\s*)" + a[l.LONECARET] + "\\s+",
        s[l.CARETTRIM] = new RegExp(a[l.CARETTRIM], "g");
        u("CARET"),
        a[l.CARET] = "^" + a[l.LONECARET] + a[l.XRANGEPLAIN] + "$",
        u("CARETLOOSE"),
        a[l.CARETLOOSE] = "^" + a[l.LONECARET] + a[l.XRANGEPLAINLOOSE] + "$",
        u("COMPARATORLOOSE"),
        a[l.COMPARATORLOOSE] = "^" + a[l.GTLT] + "\\s*(" + a[l.LOOSEPLAIN] + ")$|^$",
        u("COMPARATOR"),
        a[l.COMPARATOR] = "^" + a[l.GTLT] + "\\s*(" + a[l.FULLPLAIN] + ")$|^$",
        u("COMPARATORTRIM"),
        a[l.COMPARATORTRIM] = "(\\s*)" + a[l.GTLT] + "\\s*(" + a[l.LOOSEPLAIN] + "|" + a[l.XRANGEPLAIN] + ")",
        s[l.COMPARATORTRIM] = new RegExp(a[l.COMPARATORTRIM], "g");
        u("HYPHENRANGE"),
        a[l.HYPHENRANGE] = "^\\s*(" + a[l.XRANGEPLAIN] + ")\\s+-\\s+(" + a[l.XRANGEPLAIN] + ")\\s*$",
        u("HYPHENRANGELOOSE"),
        a[l.HYPHENRANGELOOSE] = "^\\s*(" + a[l.XRANGEPLAINLOOSE] + ")\\s+-\\s+(" + a[l.XRANGEPLAINLOOSE] + ")\\s*$",
        u("STAR"),
        a[l.STAR] = "(<|>)?=?\\s*\\*";
        for (var h = 0; h < c; h++) i(h, a[h]),
        s[h] || (s[h] = new RegExp(a[h]));
        function d(e, t) {
            if (t && "object" == typeof t || (t = {
                loose: !!t,
                includePrerelease: !1
            }), e instanceof p) return e;
            if ("string" != typeof e) return null;
            if (e.length > o) return null;
            if (! (t.loose ? s[l.LOOSE] : s[l.FULL]).test(e)) return null;
            try {
                return new p(e, t)
            } catch(e) {
                return null
            }
        }
        function p(e, t) {
            if (t && "object" == typeof t || (t = {
                loose: !!t,
                includePrerelease: !1
            }), e instanceof p) {
                if (e.loose === t.loose) return e;
                e = e.version
            } else if ("string" != typeof e) throw new TypeError("Invalid Version: " + e);
            if (e.length > o) throw new TypeError("version is longer than " + o + " characters");
            if (! (this instanceof p)) return new p(e, t);
            i("SemVer", e, t),
            this.options = t,
            this.loose = !!t.loose;
            var n = e.trim().match(t.loose ? s[l.LOOSE] : s[l.FULL]);
            if (!n) throw new TypeError("Invalid Version: " + e);
            if (this.raw = e, this.major = +n[1], this.minor = +n[2], this.patch = +n[3], this.major > r || this.major < 0) throw new TypeError("Invalid major version");
            if (this.minor > r || this.minor < 0) throw new TypeError("Invalid minor version");
            if (this.patch > r || this.patch < 0) throw new TypeError("Invalid patch version");
            n[4] ? this.prerelease = n[4].split(".").map(function(e) {
                if (/^[0-9]+$/.test(e)) {
                    var t = +e;
                    if (t >= 0 && t < r) return t
                }
                return e
            }) : this.prerelease = [],
            this.build = n[5] ? n[5].split(".") : [],
            this.format()
        }
        t.parse = d,
        t.valid = function(e, t) {
            var n = d(e, t);
            return n ? n.version: null
        },
        t.clean = function(e, t) {
            var n = d(e.trim().replace(/^[=v]+/, ""), t);
            return n ? n.version: null
        },
        t.SemVer = p,
        p.prototype.format = function() {
            return this.version = this.major + "." + this.minor + "." + this.patch,
            this.prerelease.length && (this.version += "-" + this.prerelease.join(".")),
            this.version
        },
        p.prototype.toString = function() {
            return this.version
        },
        p.prototype.compare = function(e) {
            return i("SemVer.compare", this.version, this.options, e),
            e instanceof p || (e = new p(e, this.options)),
            this.compareMain(e) || this.comparePre(e)
        },
        p.prototype.compareMain = function(e) {
            return e instanceof p || (e = new p(e, this.options)),
            v(this.major, e.major) || v(this.minor, e.minor) || v(this.patch, e.patch)
        },
        p.prototype.comparePre = function(e) {
            if (e instanceof p || (e = new p(e, this.options)), this.prerelease.length && !e.prerelease.length) return - 1;
            if (!this.prerelease.length && e.prerelease.length) return 1;
            if (!this.prerelease.length && !e.prerelease.length) return 0;
            var t = 0;
            do {
                var n = this.prerelease[t], o = e.prerelease[t];
                if (i("prerelease compare", t, n, o), void 0 === n && void 0 === o) return 0;
                if (void 0 === o) return 1;
                if (void 0 === n) return - 1;
                if (n !== o) return v(n, o)
            } while (++ t )
        },
        p.prototype.compareBuild = function(e) {
            e instanceof p || (e = new p(e, this.options));
            var t = 0;
            do {
                var n = this.build[t], o = e.build[t];
                if (i("prerelease compare", t, n, o), void 0 === n && void 0 === o) return 0;
                if (void 0 === o) return 1;
                if (void 0 === n) return - 1;
                if (n !== o) return v(n, o)
            } while (++ t )
        },
        p.prototype.inc = function(e, t) {
            switch (e) {
            case "premajor":
                this.prerelease.length = 0,
                this.patch = 0,
                this.minor = 0,
                this.major++,
                this.inc("pre", t);
                break;
            case "preminor":
                this.prerelease.length = 0,
                this.patch = 0,
                this.minor++,
                this.inc("pre", t);
                break;
            case "prepatch":
                this.prerelease.length = 0,
                this.inc("patch", t),
                this.inc("pre", t);
                break;
            case "prerelease":
                0 === this.prerelease.length && this.inc("patch", t),
                this.inc("pre", t);
                break;
            case "major":
                0 === this.minor && 0 === this.patch && 0 !== this.prerelease.length || this.major++,
                this.minor = 0,
                this.patch = 0,
                this.prerelease = [];
                break;
            case "minor":
                0 === this.patch && 0 !== this.prerelease.length || this.minor++,
                this.patch = 0,
                this.prerelease = [];
                break;
            case "patch":
                0 === this.prerelease.length && this.patch++,
                this.prerelease = [];
                break;
            case "pre":
                if (0 === this.prerelease.length) this.prerelease = [0];
                else {
                    for (var n = this.prerelease.length; --n >= 0;)"number" == typeof this.prerelease[n] && (this.prerelease[n]++, n = -2); - 1 === n && this.prerelease.push(0)
                }
                t && (this.prerelease[0] === t ? isNaN(this.prerelease[1]) && (this.prerelease = [t, 0]) : this.prerelease = [t, 0]);
                break;
            default:
                throw new Error("invalid increment argument: " + e)
            }
            return this.format(),
            this.raw = this.version,
            this
        },
        t.inc = function(e, t, n, i) {
            "string" == typeof n && (i = n, n = void 0);
            try {
                return new p(e, n).inc(t, i).version
            } catch(e) {
                return null
            }
        },
        t.diff = function(e, t) {
            if (b(e, t)) return null;
            var n = d(e),
            i = d(t),
            o = "";
            if (n.prerelease.length || i.prerelease.length) {
                o = "pre";
                var r = "prerelease"
            }
            for (var s in n) if (("major" === s || "minor" === s || "patch" === s) && n[s] !== i[s]) return o + s;
            return r
        },
        t.compareIdentifiers = v;
        var f = /^[0-9]+$/;
        function v(e, t) {
            var n = f.test(e),
            i = f.test(t);
            return n && i && (e = +e, t = +t),
            e === t ? 0 : n && !i ? -1 : i && !n ? 1 : e < t ? -1 : 1
        }
        function y(e, t, n) {
            return new p(e, n).compare(new p(t, n))
        }
        function g(e, t, n) {
            return y(e, t, n) > 0
        }
        function m(e, t, n) {
            return y(e, t, n) < 0
        }
        function b(e, t, n) {
            return 0 === y(e, t, n)
        }
        function E(e, t, n) {
            return 0 !== y(e, t, n)
        }
        function w(e, t, n) {
            return y(e, t, n) >= 0
        }
        function T(e, t, n) {
            return y(e, t, n) <= 0
        }
        function C(e, t, n, i) {
            switch (t) {
            case "===":
                return "object" == typeof e && (e = e.version),
                "object" == typeof n && (n = n.version),
                e === n;
            case "!==":
                return "object" == typeof e && (e = e.version),
                "object" == typeof n && (n = n.version),
                e !== n;
            case "":
            case "=":
            case "==":
                return b(e, n, i);
            case "!=":
                return E(e, n, i);
            case ">":
                return g(e, n, i);
            case ">=":
                return w(e, n, i);
            case "<":
                return m(e, n, i);
            case "<=":
                return T(e, n, i);
            default:
                throw new TypeError("Invalid operator: " + t)
            }
        }
        function O(e, t) {
            if (t && "object" == typeof t || (t = {
                loose: !!t,
                includePrerelease: !1
            }), e instanceof O) {
                if (e.loose === !!t.loose) return e;
                e = e.value
            }
            if (! (this instanceof O)) return new O(e, t);
            i("comparator", e, t),
            this.options = t,
            this.loose = !!t.loose,
            this.parse(e),
            this.semver === I ? this.value = "": this.value = this.operator + this.semver.version,
            i("comp", this)
        }
        t.rcompareIdentifiers = function(e, t) {
            return v(t, e)
        },
        t.major = function(e, t) {
            return new p(e, t).major
        },
        t.minor = function(e, t) {
            return new p(e, t).minor
        },
        t.patch = function(e, t) {
            return new p(e, t).patch
        },
        t.compare = y,
        t.compareLoose = function(e, t) {
            return y(e, t, !0)
        },
        t.compareBuild = function(e, t, n) {
            var i = new p(e, n),
            o = new p(t, n);
            return i.compare(o) || i.compareBuild(o)
        },
        t.rcompare = function(e, t, n) {
            return y(t, e, n)
        },
        t.sort = function(e, n) {
            return e.sort(function(e, i) {
                return t.compareBuild(e, i, n)
            })
        },
        t.rsort = function(e, n) {
            return e.sort(function(e, i) {
                return t.compareBuild(i, e, n)
            })
        },
        t.gt = g,
        t.lt = m,
        t.eq = b,
        t.neq = E,
        t.gte = w,
        t.lte = T,
        t.cmp = C,
        t.Comparator = O;
        var I = {};
        function k(e, t) {
            if (t && "object" == typeof t || (t = {
                loose: !!t,
                includePrerelease: !1
            }), e instanceof k) return e.loose === !!t.loose && e.includePrerelease === !!t.includePrerelease ? e: new k(e.raw, t);
            if (e instanceof O) return new k(e.value, t);
            if (! (this instanceof k)) return new k(e, t);
            if (this.options = t, this.loose = !!t.loose, this.includePrerelease = !!t.includePrerelease, this.raw = e, this.set = e.split(/\s*\|\|\s*/).map(function(e) {
                return this.parseRange(e.trim())
            },
            this).filter(function(e) {
                return e.length
            }), !this.set.length) throw new TypeError("Invalid SemVer Range: " + e);
            this.format()
        }
        function A(e, t) {
            for (var n = !0,
            i = e.slice(), o = i.pop(); n && i.length;) n = i.every(function(e) {
                return o.intersects(e, t)
            }),
            o = i.pop();
            return n
        }
        function x(e) {
            return ! e || "x" === e.toLowerCase() || "*" === e
        }
        function D(e, t, n, i, o, r, s, a, l, c, u, h, d) {
            return ((t = x(n) ? "": x(i) ? ">=" + n + ".0.0": x(o) ? ">=" + n + "." + i + ".0": ">=" + t) + " " + (a = x(l) ? "": x(c) ? "<" + ( + l + 1) + ".0.0": x(u) ? "<" + l + "." + ( + c + 1) + ".0": h ? "<=" + l + "." + c + "." + u + "-" + h: "<=" + a)).trim()
        }
        function B(e, t, n) {
            for (var o = 0; o < e.length; o++) if (!e[o].test(t)) return ! 1;
            if (t.prerelease.length && !n.includePrerelease) {
                for (o = 0; o < e.length; o++) if (i(e[o].semver), e[o].semver !== I && e[o].semver.prerelease.length > 0) {
                    var r = e[o].semver;
                    if (r.major === t.major && r.minor === t.minor && r.patch === t.patch) return ! 0
                }
                return ! 1
            }
            return ! 0
        }
        function S(e, t, n) {
            try {
                t = new k(t, n)
            } catch(e) {
                return ! 1
            }
            return t.test(e)
        }
        function R(e, t, n, i) {
            var o, r, s, a, l;
            switch (e = new p(e, i), t = new k(t, i), n) {
            case ">":
                o = g,
                r = T,
                s = m,
                a = ">",
                l = ">=";
                break;
            case "<":
                o = m,
                r = w,
                s = g,
                a = "<",
                l = "<=";
                break;
            default:
                throw new TypeError('Must provide a hilo val of "<" or ">"')
            }
            if (S(e, t, i)) return ! 1;
            for (var c = 0; c < t.set.length; ++c) {
                var u = t.set[c],
                h = null,
                d = null;
                if (u.forEach(function(e) {
                    e.semver === I && (e = new O(">=0.0.0")),
                    h = h || e,
                    d = d || e,
                    o(e.semver, h.semver, i) ? h = e: s(e.semver, d.semver, i) && (d = e)
                }), h.operator === a || h.operator === l) return ! 1;
                if ((!d.operator || d.operator === a) && r(e, d.semver)) return ! 1;
                if (d.operator === l && s(e, d.semver)) return ! 1
            }
            return ! 0
        }
        O.prototype.parse = function(e) {
            var t = this.options.loose ? s[l.COMPARATORLOOSE] : s[l.COMPARATOR],
            n = e.match(t);
            if (!n) throw new TypeError("Invalid comparator: " + e);
            this.operator = void 0 !== n[1] ? n[1] : "",
            "=" === this.operator && (this.operator = ""),
            n[2] ? this.semver = new p(n[2], this.options.loose) : this.semver = I
        },
        O.prototype.toString = function() {
            return this.value
        },
        O.prototype.test = function(e) {
            if (i("Comparator.test", e, this.options.loose), this.semver === I || e === I) return ! 0;
            if ("string" == typeof e) try {
                e = new p(e, this.options)
            } catch(e) {
                return ! 1
            }
            return C(e, this.operator, this.semver, this.options)
        },
        O.prototype.intersects = function(e, t) {
            if (! (e instanceof O)) throw new TypeError("a Comparator is required");
            var n;
            if (t && "object" == typeof t || (t = {
                loose: !!t,
                includePrerelease: !1
            }), "" === this.operator) return "" === this.value || (n = new k(e.value, t), S(this.value, n, t));
            if ("" === e.operator) return "" === e.value || (n = new k(this.value, t), S(e.semver, n, t));
            var i = !(">=" !== this.operator && ">" !== this.operator || ">=" !== e.operator && ">" !== e.operator),
            o = !("<=" !== this.operator && "<" !== this.operator || "<=" !== e.operator && "<" !== e.operator),
            r = this.semver.version === e.semver.version,
            s = !(">=" !== this.operator && "<=" !== this.operator || ">=" !== e.operator && "<=" !== e.operator),
            a = C(this.semver, "<", e.semver, t) && (">=" === this.operator || ">" === this.operator) && ("<=" === e.operator || "<" === e.operator),
            l = C(this.semver, ">", e.semver, t) && ("<=" === this.operator || "<" === this.operator) && (">=" === e.operator || ">" === e.operator);
            return i || o || r && s || a || l
        },
        t.Range = k,
        k.prototype.format = function() {
            return this.range = this.set.map(function(e) {
                return e.join(" ").trim()
            }).join("||").trim(),
            this.range
        },
        k.prototype.toString = function() {
            return this.range
        },
        k.prototype.parseRange = function(e) {
            var t = this.options.loose;
            e = e.trim();
            var n = t ? s[l.HYPHENRANGELOOSE] : s[l.HYPHENRANGE];
            e = e.replace(n, D),
            i("hyphen replace", e),
            e = e.replace(s[l.COMPARATORTRIM], "$1$2$3"),
            i("comparator trim", e, s[l.COMPARATORTRIM]),
            e = (e = (e = e.replace(s[l.TILDETRIM], "$1~")).replace(s[l.CARETTRIM], "$1^")).split(/\s+/).join(" ");
            var o = t ? s[l.COMPARATORLOOSE] : s[l.COMPARATOR],
            r = e.split(" ").map(function(e) {
                return function(e, t) {
                    return i("comp", e, t),
                    e = function(e, t) {
                        return e.trim().split(/\s+/).map(function(e) {
                            return function(e, t) {
                                i("caret", e, t);
                                var n = t.loose ? s[l.CARETLOOSE] : s[l.CARET];
                                return e.replace(n,
                                function(t, n, o, r, s) {
                                    var a;
                                    return i("caret", e, t, n, o, r, s),
                                    x(n) ? a = "": x(o) ? a = ">=" + n + ".0.0 <" + ( + n + 1) + ".0.0": x(r) ? a = "0" === n ? ">=" + n + "." + o + ".0 <" + n + "." + ( + o + 1) + ".0": ">=" + n + "." + o + ".0 <" + ( + n + 1) + ".0.0": s ? (i("replaceCaret pr", s), a = "0" === n ? "0" === o ? ">=" + n + "." + o + "." + r + "-" + s + " <" + n + "." + o + "." + ( + r + 1) : ">=" + n + "." + o + "." + r + "-" + s + " <" + n + "." + ( + o + 1) + ".0": ">=" + n + "." + o + "." + r + "-" + s + " <" + ( + n + 1) + ".0.0") : (i("no pr"), a = "0" === n ? "0" === o ? ">=" + n + "." + o + "." + r + " <" + n + "." + o + "." + ( + r + 1) : ">=" + n + "." + o + "." + r + " <" + n + "." + ( + o + 1) + ".0": ">=" + n + "." + o + "." + r + " <" + ( + n + 1) + ".0.0"),
                                    i("caret return", a),
                                    a
                                })
                            } (e, t)
                        }).join(" ")
                    } (e, t),
                    i("caret", e),
                    e = function(e, t) {
                        return e.trim().split(/\s+/).map(function(e) {
                            return function(e, t) {
                                var n = t.loose ? s[l.TILDELOOSE] : s[l.TILDE];
                                return e.replace(n,
                                function(t, n, o, r, s) {
                                    var a;
                                    return i("tilde", e, t, n, o, r, s),
                                    x(n) ? a = "": x(o) ? a = ">=" + n + ".0.0 <" + ( + n + 1) + ".0.0": x(r) ? a = ">=" + n + "." + o + ".0 <" + n + "." + ( + o + 1) + ".0": s ? (i("replaceTilde pr", s), a = ">=" + n + "." + o + "." + r + "-" + s + " <" + n + "." + ( + o + 1) + ".0") : a = ">=" + n + "." + o + "." + r + " <" + n + "." + ( + o + 1) + ".0",
                                    i("tilde return", a),
                                    a
                                })
                            } (e, t)
                        }).join(" ")
                    } (e, t),
                    i("tildes", e),
                    e = function(e, t) {
                        return i("replaceXRanges", e, t),
                        e.split(/\s+/).map(function(e) {
                            return function(e, t) {
                                e = e.trim();
                                var n = t.loose ? s[l.XRANGELOOSE] : s[l.XRANGE];
                                return e.replace(n,
                                function(n, o, r, s, a, l) {
                                    i("xRange", e, n, o, r, s, a, l);
                                    var c = x(r),
                                    u = c || x(s),
                                    h = u || x(a),
                                    d = h;
                                    return "=" === o && d && (o = ""),
                                    l = t.includePrerelease ? "-0": "",
                                    c ? n = ">" === o || "<" === o ? "<0.0.0-0": "*": o && d ? (u && (s = 0), a = 0, ">" === o ? (o = ">=", u ? (r = +r + 1, s = 0, a = 0) : (s = +s + 1, a = 0)) : "<=" === o && (o = "<", u ? r = +r + 1 : s = +s + 1), n = o + r + "." + s + "." + a + l) : u ? n = ">=" + r + ".0.0" + l + " <" + ( + r + 1) + ".0.0" + l: h && (n = ">=" + r + "." + s + ".0" + l + " <" + r + "." + ( + s + 1) + ".0" + l),
                                    i("xRange return", n),
                                    n
                                })
                            } (e, t)
                        }).join(" ")
                    } (e, t),
                    i("xrange", e),
                    e = function(e, t) {
                        return i("replaceStars", e, t),
                        e.trim().replace(s[l.STAR], "")
                    } (e, t),
                    i("stars", e),
                    e
                } (e, this.options)
            },
            this).join(" ").split(/\s+/);
            return this.options.loose && (r = r.filter(function(e) {
                return !! e.match(o)
            })),
            r = r.map(function(e) {
                return new O(e, this.options)
            },
            this)
        },
        k.prototype.intersects = function(e, t) {
            if (! (e instanceof k)) throw new TypeError("a Range is required");
            return this.set.some(function(n) {
                return A(n, t) && e.set.some(function(e) {
                    return A(e, t) && n.every(function(n) {
                        return e.every(function(e) {
                            return n.intersects(e, t)
                        })
                    })
                })
            })
        },
        t.toComparators = function(e, t) {
            return new k(e, t).set.map(function(e) {
                return e.map(function(e) {
                    return e.value
                }).join(" ").trim().split(" ")
            })
        },
        k.prototype.test = function(e) {
            if (!e) return ! 1;
            if ("string" == typeof e) try {
                e = new p(e, this.options)
            } catch(e) {
                return ! 1
            }
            for (var t = 0; t < this.set.length; t++) if (B(this.set[t], e, this.options)) return ! 0;
            return ! 1
        },
        t.satisfies = S,
        t.maxSatisfying = function(e, t, n) {
            var i = null,
            o = null;
            try {
                var r = new k(t, n)
            } catch(e) {
                return null
            }
            return e.forEach(function(e) {
                r.test(e) && (i && -1 !== o.compare(e) || (o = new p(i = e, n)))
            }),
            i
        },
        t.minSatisfying = function(e, t, n) {
            var i = null,
            o = null;
            try {
                var r = new k(t, n)
            } catch(e) {
                return null
            }
            return e.forEach(function(e) {
                r.test(e) && (i && 1 !== o.compare(e) || (o = new p(i = e, n)))
            }),
            i
        },
        t.minVersion = function(e, t) {
            e = new k(e, t);
            var n = new p("0.0.0");
            if (e.test(n)) return n;
            if (n = new p("0.0.0-0"), e.test(n)) return n;
            n = null;
            for (var i = 0; i < e.set.length; ++i) {
                var o = e.set[i];
                o.forEach(function(e) {
                    var t = new p(e.semver.version);
                    switch (e.operator) {
                    case ">":
                        0 === t.prerelease.length ? t.patch++:t.prerelease.push(0),
                        t.raw = t.format();
                    case "":
                    case ">=":
                        n && !g(n, t) || (n = t);
                        break;
                    case "<":
                    case "<=":
                        break;
                    default:
                        throw new Error("Unexpected operation: " + e.operator)
                    }
                })
            }
            if (n && e.test(n)) return n;
            return null
        },
        t.validRange = function(e, t) {
            try {
                return new k(e, t).range || "*"
            } catch(e) {
                return null
            }
        },
        t.ltr = function(e, t, n) {
            return R(e, t, "<", n)
        },
        t.gtr = function(e, t, n) {
            return R(e, t, ">", n)
        },
        t.outside = R,
        t.prerelease = function(e, t) {
            var n = d(e, t);
            return n && n.prerelease.length ? n.prerelease: null
        },
        t.intersects = function(e, t, n) {
            return e = new k(e, n),
            t = new k(t, n),
            e.intersects(t)
        },
        t.coerce = function(e, t) {
            if (e instanceof p) return e;
            "number" == typeof e && (e = String(e));
            if ("string" != typeof e) return null;
            var n = null;
            if ((t = t || {}).rtl) {
                for (var i; (i = s[l.COERCERTL].exec(e)) && (!n || n.index + n[0].length !== e.length);) n && i.index + i[0].length === n.index + n[0].length || (n = i),
                s[l.COERCERTL].lastIndex = i.index + i[1].length + i[2].length;
                s[l.COERCERTL].lastIndex = -1
            } else n = e.match(s[l.COERCE]);
            if (null === n) return null;
            return d(n[2] + "." + (n[3] || "0") + "." + (n[4] || "0"), t)
        }
    }).call(this, n(10))
},
function(e, t, n) {
    var i; !
    function() {
        "use strict";
        /**
	 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
	 *
	 * @codingstandard ftlabs-jsv2
	 * @copyright The Financial Times Limited [All Rights Reserved]
	 * @license MIT License (see LICENSE.txt)
	 */
        function o(e, t) {
            var n;
            if (t = t || {},
            this.trackingClick = !1, this.trackingClickStart = 0, this.targetElement = null, this.touchStartX = 0, this.touchStartY = 0, this.lastTouchIdentifier = 0, this.touchBoundary = t.touchBoundary || 10, this.layer = e, this.tapDelay = t.tapDelay || 200, this.tapTimeout = t.tapTimeout || 700, !o.notNeeded(e)) {
                for (var i = ["onMouse", "onClick", "onTouchStart", "onTouchMove", "onTouchEnd", "onTouchCancel"], r = 0, a = i.length; r < a; r++) this[i[r]] = l(this[i[r]], this);
                s && (e.addEventListener("mouseover", this.onMouse, !0), e.addEventListener("mousedown", this.onMouse, !0), e.addEventListener("mouseup", this.onMouse, !0)),
                e.addEventListener("click", this.onClick, !0),
                e.addEventListener("touchstart", this.onTouchStart, !1),
                e.addEventListener("touchmove", this.onTouchMove, !1),
                e.addEventListener("touchend", this.onTouchEnd, !1),
                e.addEventListener("touchcancel", this.onTouchCancel, !1),
                Event.prototype.stopImmediatePropagation || (e.removeEventListener = function(t, n, i) {
                    var o = Node.prototype.removeEventListener;
                    "click" === t ? o.call(e, t, n.hijacked || n, i) : o.call(e, t, n, i)
                },
                e.addEventListener = function(t, n, i) {
                    var o = Node.prototype.addEventListener;
                    "click" === t ? o.call(e, t, n.hijacked || (n.hijacked = function(e) {
                        e.propagationStopped || n(e)
                    }), i) : o.call(e, t, n, i)
                }),
                "function" == typeof e.onclick && (n = e.onclick, e.addEventListener("click",
                function(e) {
                    n(e)
                },
                !1), e.onclick = null)
            }
            function l(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }
        }
        var r = navigator.userAgent.indexOf("Windows Phone") >= 0,
        s = navigator.userAgent.indexOf("Android") > 0 && !r,
        a = /iP(ad|hone|od)/.test(navigator.userAgent) && !r,
        l = a && /OS 4_\d(_\d)?/.test(navigator.userAgent),
        c = a && /OS [6-7]_\d/.test(navigator.userAgent),
        u = navigator.userAgent.indexOf("BB10") > 0;
        o.prototype.needsClick = function(e) {
            switch (e.nodeName.toLowerCase()) {
            case "button":
            case "select":
            case "textarea":
                if (e.disabled) return ! 0;
                break;
            case "input":
                if (a && "file" === e.type || e.disabled) return ! 0;
                break;
            case "label":
            case "iframe":
            case "video":
                return ! 0
            }
            return /\bneedsclick\b/.test(e.className)
        },
        o.prototype.needsFocus = function(e) {
            switch (e.nodeName.toLowerCase()) {
            case "textarea":
                return ! 0;
            case "select":
                return ! s;
            case "input":
                switch (e.type) {
                case "button":
                case "checkbox":
                case "file":
                case "image":
                case "radio":
                case "submit":
                    return ! 1
                }
                return ! e.disabled && !e.readOnly;
            default:
                return /\bneedsfocus\b/.test(e.className)
            }
        },
        o.prototype.sendClick = function(e, t) {
            var n, i;
            document.activeElement && document.activeElement !== e && document.activeElement.blur(),
            i = t.changedTouches[0],
            (n = document.createEvent("MouseEvents")).initMouseEvent(this.determineEventType(e), !0, !0, window, 1, i.screenX, i.screenY, i.clientX, i.clientY, !1, !1, !1, !1, 0, null),
            n.forwardedTouchEvent = !0,
            e.dispatchEvent(n)
        },
        o.prototype.determineEventType = function(e) {
            return s && "select" === e.tagName.toLowerCase() ? "mousedown": "click"
        },
        o.prototype.focus = function(e) {
            var t;
            a && e.setSelectionRange && 0 !== e.type.indexOf("date") && "time" !== e.type && "month" !== e.type && "email" !== e.type ? (t = e.value.length, e.setSelectionRange(t, t)) : e.focus()
        },
        o.prototype.updateScrollParent = function(e) {
            var t, n;
            if (! (t = e.fastClickScrollParent) || !t.contains(e)) {
                n = e;
                do {
                    if (n.scrollHeight > n.offsetHeight) {
                        t = n,
                        e.fastClickScrollParent = n;
                        break
                    }
                    n = n.parentElement
                } while ( n )
            }
            t && (t.fastClickLastScrollTop = t.scrollTop)
        },
        o.prototype.getTargetElementFromEventTarget = function(e) {
            return e.nodeType === Node.TEXT_NODE ? e.parentNode: window.SVGElementInstance && e instanceof SVGElementInstance ? e.correspondingUseElement: e
        },
        o.prototype.onTouchStart = function(e) {
            var t, n, i;
            if (e.targetTouches.length > 1) return ! 0;
            if (t = this.getTargetElementFromEventTarget(e.target), n = e.targetTouches[0], a) {
                if ((i = window.getSelection()).rangeCount && !i.isCollapsed) return ! 0;
                if (!l) {
                    if (n.identifier && n.identifier === this.lastTouchIdentifier) return e.preventDefault(),
                    !1;
                    this.lastTouchIdentifier = n.identifier,
                    this.updateScrollParent(t)
                }
            }
            return this.trackingClick = !0,
            this.trackingClickStart = e.timeStamp,
            this.targetElement = t,
            this.touchStartX = n.pageX,
            this.touchStartY = n.pageY,
            e.timeStamp - this.lastClickTime < this.tapDelay && e.preventDefault(),
            !0
        },
        o.prototype.touchHasMoved = function(e) {
            var t = e.changedTouches[0],
            n = this.touchBoundary;
            return Math.abs(t.pageX - this.touchStartX) > n || Math.abs(t.pageY - this.touchStartY) > n
        },
        o.prototype.onTouchMove = function(e) {
            return ! this.trackingClick || ((this.targetElement !== this.getTargetElementFromEventTarget(e.target) || this.touchHasMoved(e)) && (this.trackingClick = !1, this.targetElement = null), !0)
        },
        o.prototype.findControl = function(e) {
            return void 0 !== e.control ? e.control: e.htmlFor ? document.getElementById(e.htmlFor) : e.querySelector("button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea")
        },
        o.prototype.onTouchEnd = function(e) {
            var t, n, i, o, r, u = this.targetElement;
            if (!this.trackingClick) return ! 0;
            if (e.timeStamp - this.lastClickTime < this.tapDelay) return this.cancelNextClick = !0,
            !0;
            if (e.timeStamp - this.trackingClickStart > this.tapTimeout) return ! 0;
            if (this.cancelNextClick = !1, this.lastClickTime = e.timeStamp, n = this.trackingClickStart, this.trackingClick = !1, this.trackingClickStart = 0, c && (r = e.changedTouches[0], (u = document.elementFromPoint(r.pageX - window.pageXOffset, r.pageY - window.pageYOffset) || u).fastClickScrollParent = this.targetElement.fastClickScrollParent), "label" === (i = u.tagName.toLowerCase())) {
                if (t = this.findControl(u)) {
                    if (this.focus(u), s) return ! 1;
                    u = t
                }
            } else if (this.needsFocus(u)) return e.timeStamp - n > 100 || a && window.top !== window && "input" === i ? (this.targetElement = null, !1) : (this.focus(u), this.sendClick(u, e), a && "select" === i || (this.targetElement = null, e.preventDefault()), !1);
            return ! (!a || l || !(o = u.fastClickScrollParent) || o.fastClickLastScrollTop === o.scrollTop) || (this.needsClick(u) || (e.preventDefault(), this.sendClick(u, e)), !1)
        },
        o.prototype.onTouchCancel = function() {
            this.trackingClick = !1,
            this.targetElement = null
        },
        o.prototype.onMouse = function(e) {
            return ! this.targetElement || ( !! e.forwardedTouchEvent || (!e.cancelable || (!(!this.needsClick(this.targetElement) || this.cancelNextClick) || (e.stopImmediatePropagation ? e.stopImmediatePropagation() : e.propagationStopped = !0, e.stopPropagation(), e.preventDefault(), !1))))
        },
        o.prototype.onClick = function(e) {
            var t;
            return this.trackingClick ? (this.targetElement = null, this.trackingClick = !1, !0) : "submit" === e.target.type && 0 === e.detail || ((t = this.onMouse(e)) || (this.targetElement = null), t)
        },
        o.prototype.destroy = function() {
            var e = this.layer;
            s && (e.removeEventListener("mouseover", this.onMouse, !0), e.removeEventListener("mousedown", this.onMouse, !0), e.removeEventListener("mouseup", this.onMouse, !0)),
            e.removeEventListener("click", this.onClick, !0),
            e.removeEventListener("touchstart", this.onTouchStart, !1),
            e.removeEventListener("touchmove", this.onTouchMove, !1),
            e.removeEventListener("touchend", this.onTouchEnd, !1),
            e.removeEventListener("touchcancel", this.onTouchCancel, !1)
        },
        o.notNeeded = function(e) {
            var t, n, i;
            if (void 0 === window.ontouchstart) return ! 0;
            if (n = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1]) {
                if (!s) return ! 0;
                if ((t = document.querySelector("meta[name=viewport]")) && n > 31) return ! 0
            }
            if (u && (i = navigator.userAgent.match(/Version\/([0-9]*)\.([0-9]*)/))[1] >= 10 && i[2] >= 3 && (t = document.querySelector("meta[name=viewport]"))) {
                if ( - 1 !== t.content.indexOf("user-scalable=no")) return ! 0;
                if (document.documentElement.scrollWidth <= window.outerWidth) return ! 0
            }
            return "none" === e.style.msTouchAction || "manipulation" === e.style.touchAction || ( !! ( + (/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1] >= 27 && (t = document.querySelector("meta[name=viewport]")) && ( - 1 !== t.content.indexOf("user-scalable=no") || document.documentElement.scrollWidth <= window.outerWidth)) || ("none" === e.style.touchAction || "manipulation" === e.style.touchAction))
        },
        o.attach = function(e, t) {
            return new o(e, t)
        },
        void 0 === (i = function() {
            return o
        }.call(t, n, t, e)) || (e.exports = i)
    } ()
},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.PrivacyIcons = window.vungle.templates.PrivacyIcons || {},
    window.vungle.templates.PrivacyIcons.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            var r;
            return '<div id="privacy-icons" style="display: none;" data-hbs-name="PrivacyIcons" >\n  <svg aria-hidden="true" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n    <defs>\n\n      <symbol id="lock-icon" class="' + e.escapeExpression("function" == typeof(r = null != (r = n.THEME || (null != t ? t.THEME: t)) ? r: n.helperMissing) ? r.call(null != t ? t: e.nullContext || {},
            {
                name: "THEME",
                hash: {},
                data: o
            }) : r) + '" viewBox="0 0 390 390" style="enable-background:new 0 0 390 390;" xml:space="preserve">\n      <title>lock-icon</title>\n      <path class="st1" d="M195,369.5C50.8,317.6,53,198.4,54.8,102.5c0.2-9.2,0.3-17.9,0.4-26.5c57.6-0.7,102.2-18,139.8-54.3\n          C232.5,58,277.1,75.3,334.8,76c0,8.5,0.2,17.3,0.4,26.5C337,198.4,339.2,317.6,195,369.5z M177.8,289.4h34.4l0.9-2.3\n        l60.7-166.8h-36.9L195,235.1l-41.8-114.8h-37L177.8,289.4z"/>\n      </symbol>\n\n      <symbol id="privacy-icon" viewBox="0 0 194.818 194.818" style="enable-background:new 0 0 194.818 194.818;" xml:space="preserve">\n      <title>privacy-icon</title>\n      <style>\n        .external-path {\n            fill: #909090;\n        }\n      </style>\n      <path class="external-path" d="M185.818,2.161h-57.04c-4.971,0-9,4.029-9,9s4.029,9,9,9h35.312l-86.3,86.3c-3.515,3.515-3.515,9.213,0,12.728\n          c1.758,1.757,4.061,2.636,6.364,2.636s4.606-0.879,6.364-2.636l86.3-86.3v35.313c0,4.971,4.029,9,9,9s9-4.029,9-9v-57.04\n          C194.818,6.19,190.789,2.161,185.818,2.161z"/>\n      <path class="external-path" d="M149,77.201c-4.971,0-9,4.029-9,9v88.456H18v-122h93.778c4.971,0,9-4.029,9-9s-4.029-9-9-9H9c-4.971,0-9,4.029-9,9v140\n          c0,4.971,4.029,9,9,9h140c4.971,0,9-4.029,9-9V86.201C158,81.23,153.971,77.201,149,77.201z"/>\n      </symbol>\n\n      <symbol id="privacy-close-icon" viewBox="0 0 552 551" enable-background="new 0 0 552 551" xml:space="preserve">\n      <title>privacy-close-icon</title>\n      <path fill="#FFFFFF" d="M468.9,81.3c53.8,53.4,80.7,118,80.7,193.6c0,75.6-26.7,140.1-80.1,193.6c-53.4,53.4-118,80.1-193.6,80.1\n            c-75.6,0-140.1-26.7-193.6-80.1S2.2,350.5,2.2,274.8c0-75.6,26.7-140.1,80.1-193.6C135.8,27.9,200.3,1.2,275.9,1.2\n            C350.7,1.2,415.1,27.9,468.9,81.3z M510.3,274.8c0-64.7-22.9-120.1-68.7-166.3c-45.8-46.2-101.1-69.2-165.7-69.2\n            c-64.7,0-120.1,23.1-166.3,69.2c-46.2,46.2-69.2,101.6-69.2,166.3c0,64.7,23.1,120.1,69.2,166.3c46.2,46.2,101.6,69.2,166.3,69.2\n            c64.7,0,119.9-23.1,165.7-69.2C487.4,395,510.3,339.6,510.3,274.8z M416.5,161.4L303.1,274.8l113.4,113.4l-27.3,27.3L275.9,302.1\n            L161.4,415.5l-27.3-27.3l114.5-113.4L134.1,161.4l27.3-27.3l114.5,113.4l113.4-113.4L416.5,161.4z"/>\n      </symbol>\n\n    </defs>\n  </svg>\n</div>'
        },
        useData: !0
    })
},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.DownloadIcons = window.vungle.templates.DownloadIcons || {},
    window.vungle.templates.DownloadIcons.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            return '<div id="download-icons" style="display: none;" data-hbs-name="DownloadIcons" >\n  <svg aria-hidden="true" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n    <defs>\n\n      <symbol id="cta-icon-down" enable-background="new 0 0 129 129">\n      <title>cta-icon-down</title>\n      <path class="fill" d="m121.3,34.6c-1.6-1.6-4.2-1.6-5.8,0l-51,51.1-51.1-51.1c-1.6-1.6-4.2-1.6-5.8,0-1.6,1.6-1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2 1,0 2.1-0.4 2.9-1.2l53.9-53.9c1.7-1.6 1.7-4.2 0.1-5.8z"/>\n      </symbol>\n\n      <symbol id="cta-icon-download" viewBox="0 0 471.2 471.2" style="enable-background:new 0 0 471.2 471.2;" xml:space="preserve">\n      <title>cta-icon-download</title>\n      <style type="text/css">\n          .svg-cta {\n              fill: #fff;\n          }\n      </style>\n      <path class="svg-cta" d="M457.7,230.15c-7.5,0-13.5,6-13.5,13.5v122.8c0,33.4-27.2,60.5-60.5,60.5H87.5c-33.4,0-60.5-27.2-60.5-60.5v-124.8\t\t\tc0-7.5-6-13.5-13.5-13.5s-13.5,6-13.5,13.5v124.8c0,48.3,39.3,87.5,87.5,87.5h296.2c48.3,0,87.5-39.3,87.5-87.5v-122.8\t\t\tC471.2,236.25,465.2,230.15,457.7,230.15z"/>\n      <path class="svg-cta" d="M226.1,346.75c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4l85.8-85.8c5.3-5.3,5.3-13.8,0-19.1c-5.3-5.3-13.8-5.3-19.1,0l-62.7,62.8\t\t\tV30.75c0-7.5-6-13.5-13.5-13.5s-13.5,6-13.5,13.5v273.9l-62.8-62.8c-5.3-5.3-13.8-5.3-19.1,0c-5.3,5.3-5.3,13.8,0,19.1\t\t\tL226.1,346.75z"/>\n      </symbol>\n\n      <symbol id="cta-icon-download-square" viewBox="0 0 454 522" enable-background="new 0 0 454 522">\n      <title>cta-icon-download-square</title>\n      <style>\n        .cls-01 {\n          fill: #fff;\n          stroke: #6C6C6C;\n          stroke-width: 6;\n          stroke-miterlimit: 10;\n        }\n      </style>\n      <path class="cls-01" d="M190,354.2L34.7,198.8L72,161.5l128.7,128.7V6.5\n            H254v283.7l128.7-128.7l37.3,37.3L264.7,354.2l-37.3,37.3L190,354.2z M448,391.4h-56v67H62.7v-67h-56v123.1H448V391.4L448,391.4z"/>\n      </symbol>\n\n      <symbol id="cta-icon-external"  viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">\n      <title>cta-icon-external</title>\n      <path d="M412.88,261.464c-11.423,0-20.682,9.259-20.682,20.682v156.879c0,17.43-14.181,31.611-31.612,31.611H72.975\t\t\tc-17.43,0-31.611-14.181-31.611-31.611V151.414c0-17.43,14.181-31.611,31.611-31.611h156.879c11.422,0,20.682-9.26,20.682-20.682\t\t\tc0-11.422-9.26-20.682-20.682-20.682H72.975C32.737,78.439,0,111.176,0,151.414v287.611C0,479.264,32.737,512,72.975,512h287.61\t\t\tc40.239,0,72.976-32.736,72.977-72.975V282.146C433.562,270.723,424.303,261.464,412.88,261.464z"/>\n      <path d="M491.318,0H334.439c-11.423,0-20.682,9.26-20.682,20.682c0,11.422,9.259,20.682,20.682,20.682h136.197v136.197\t\t\tc0,11.422,9.259,20.682,20.682,20.682c11.423,0,20.682-9.26,20.682-20.682V20.682C512,9.26,502.741,0,491.318,0z"/>\n       <path d="M505.942,6.058c-8.077-8.076-21.172-8.076-29.249,0L189.082,293.668c-8.077,8.077-8.077,21.172,0,29.249\t\t\tc4.038,4.039,9.332,6.058,14.625,6.058c5.294,0,10.587-2.02,14.625-6.058L505.942,35.307 C514.019,27.23,514.019,14.135,505.942,6.058z"/>\n      </symbol>\n\n      <symbol id="cta-icon-right" viewBox="0 0 32 32">\n      <title>cta-icon-right</title>\n      <path d="M10.022 30.090c-0.198 0.198-0.447 0.298-0.719 0.298s-0.521-0.099-0.719-0.298c-0.397-0.397-0.397-1.042 0-1.439l12.651-12.651-12.651-12.651c-0.397-0.397-0.397-1.042 0-1.439s1.042-0.397 1.439 0l13.371 13.371c0.397 0.397 0.397 1.042 0 1.439l-13.371 13.371z"></path>\n      </symbol>\n\n      <symbol id="cancel-download" viewBox="0 0 38 38" style="enable-background:new 0 0 37.1 38;" xml:space="preserve">\n      <title>cancel-download</title>\n        <style type="text/css">\n          .cd0 { fill: #fff; }\n          .cd1 { fill: #47adf5; }\n        </style>\n        <circle class="cd0" cx="18.5" cy="19" r="17"/>\n        <path class="cd1" d="M26.2,11.4c-0.4-0.4-0.9-0.4-1.2,0l-6.4,6.4l-6.4-6.4c-0.4-0.4-0.9-0.4-1.2,0c-0.4,0.4-0.4,0.9,0,1.2l6.4,6.4\n          l-6.4,6.4c-0.4,0.4-0.4,0.9,0,1.2c0.2,0.2,0.4,0.3,0.6,0.3c0.2,0,0.4-0.1,0.6-0.3l6.4-6.4l6.4,6.4c0.2,0.2,0.4,0.3,0.6,0.3\n          s0.4-0.1,0.6-0.3c0.4-0.4,0.4-0.9,0-1.2L19.8,19l6.4-6.4C26.5,12.2,26.5,11.7,26.2,11.4z"/>\n        <path class="cd1" d="M18.5,0.6C8.4,0.6,0.1,8.8,0.1,19s8.3,18.4,18.4,18.4S37,29.2,37,19S28.7,0.6,18.5,0.6z M18.5,35.7\n          C9.3,35.7,1.9,28.2,1.9,19S9.3,2.3,18.5,2.3S35.2,9.8,35.2,19S27.8,35.7,18.5,35.7z"/>\n      </symbol>\n\n      <symbol id="cancel-install" viewBox="0 0 38 38" style="enable-background:new 0 0 37.1 38;" xml:space="preserve">\n      <title>cancel-install</title>\n        <style type="text/css">\n          .ci0 { fill: #d2d2d2; }\n          .cd1 { fill: #47adf5; }\n        </style>\n        <circle class="ci0" cx="18.5" cy="19" r="17"/>\n         <path class="ci1" d="M26.2,11.4c-0.4-0.4-0.9-0.4-1.2,0l-6.4,6.4l-6.4-6.4c-0.4-0.4-0.9-0.4-1.2,0c-0.4,0.4-0.4,0.9,0,1.2l6.4,6.4\n            l-6.4,6.4c-0.4,0.4-0.4,0.9,0,1.2c0.2,0.2,0.4,0.3,0.6,0.3c0.2,0,0.4-0.1,0.6-0.3l6.4-6.4l6.4,6.4c0.2,0.2,0.4,0.3,0.6,0.3\n            s0.4-0.1,0.6-0.3c0.4-0.4,0.4-0.9,0-1.2L19.8,19l6.4-6.4C26.5,12.2,26.5,11.7,26.2,11.4z"/>\n          <path class="ci1" d="M18.5,0.6C8.4,0.6,0.1,8.8,0.1,19s8.3,18.4,18.4,18.4S37,29.2,37,19S28.7,0.6,18.5,0.6z M18.5,35.7\n            C9.3,35.7,1.9,28.2,1.9,19S9.3,2.3,18.5,2.3S35.2,9.8,35.2,19S27.8,35.7,18.5,35.7z"/>\n      </symbol>\n\n    </defs>\n  </svg>\n</div>'
        },
        useData: !0
    })
},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.SoundIcons = window.vungle.templates.SoundIcons || {},
    window.vungle.templates.SoundIcons.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            return '<div id="sound-icons" style="display: none;" data-hbs-name="SoundIcons" >\n  <svg aria-hidden="true" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n    <defs>\n\n      <symbol id="mute-video" viewBox="0 0 500 500">\n      <title>mute-video</title>\n      <style>\n        .st01{opacity:.8}\n        .st11,.st21{fill:#fff}\n        .st21{display:none}\n      </style>\n      <circle class="st01" cx="249.9" cy="249.9" r="247"/>\n      <path class="st11" d="M418.9 195.8c-3.2-3.2-8.2-3.2-11.4 0l-45.6 45.6-45.6-45.6c-3.2-3.2-8.2-3.2-11.4 0-3.2 3.2-3.2 8.2 0 11.4l45.6 45.6-45.6 45.6c-3.2 3.2-3.2 8.2 0 11.4 1.8 1.8 4.1 2.3 5.9 2.3s4.1-.9 5.9-2.3l45.6-45.6 45.6 45.6c1.8 1.8 4.1 2.3 5.9 2.3s4.1-.9 5.9-2.3c3.2-3.2 3.2-8.2 0-11.4l-45.6-45.6 45.6-45.6c2.9-2.3 2.9-8.2-.8-11.4zM268.2 89.2c-2.3-1.7-6.8-.9-9.1.9l-106.7 79.5H95.2c-5 0-8.2 2.9-8.2 7.6v144c0 4.6 3.2 7.6 8.2 7.6h57.2l106.7 80c1.8.9 3.2 1.7 5 1.7.9 0 2.3 0 3.2-.9 2.3-1.7 5-3.8 5-6.8V95.5c.9-1.7-.9-4.6-4.1-6.3zM148.2 314h-44.8V186.1h44.8V314zm108.5 72.9l-92.1-69v-136l91.7-69v274h.4z"/>\n      <path class="st21" d="M268.5 89c-2.3-1.7-6.8-.9-9.2.9l-107 79.9H94.9c-5 0-8.2 3-8.2 7.7V322c0 4.6 3.2 7.7 8.2 7.7h57.4L259.4 410c1.8.9 3.2 1.7 5 1.7.9 0 2.3 0 3.2-.9 2.3-1.7 5-3.8 5-6.8V95.3c1-1.7-.8-4.6-4.1-6.3zM148.2 314.6h-44.9V186.2h44.9v128.4zm108.9 73.1l-92.4-69.3V182l92-69.2v274.9h.4zm149-127.2h-90.5c-4.2 0-7.7-3.5-7.7-7.9s3.4-7.9 7.7-7.9h90.5c4.2 0 7.7 3.5 7.7 7.9s-3.4 7.9-7.7 7.9zm.9-94.6l-88.6 37.6c-3.9 1.6-8.4-.3-10-4.3-1.6-4 .3-8.6 4.1-10.2l88.6-37.6c3.9-1.6 8.4.3 10 4.3 1.6 3.9-.2 8.6-4.1 10.2zm4.7 182.9c-1.6 4-6.1 5.9-10 4.3l-88.6-37.6c-3.9-1.6-5.8-6.2-4.1-10.2 1.6-4 6.1-5.9 10-4.3l88.6 37.6c3.9 1.6 5.8 6.2 4.1 10.2z"/>\n      </symbol>\n\n      <symbol id="unmute-video" viewBox="0 0 500 500">\n      <title>unmute-video</title>\n      <style>\n        .st01{opacity:.8}\n        .st31{display:none}\n        .st31,.st41{fill:#fff}\n      </style>\n      <circle class="st01" cx="249.9" cy="249.9" r="247"/>\n      <path class="st31" d="M418.9 195.8c-3.2-3.2-8.2-3.2-11.4 0l-45.6 45.6-45.6-45.6c-3.2-3.2-8.2-3.2-11.4 0-3.2 3.2-3.2 8.2 0 11.4l45.6 45.6-45.6 45.6c-3.2 3.2-3.2 8.2 0 11.4 1.8 1.8 4.1 2.3 5.9 2.3s4.1-.9 5.9-2.3l45.6-45.6 45.6 45.6c1.8 1.8 4.1 2.3 5.9 2.3s4.1-.9 5.9-2.3c3.2-3.2 3.2-8.2 0-11.4l-45.6-45.6 45.6-45.6c2.9-2.3 2.9-8.2-.8-11.4zM268.2 89.2c-2.3-1.7-6.8-.9-9.1.9l-106.7 79.5H95.2c-5 0-8.2 2.9-8.2 7.6v144c0 4.6 3.2 7.6 8.2 7.6h57.2l106.7 80c1.8.9 3.2 1.7 5 1.7.9 0 2.3 0 3.2-.9 2.3-1.7 5-3.8 5-6.8V95.5c.9-1.7-.9-4.6-4.1-6.3zM148.2 314h-44.8V186.1h44.8V314zm108.5 72.9l-92.1-69v-136l91.7-69v274h.4z"/>\n      <path class="st41" d="M268.5 89c-2.3-1.7-6.8-.9-9.2.9l-107 79.9H94.9c-5 0-8.2 3-8.2 7.7V322c0 4.6 3.2 7.7 8.2 7.7h57.4L259.4 410c1.8.9 3.2 1.7 5 1.7.9 0 2.3 0 3.2-.9 2.3-1.7 5-3.8 5-6.8V95.3c1-1.7-.8-4.6-4.1-6.3zM148.2 314.6h-44.9V186.2h44.9v128.4zm108.9 73.1l-92.4-69.3V182l92-69.2v274.9h.4zm149-127.2h-90.5c-4.2 0-7.7-3.5-7.7-7.9s3.4-7.9 7.7-7.9h90.5c4.2 0 7.7 3.5 7.7 7.9s-3.4 7.9-7.7 7.9zm.9-94.6l-88.6 37.6c-3.9 1.6-8.4-.3-10-4.3-1.6-4 .3-8.6 4.1-10.2l88.6-37.6c3.9-1.6 8.4.3 10 4.3 1.6 3.9-.2 8.6-4.1 10.2zm4.7 182.9c-1.6 4-6.1 5.9-10 4.3l-88.6-37.6c-3.9-1.6-5.8-6.2-4.1-10.2 1.6-4 6.1-5.9 10-4.3l88.6 37.6c3.9 1.6 5.8 6.2 4.1 10.2z"/>\n      </symbol>\n\n      <symbol id="dialog-replay-icon" viewBox="0 0 232 216">\n      <title>dialog-replay-icon</title>\n      <style>\n        .cls-02 {\n          fill: #fff;\n        }\n      </style>\n      <path class="cls-02" d="M124,1.6c-41.1,0-78.5,23.7-96.1,60.7L5.8,56.9l16.6,56.6l40.7-42.6l-20.2-4.9C58.5,35.8,89.7,16.6,124,16.6\n            c50.4,0,91.4,41,91.4,91.4c0,50.4-41,91.4-91.4,91.4c-24.4,0-47.3-9.5-64.6-26.8l-10.6,10.6c20.1,20.1,46.8,31.2,75.2,31.2\n            c58.7,0,106.4-47.7,106.4-106.4S182.7,1.6,124,1.6z"/>\n      </symbol>\n\n    </defs>\n  </svg>\n</div>'
        },
        useData: !0
    })
},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.CloseIcons = window.vungle.templates.CloseIcons || {},
    window.vungle.templates.CloseIcons.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            var r, s = null != t ? t: e.nullContext || {},
            a = n.helperMissing,
            l = "function",
            c = e.escapeExpression;
            return '<div id="close-icons" style="display: none;" data-hbs-name="CloseIcons" >\n  <svg aria-hidden="true" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\n    <defs>\n\n      <symbol id="close-icon" viewBox="0 0 525.4 525.5" style="enable-background:new 0 0 525.4 525.5;" xml:space="preserve">\n      <title>close-icon</title>\n      <polygon class="closeBtn" points="467.6,8.9 262.9,213.6 58.1,8.9 9,58 213.8,262.7 9,467 58.1,516.1 262.9,311.8 467.6,516.1     516.7,467 311.9,262.7 516.7,58"/>\n      </symbol>\n\n      <symbol id="close-icon' + c(typeof(r = null != (r = n.THEME || (null != t ? t.THEME: t)) ? r: a) == l ? r.call(s, {
                name: "THEME",
                hash: {},
                data: o
            }) : r) + '" viewBox="0 0 525.4 525.5" style="enable-background:new 0 0 525.4 525.5;" xml:space="preserve">\n      <title>close-icon</title>\n      <polygon class="closeBtn' + c(typeof(r = null != (r = n.THEME || (null != t ? t.THEME: t)) ? r: a) == l ? r.call(s, {
                name: "THEME",
                hash: {},
                data: o
            }) : r) + '" points="467.6,8.9 262.9,213.6 58.1,8.9 9,58 213.8,262.7 9,467 58.1,516.1 262.9,311.8 467.6,516.1     516.7,467 311.9,262.7 516.7,58"/>\n      </symbol>\n\n      <symbol id="close-outline-icon" viewBox="0 0 990.5 990" style="enable-background:new 0 0 990.5 990;" xml:space="preserve">\n      <title>close-outline-icon</title>\n      <style type="text/css">\n          .svg-close-background-light {\n            fill: rgba(255,255,255,0.7);\n          }\n          .svg-close-background-dark {\n            fill: rgba(0,0,0,0.7);\n        }\n          .svg-close-icon,\n          .svg-close-icondark {\n              fill: #ffffff;\n          }\n            .svg-close-iconlight {\n              fill: #1d1d1d;\n            }\n        </style>\n        <path class="svg-close-background-' + c(typeof(r = null != (r = n.THEME || (null != t ? t.THEME: t)) ? r: a) == l ? r.call(s, {
                name: "THEME",
                hash: {},
                data: o
            }) : r) + '" d="M195.9-0.7h-9.7H2.8c133.3,0,169.7,95.2,179.6,147.2v474.3c0,62.9,31.6,118.3,79.8,151.3c30.2,21.8,67.2,34.7,107.3,34.7\n            h466.9C886.7,815,990,848.7,990,987.6V806.8h0.5l0-807.5H195.9z"/>\n        <polygon class="svg-close-icon svg-close-icon' + c(typeof(r = null != (r = n.THEME || (null != t ? t.THEME: t)) ? r: a) == l ? r.call(s, {
                name: "THEME",
                hash: {},
                data: o
            }) : r) + '" points="780.4,643.8 587.1,450.6 392.3,643.8 345.9,597.5 540.8,402.6 345.9,209.3 392.3,162.9 587.1,356.2 780.4,162.9 826.8,209.3 633.5,402.6 826.8,597.5">\n        </polygon>\n        </symbol>\n\n    </defs>\n  </svg>\n</div>'
        },
        useData: !0
    })
},
function(e, t, n) {},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.DialogBox = window.vungle.templates.DialogBox || {},
    window.vungle.templates.DialogBox.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            return '<div id="DIALOGBOX" data-hbs-name="DialogBox">\n    <div class="dialog">\n        <div class="dialog-content">\n            <div class="title-text"></div>\n            <div class="body-text-container">\n                <div class="body-text"></div>\n            </div>\n            <div class="action-buttons">\n                <div class="primary-button">\n                    <button class="primary" data-vgl-tabindex="1"></button>\n                </div>\n                <div class="secondary-button">\n                    <button class="secondary" data-vgl-tabindex="2"></button>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n'
        },
        useData: !0
    })
},
function(e, t, n) {},
function(e, t) {
    var n, i, o = e.exports = {};
    function r() {
        throw new Error("setTimeout has not been defined")
    }
    function s() {
        throw new Error("clearTimeout has not been defined")
    }
    function a(e) {
        if (n === setTimeout) return setTimeout(e, 0);
        if ((n === r || !n) && setTimeout) return n = setTimeout,
        setTimeout(e, 0);
        try {
            return n(e, 0)
        } catch(t) {
            try {
                return n.call(null, e, 0)
            } catch(t) {
                return n.call(this, e, 0)
            }
        }
    } !
    function() {
        try {
            n = "function" == typeof setTimeout ? setTimeout: r
        } catch(e) {
            n = r
        }
        try {
            i = "function" == typeof clearTimeout ? clearTimeout: s
        } catch(e) {
            i = s
        }
    } ();
    var l, c = [],
    u = !1,
    h = -1;
    function d() {
        u && l && (u = !1, l.length ? c = l.concat(c) : h = -1, c.length && p())
    }
    function p() {
        if (!u) {
            var e = a(d);
            u = !0;
            for (var t = c.length; t;) {
                for (l = c, c = []; ++h < t;) l && l[h].run();
                h = -1,
                t = c.length
            }
            l = null,
            u = !1,
            function(e) {
                if (i === clearTimeout) return clearTimeout(e);
                if ((i === s || !i) && clearTimeout) return i = clearTimeout,
                clearTimeout(e);
                try {
                    i(e)
                } catch(t) {
                    try {
                        return i.call(null, e)
                    } catch(t) {
                        return i.call(this, e)
                    }
                }
            } (e)
        }
    }
    function f(e, t) {
        this.fun = e,
        this.array = t
    }
    function v() {}
    o.nextTick = function(e) {
        var t = new Array(arguments.length - 1);
        if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
        c.push(new f(e, t)),
        1 !== c.length || u || a(p)
    },
    f.prototype.run = function() {
        this.fun.apply(null, this.array)
    },
    o.title = "browser",
    o.browser = !0,
    o.env = {},
    o.argv = [],
    o.version = "",
    o.versions = {},
    o.on = v,
    o.addListener = v,
    o.once = v,
    o.off = v,
    o.removeListener = v,
    o.removeAllListeners = v,
    o.emit = v,
    o.prependListener = v,
    o.prependOnceListener = v,
    o.listeners = function(e) {
        return []
    },
    o.binding = function(e) {
        throw new Error("process.binding is not supported")
    },
    o.cwd = function() {
        return "/"
    },
    o.chdir = function(e) {
        throw new Error("process.chdir is not supported")
    },
    o.umask = function() {
        return 0
    }
},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.GDPRDialogBox = window.vungle.templates.GDPRDialogBox || {},
    window.vungle.templates.GDPRDialogBox.template = Handlebars.template({
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            return '<div id="GDPRDialogBox" data-hbs-name="GDPRDialogBox">\n    <div class="dialog">\n        <div class="dialog-content">\n            <div class="app-icon">\n                <svg data-vgl-gesture="GDPR-icon">\n                    <use xlink:href="#GDPR-icon"></use>\n                </svg>\n            </div>\n            <div class="title-text"></div>\n            <div class="body-text"></div>\n        </div>\n    </div>\n\n    <div class="cta">\n        <div class="cta-content">\n            <div class="consent-button">\n                <button data-vgl-tabindex="1" class="consent"></button>\n            </div>\n            <div class="no-consent-button">\n                <button data-vgl-tabindex="2" class="no-consent"></button>\n            </div>\n        </div>\n    </div>\n</div>\n\n<div id="icons" style="display: none;">\n    <svg version="1.1" id="GDPR-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 96.5 96.6" style="enable-background:new 0 0 96.5 96.6;" xml:space="preserve">\n        <style type="text/css">\n            .st100{fill:#FFFFFF;}\n        </style>\n        <g transform="translate(0,-952.36218)">\n            <path fill="#FFFFFF" class="st100" d="M46.2,953.6v12.1c-17.7,1-31.9,15.2-32.9,32.9H1.2v4h12.1c1,17.7,15.2,31.9,32.9,32.9v12.1h4v-12.1\n                c17.7-1,31.9-15.2,32.9-32.9h12.1v-4H83.2c-1-17.7-15.2-31.9-32.9-32.9v-12.1H46.2z M46.2,969.7v14.1c-7.8,0.9-14,7.1-14.9,14.9\n                H17.3C18.3,983.1,30.7,970.7,46.2,969.7z M50.2,969.7c15.5,1,27.9,13.4,28.9,28.9H65.1c-0.9-7.8-7.1-14-14.9-14.9V969.7z\n                 M40.9,993.3c10.8-8.1,22.8,3.9,14.7,14.7C44.8,1016.1,32.8,1004.1,40.9,993.3z M17.3,1002.6h14.1c0.9,7.8,7.1,14,14.9,14.9v14.1\n                C30.7,1030.6,18.3,1018.2,17.3,1002.6z M65.1,1002.6h14.1c-1,15.5-13.4,28-28.9,28.9v-14.1C58,1016.6,64.2,1010.4,65.1,1002.6z"></path>\n        </g>\n    </svg>\n</div>\n'
        },
        useData: !0
    })
},
function(e, t, n) {},
function(e, t, n) {},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.Video = window.vungle.templates.Video || {},
    window.vungle.templates.Video.template = Handlebars.template({
        1 : function(e, t, n, i, o) {
            return "hide"
        },
        3 : function(e, t, n, i, o) {
            var r;
            return 'data-vgl-delay-show="' + e.escapeExpression("function" == typeof(r = null != (r = n.DOWNLOAD_BUTTON_DELAY_SECONDS || (null != t ? t.DOWNLOAD_BUTTON_DELAY_SECONDS: t)) ? r: n.helperMissing) ? r.call(null != t ? t: e.nullContext || {},
            {
                name: "DOWNLOAD_BUTTON_DELAY_SECONDS",
                hash: {},
                data: o
            }) : r) + '"'
        },
        5 : function(e, t, n, i, o) {
            return " hide"
        },
        7 : function(e, t, n, i, o) {
            var r, s = null != t ? t: e.nullContext || {},
            a = n.helperMissing,
            l = "function",
            c = e.escapeExpression;
            return 'data-vgl-delay-show="' + c(typeof(r = null != (r = n.DOWNLOAD_BUTTON_DELAY_SECONDS || (null != t ? t.DOWNLOAD_BUTTON_DELAY_SECONDS: t)) ? r: a) == l ? r.call(s, {
                name: "DOWNLOAD_BUTTON_DELAY_SECONDS",
                hash: {},
                data: o
            }) : r) + '" data-vgl-delay-show-incentivized="' + c(typeof(r = null != (r = n.DOWNLOAD_BUTTON_DELAY_SECONDS || (null != t ? t.DOWNLOAD_BUTTON_DELAY_SECONDS: t)) ? r: a) == l ? r.call(s, {
                name: "DOWNLOAD_BUTTON_DELAY_SECONDS",
                hash: {},
                data: o
            }) : r) + '"'
        },
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            var r, s, a = null != t ? t: e.nullContext || {},
            l = n.helperMissing,
            c = e.escapeExpression,
            u = "function";
            return '<div id="Video" data-hbs-name="Video" data-vgl-page class="row" data-vgl-cta-background-color="' + c((n.i18ns || t && t.i18ns || l).call(a, "CTA_BUTTON_BACKGROUND", null != t ? t.CTA_BUTTON_BACKGROUND: t, {
                name: "i18ns",
                hash: {},
                data: o
            })) + '">\n    <div\n        role="dialog"\n        class="overlay-cta ' + (null != (r = (n.equalDef || t && t.equalDef || l).call(a, null != t ? t.FULL_CTA: t, "false", "false", {
                name: "equalDef",
                hash: {},
                fn: e.program(1, o, 0),
                inverse: e.noop,
                data: o
            })) ? r: "") + '"\n\n        data-vgl-gesture="cta-button"\n        data-vgl-full-cta="' + c(typeof(s = null != (s = n.FULL_CTA || (null != t ? t.FULL_CTA: t)) ? s: l) == u ? s.call(a, {
                name: "FULL_CTA",
                hash: {},
                data: o
            }) : s) + '"\n        data-vgl-uri="' + c(typeof(s = null != (s = n.CTA_BUTTON_URL || (null != t ? t.CTA_BUTTON_URL: t)) ? s: l) == u ? s.call(a, {
                name: "CTA_BUTTON_URL",
                hash: {},
                data: o
            }) : s) + '"\n        data-vgl-app-store-id="' + c(typeof(s = null != (s = n.APP_STORE_ID || (null != t ? t.APP_STORE_ID: t)) ? s: l) == u ? s.call(a, {
                name: "APP_STORE_ID",
                hash: {},
                data: o
            }) : s) + '"\n        ' + (null != (r = (n.equalDef || t && t.equalDef || l).call(a, null != t ? t.FULL_CTA: t, "true", "false", {
                name: "equalDef",
                hash: {},
                fn: e.program(3, o, 0),
                inverse: e.noop,
                data: o
            })) ? r: "") + '>\n    </div>\n    <div class="content small-12 columns">\n        <div class="header row">\n            <div class="close" data-vgl-delay-show="' + c(typeof(s = null != (s = n.CLOSE_BUTTON_DELAY_SECONDS || (null != t ? t.CLOSE_BUTTON_DELAY_SECONDS: t)) ? s: l) == u ? s.call(a, {
                name: "CLOSE_BUTTON_DELAY_SECONDS",
                hash: {},
                data: o
            }) : s) + '" data-vgl-delay-show-incentivized="' + c(typeof(s = null != (s = n.INCENTIVIZED_CLOSE_BUTTON_DELAY_SECONDS || (null != t ? t.INCENTIVIZED_CLOSE_BUTTON_DELAY_SECONDS: t)) ? s: l) == u ? s.call(a, {
                name: "INCENTIVIZED_CLOSE_BUTTON_DELAY_SECONDS",
                hash: {},
                data: o
            }) : s) + '" data-vgl-tabindex="3">\n                <div class="close-btn-container">\n                    <svg data-vgl-gesture="close-icon" class="close-btn right">\n                        <use xlink:href="#close-icon"></use>\n                    </svg>\n                </div>\n                <span class="close-btn-text">' + c((n.i18nt || t && t.i18nt || l).call(a, "CLOSE_BUTTON_TEXT", "Close", {
                name: "i18nt",
                hash: {},
                data: o
            })) + '</span>\n            </div>\n        </div>\n\n        <div class="video-container">\n            <video autoplay muted class="video row" ad-outlet="video" data-vgl-gesture="video" playsinline webkit-playsinline data-vgl-video-timer="' + c(typeof(s = null != (s = n.VIDEO_PROGRESS_BAR || (null != t ? t.VIDEO_PROGRESS_BAR: t)) ? s: l) == u ? s.call(a, {
                name: "VIDEO_PROGRESS_BAR",
                hash: {},
                data: o
            }) : s) + '">\n                <source src="' + c(typeof(s = null != (s = n.MAIN_VIDEO || (null != t ? t.MAIN_VIDEO: t)) ? s: l) == u ? s.call(a, {
                name: "MAIN_VIDEO",
                hash: {},
                data: o
            }) : s) + '">\n            </video>\n            <div class="mute-icon-container" data-vgl-start-muted=' + c(typeof(s = null != (s = n.START_MUTED || (null != t ? t.START_MUTED: t)) ? s: l) == u ? s.call(a, {
                name: "START_MUTED",
                hash: {},
                data: o
            }) : s) + '>\n                <div class="unmute-video-wrap hidden">\n                    <svg data-vgl-gesture="unmute-video" class="unmute-video">\n                       <use xlink:href="#unmute-video"></use>\n                    </svg>\n                </div>\n                <div class="mute-video-wrap hidden">\n                    <svg data-vgl-gesture="mute-video" class="mute-video">\n                       <use xlink:href="#mute-video"></use>\n                    </svg>\n                </div>\n            </div>\n            <div class="progress-bar" data-vgl-progress-background-color="' + c((n.i18ns || t && t.i18ns || l).call(a, "CTA_BUTTON_BACKGROUND", null != t ? t.CTA_BUTTON_BACKGROUND: t, {
                name: "i18ns",
                hash: {},
                data: o
            })) + '"><span></span></div>\n        </div>\n\n        <div class="footer row small-12 columns">\n            <div class="privacy-button" data-vgl-uri="' + c(typeof(s = null != (s = n.VUNGLE_PRIVACY_URL || (null != t ? t.VUNGLE_PRIVACY_URL: t)) ? s: l) == u ? s.call(a, {
                name: "VUNGLE_PRIVACY_URL",
                hash: {},
                data: o
            }) : s) + '" data-vgl-tabindex="2">\n                <svg data-vgl-gesture="lock-icon" class="lock-icon">\n                    <use xlink:href="#lock-icon"></use>\n                </svg>\n\n                <span>Privacy<svg data-vgl-gesture="privacy-icon" class="privacy-icon">\n                    <use xlink:href="#privacy-icon"></use>\n                </svg></span>\n            </div>\n\n            <div class="download small-6 columns cta-delay-show cta-hard-hide' + (null != (r = (n.equal || t && t.equal || l).call(a, null != t ? t.VIDEO_SHOW_CTA: t, "false", {
                name: "equal",
                hash: {},
                fn: e.program(5, o, 0),
                inverse: e.noop,
                data: o
            })) ? r: "") + '" data-vgl-uri="' + c(typeof(s = null != (s = n.CTA_BUTTON_URL || (null != t ? t.CTA_BUTTON_URL: t)) ? s: l) == u ? s.call(a, {
                name: "CTA_BUTTON_URL",
                hash: {},
                data: o
            }) : s) + '" ' + (null != (r = (n.equal || t && t.equal || l).call(a, null != t ? t.VIDEO_SHOW_CTA: t, "true", {
                name: "equal",
                hash: {},
                fn: e.program(7, o, 0),
                inverse: e.noop,
                data: o
            })) ? r: "") + ' data-vgl-tabindex="1">\n                <span class="cta-button__icon">\n                    <svg data-vgl-gesture="download-icon" class="download-icon">\n                        <use xlink:href="#cta-icon-download-square"></use>\n                    </svg>\n                </span>\n                <span class="cta-button__timer hide"></span>\n            </div>\n        </div>\n    </div>\n</div>\n\n\x3c!-- incentivized dialog box --\x3e\n<script type="text/template" id="incentivized-title-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "INCENTIVIZED_TITLE_TEXT", null != t ? t.INCENTIVIZED_TITLE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '\n<\/script>\n<script type="text/template" id="incentivized-body-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "INCENTIVIZED_BODY_TEXT", null != t ? t.INCENTIVIZED_BODY_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '\n<\/script>\n<script type="text/template" id="incentivized-primary-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "INCENTIVIZED_CONTINUE_TEXT", null != t ? t.INCENTIVIZED_CONTINUE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '&nbsp;<svg class="action-icon"><use xlink:href="#dialog-replay-icon"></use></svg>\n<\/script>\n<script type="text/template" id="incentivized-secondary-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "INCENTIVIZED_CLOSE_TEXT", null != t ? t.INCENTIVIZED_CLOSE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '\n<\/script>\n\n\x3c!-- privacy dialog box --\x3e\n<script type="text/template" id="privacy-body-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_BODY_TEXT", null != t ? t.PRIVACY_BODY_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '\n<\/script>\n<script type="text/template" id="privacy-primary-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_CONTINUE_TEXT", null != t ? t.PRIVACY_CONTINUE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '&nbsp;<svg class="action-icon"><use xlink:href="#privacy-close-icon"></use></svg>\n<\/script>\n<script type="text/template" id="privacy-secondary-text">\n    ' + c((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_CLOSE_TEXT", null != t ? t.PRIVACY_CLOSE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + "\n<\/script>\n"
        },
        useData: !0
    })
},
function(e, t, n) {},
function(e, t) {
    window.vungle = window.vungle || {},
    window.vungle.templates = window.vungle.templates || {},
    window.vungle.templates.ShowcaseNonBrand = window.vungle.templates.ShowcaseNonBrand || {},
    window.vungle.templates.ShowcaseNonBrand.template = Handlebars.template({
        1 : function(e, t, n, i, o) {
            return "hide"
        },
        compiler: [7, ">= 4.0.0"],
        main: function(e, t, n, i, o) {
            var r, s, a = null != t ? t: e.nullContext || {},
            l = n.helperMissing,
            c = "function",
            u = e.escapeExpression;
            return '<div id="ShowcaseNonBrand" data-hbs-name="ShowcaseNonBrand" data-vgl-page class="' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '" data-vgl-cta-background-color="' + u((n.i18ns || t && t.i18ns || l).call(a, "CTA_BUTTON_BACKGROUND", null != t ? t.CTA_BUTTON_BACKGROUND: t, {
                name: "i18ns",
                hash: {},
                data: o
            })) + '" data-vgl-theme="' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '">\n    <div\n        role="dialog"\n        class="overlay-cta ' + (null != (r = (n.equalDef || t && t.equalDef || l).call(a, null != t ? t.FULL_CTA: t, "false", "false", {
                name: "equalDef",
                hash: {},
                fn: e.program(1, o, 0),
                inverse: e.noop,
                data: o
            })) ? r: "") + '"\n\n        data-vgl-gesture="cta-button"\n        data-vgl-full-cta="' + u(typeof(s = null != (s = n.FULL_CTA || (null != t ? t.FULL_CTA: t)) ? s: l) == c ? s.call(a, {
                name: "FULL_CTA",
                hash: {},
                data: o
            }) : s) + '"\n        data-vgl-uri="' + u(typeof(s = null != (s = n.CTA_BUTTON_URL || (null != t ? t.CTA_BUTTON_URL: t)) ? s: l) == c ? s.call(a, {
                name: "CTA_BUTTON_URL",
                hash: {},
                data: o
            }) : s) + '"\n        data-vgl-app-store-id="' + u(typeof(s = null != (s = n.APP_STORE_ID || (null != t ? t.APP_STORE_ID: t)) ? s: l) == c ? s.call(a, {
                name: "APP_STORE_ID",
                hash: {},
                data: o
            }) : s) + '">\n    </div>\n    <div class="creative">\n        <header class="header">\n            <div class="close ' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '" data-vgl-tabindex="3">\n                <div class="close-btn-container">\n                    <svg data-vgl-gesture="close-icon' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '" class="close-btn right">\n                        <use xlink:href="#close-icon' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '"></use>\n                    </svg>\n                </div>\n                <span class="close-btn-text">' + u((n.i18nt || t && t.i18nt || l).call(a, "CLOSE_BUTTON_TEXT", "Close", {
                name: "i18nt",
                hash: {},
                data: o
            })) + '</span>\n            </div>\n        </header>\n\n        <div class="slideshow">\n            <div style="background-image: url(' + u(typeof(s = null != (s = n.CAROUSEL_IMAGE_1 || (null != t ? t.CAROUSEL_IMAGE_1: t)) ? s: l) == c ? s.call(a, {
                name: "CAROUSEL_IMAGE_1",
                hash: {},
                data: o
            }) : s) + ')" class="slideshowImages"></div>\n\n            <div style="background-image: url(' + u(typeof(s = null != (s = n.CAROUSEL_IMAGE_2 || (null != t ? t.CAROUSEL_IMAGE_2: t)) ? s: l) == c ? s.call(a, {
                name: "CAROUSEL_IMAGE_2",
                hash: {},
                data: o
            }) : s) + ')" class="slideshowImages"></div>\n\n            <div style="background-image: url(' + u(typeof(s = null != (s = n.CAROUSEL_IMAGE_3 || (null != t ? t.CAROUSEL_IMAGE_3: t)) ? s: l) == c ? s.call(a, {
                name: "CAROUSEL_IMAGE_3",
                hash: {},
                data: o
            }) : s) + ')" class="slideshowImages"></div>\n\n            <div style="background-image: url(' + u(typeof(s = null != (s = n.CAROUSEL_IMAGE_4 || (null != t ? t.CAROUSEL_IMAGE_4: t)) ? s: l) == c ? s.call(a, {
                name: "CAROUSEL_IMAGE_4",
                hash: {},
                data: o
            }) : s) + ')" class="slideshowImages"></div>\n\n            <div style="background-image: url(' + u(typeof(s = null != (s = n.CAROUSEL_IMAGE_5 || (null != t ? t.CAROUSEL_IMAGE_5: t)) ? s: l) == c ? s.call(a, {
                name: "CAROUSEL_IMAGE_5",
                hash: {},
                data: o
            }) : s) + ')" class="slideshowImages"></div>\n        </div>\n\n        <span id="slideshow-gradient" class="slideshow-gradient ' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '"></span>\n\n        <div class="card-container">\n            <div class="card-positioning ">\n                <div class="card ' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '">\n                    <div class="vertical-centering">\n                        <div class="app-info ' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '">\n                            <div class="app-icon-wrap">\n                                <img data-vgl-gesture="app-icon" class="app-icon radius" data-vgl-uri="' + u(typeof(s = null != (s = n.CTA_BUTTON_URL || (null != t ? t.CTA_BUTTON_URL: t)) ? s: l) == c ? s.call(a, {
                name: "CTA_BUTTON_URL",
                hash: {},
                data: o
            }) : s) + '" src="' + u(typeof(s = null != (s = n.APP_ICON || (null != t ? t.APP_ICON: t)) ? s: l) == c ? s.call(a, {
                name: "APP_ICON",
                hash: {},
                data: o
            }) : s) + '">\n                            </div>\n\n                            <ul class="app-details">\n                                <li class="app-name"><h2 data-vgl-gesture="app-name" class="app-name ellipsis">' + u(typeof(s = null != (s = n.APP_NAME || (null != t ? t.APP_NAME: t)) ? s: l) == c ? s.call(a, {
                name: "APP_NAME",
                hash: {},
                data: o
            }) : s) + '</h2></li>\n                                <li class="pub-name"><h3 data-vgl-gesture="pub-name" class="pub-name ellipsis">' + u(typeof(s = null != (s = n.APP_DESCRIPTION || (null != t ? t.APP_DESCRIPTION: t)) ? s: l) == c ? s.call(a, {
                name: "APP_DESCRIPTION",
                hash: {},
                data: o
            }) : s) + '</h3></li>\n                                <li class="app-rating"><img data-vgl-gesture="app-rating" class="app-rating" src="' + u(typeof(s = null != (s = n.APP_RATING || (null != t ? t.APP_RATING: t)) ? s: l) == c ? s.call(a, {
                name: "APP_RATING",
                hash: {},
                data: o
            }) : s) + '"/></li>\n                            </ul>\n                        </div>\n\n                        <div class="cta-info">\n                            <button data-vgl-gesture="cta-button" class="cta-button cta-hard-hide" data-vgl-uri="' + u(typeof(s = null != (s = n.CTA_BUTTON_URL || (null != t ? t.CTA_BUTTON_URL: t)) ? s: l) == c ? s.call(a, {
                name: "CTA_BUTTON_URL",
                hash: {},
                data: o
            }) : s) + '" data-vgl-tabindex="1">' + u((n.i18nt || t && t.i18nt || l).call(a, "CTA_BUTTON_TEXT", null != t ? t.CTA_BUTTON_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '</button>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class="footer small-12 columns">\n            <div class="privacy-button" data-vgl-uri="' + u(typeof(s = null != (s = n.VUNGLE_PRIVACY_URL || (null != t ? t.VUNGLE_PRIVACY_URL: t)) ? s: l) == c ? s.call(a, {
                name: "VUNGLE_PRIVACY_URL",
                hash: {},
                data: o
            }) : s) + '" data-vgl-tabindex="2">\n                <svg data-vgl-gesture="lock-icon" class="lock-icon ' + u(typeof(s = null != (s = n.THEME || (null != t ? t.THEME: t)) ? s: l) == c ? s.call(a, {
                name: "THEME",
                hash: {},
                data: o
            }) : s) + '">\n                    <use xlink:href="#lock-icon"></use>\n                </svg>\n\n                <span>Privacy<svg data-vgl-gesture="privacy-icon" class="privacy-icon">\n                    <use xlink:href="#privacy-icon"></use>\n                </svg></span>\n            </div>\n        </div>\n    </div>\n</div>\n\n<script type="text/template" id="privacy-body-text">\n    ' + u((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_BODY_TEXT", null != t ? t.PRIVACY_BODY_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '\n<\/script>\n<script type="text/template" id="privacy-primary-text">\n    ' + u((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_CONTINUE_TEXT", null != t ? t.PRIVACY_CONTINUE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + '&nbsp;<svg class="action-icon"><use xlink:href="#privacy-close-icon"></use></svg>\n<\/script>\n<script type="text/template" id="privacy-secondary-text">\n    ' + u((n.i18nt || t && t.i18nt || l).call(a, "PRIVACY_CLOSE_TEXT", null != t ? t.PRIVACY_CLOSE_TEXT: t, {
                name: "i18nt",
                hash: {},
                data: o
            })) + "\n<\/script>\n"
        },
        useData: !0
    })
},
function(e, t, n) {},
function(e, t, n) {
    "use strict";
    n.r(t);
    n(3),
    n(4),
    n(5),
    n(6),
    n(7);
    function i(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var o = "01000101 01000011 01001101 01000001 01010011 01100011 01110010 01101001 01110000 01110100 00100000 00110010 00110000 00110001 00110101",
    r = function() {
        function e(t) {
            if (function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e), t !== o) throw {
                name: "SingletonException",
                message: "Cannot create another UUID singleton object!"
            };
            this.lastGenerated = null
        }
        var t, n, r;
        return t = e,
        r = [{
            key: "instance",
            get: function() {
                return this.singleton || (this.singleton = new e(o)),
                this.singleton
            }
        }],
        (n = [{
            key: "generate",
            value: function() {
                var e = Date.now();
                window.performance && "function" == typeof window.performance.now && (e += performance.now());
                var t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
                function(t) {
                    var n = (e + 16 * Math.random()) % 16 | 0;
                    return e = Math.floor(e / 16),
                    ("x" === t ? n: 3 & n | 8).toString(16)
                });
                return t === this.lastGenerated ? this.generate() : t
            }
        }]) && i(t.prototype, n),
        r && i(t, r),
        e
    } ();
    Function.prototype.uuidBind = function() {
        var e = Function.prototype.bind.apply(this, arguments);
        return e.uuid = r.instance.generate(),
        "_id" in arguments[0] && (e._id = arguments[0]._id),
        this.uuid = e.uuid,
        e
    };
    var s = r;
    function a(e) {
        return function(e) {
            if (Array.isArray(e)) {
                for (var t = 0,
                n = new Array(e.length); t < e.length; t++) n[t] = e[t];
                return n
            }
        } (e) ||
        function(e) {
            if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
        } (e) ||
        function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        } ()
    }
    function l(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var c = "01010110 01110101 01101110 01100111 01101100 01100101 00100000 01001001 01010000 01001111",
    u = function() {
        function e(t) {
            if (function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e), t !== c) throw {
                name: "SingletonException",
                message: "Cannot create another EventBus singleton object!"
            };
            this.listeners = {}
        }
        var t, n, i;
        return t = e,
        i = [{
            key: "instance",
            get: function() {
                return this.singleton || (this.singleton = new e(c)),
                this.singleton
            }
        }],
        (n = [{
            key: "findHandler",
            value: function(t, n) {
                for (var i = -1,
                o = e.instance.listeners[t].length, r = 0; r < o && -1 === i; r++) e.instance.listeners[t][r].uuid === n.uuid && (i = r);
                return i
            }
        },
        {
            key: "subscribe",
            value: function(t, n) {
                return t in e.instance.listeners ? e.instance.listeners[t].push(n) : e.instance.listeners[t] = [n],
                n.uuid
            }
        },
        {
            key: "publish",
            value: function(t, n) {
                if (t in e.instance.listeners) for (var i = e.instance.listeners[t], o = 0; o < i.length; o++)"function" == typeof i[o] && setTimeout(void(0, i[o])(n), 0)
            }
        },
        {
            key: "unsubscribe",
            value: function(t, n) {
                if (t in e.instance.listeners) {
                    var i = this.findHandler(t, n); - 1 !== i && (e.instance.listeners[t].splice(i, 1), 0 === e.instance.listeners[t].length && delete e.instance.listeners[t])
                }
            }
        },
        {
            key: "unsubscribeAll",
            value: function(t) {
                Object.keys(e.instance.listeners).forEach(function(n) {
                    a(e.instance.listeners[n]).forEach(function(i, o) {
                        "_id" in i && i._id === t && e.instance.listeners[n].splice(o, 1)
                    })
                })
            }
        }]) && l(t.prototype, n),
        i && l(t, i),
        e
    } ();
    function h(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var d = function() {
        function e(t) { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e),
            this.eventDispatcher = u.instance,
            this.selector = t,
            this.element = null,
            this.initialized = !1,
            this._id = s.instance.generate()
        }
        var t, n, i;
        return t = e,
        (n = [{
            key: "getElement",
            value: function() {
                return this.element || (this.element = document.querySelector(this.selector)),
                this.element
            }
        },
        {
            key: "init",
            value: function() {
                throw {
                    name: "NoImplException",
                    message: "No init method provided in UIElement derived class!"
                }
            }
        },
        {
            key: "show",
            value: function() {
                this.isVisible() || (this.getElement().style.visibility = "visible")
            }
        },
        {
            key: "hide",
            value: function() {
                this.isVisible() && (this.getElement().style.visibility = "hidden")
            }
        },
        {
            key: "destroy",
            value: function() {}
        },
        {
            key: "isVisible",
            value: function() {
                return "visible" === window.getComputedStyle(this.getElement()).visibility
            }
        },
        {
            key: "pause",
            value: function() {}
        }]) && h(t.prototype, n),
        i && h(t, i),
        e
    } ();
    function p(e) {
        return (p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function f(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function v(e, t) {
        return ! t || "object" !== p(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function y(e) {
        return (y = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function g(e, t) {
        return (g = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var m = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.isIncentivized,
            r = void 0 !== o && o;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = v(this, y(t).call(this, i))).isIncentivized = r,
            n.showDelayMilliseconds = 0,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && g(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getShowDelayMilliseconds",
            value: function() {
                if (!this.showDelayMilliseconds) {
                    var e = this.isIncentivized ? "data-vgl-delay-show-incentivized": "data-vgl-delay-show",
                    t = this.getElement().getAttribute(e);
                    this.showDelayMilliseconds = t ? "9999" !== t ? 1e3 * parseFloat(t) : null: 0
                }
                return this.showDelayMilliseconds
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.getElement().addEventListener("click", this.onClick.bind(this)), this.initialized = !0)
            }
        },
        {
            key: "destroy",
            value: function() {
                this.eventDispatcher.unsubscribeAll(this._id)
            }
        },
        {
            key: "onClick",
            value: function() {
                throw {
                    name: "NoImplException",
                    message: "No onClick method provided in AbstractDelayShowButton derived class!"
                }
            }
        }]) && f(n.prototype, i),
        o && f(n, o),
        t
    } ();
    n(8),
    n(9);
    function b(e) {
        return (b = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function E(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function w(e, t) {
        return ! t || "object" !== b(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function T(e, t, n) {
        return (T = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = C(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function C(e) {
        return (C = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function O(e, t) {
        return (O = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var I = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.themeColor,
            r = e.titleText,
            s = void 0 === r ? null: r,
            a = e.bodyText,
            l = void 0 === a ? null: a,
            c = e.primaryText,
            u = void 0 === c ? null: c,
            h = e.secondaryText,
            d = void 0 === h ? null: h,
            p = e.primaryEvent,
            f = void 0 === p ? null: p,
            v = e.secondaryEvent,
            y = void 0 === v ? null: v;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = w(this, C(t).call(this, i))).themeColor = o,
            n.titleText = s,
            n.bodyText = l,
            n.primaryText = u,
            n.secondaryText = d,
            n.primaryEvent = f,
            n.secondaryEvent = y,
            n.secondaryButton = null,
            n.primaryButton = null,
            n.dialogContent = null,
            n.titleTextElement = null,
            n.bodyTextElement = null,
            n.primaryButtonContainer = null,
            n.secondaryButtonContainer = null,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && O(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getCloseButton",
            value: function() {
                return this.secondaryButton || (this.secondaryButton = document.querySelector(this.selector + " .secondary")),
                this.secondaryButton
            }
        },
        {
            key: "getCloseButtonContainer",
            value: function() {
                return this.secondaryButtonContainer || (this.secondaryButtonContainer = document.querySelector(this.selector + " .secondary-button")),
                this.secondaryButtonContainer
            }
        },
        {
            key: "getContinueButton",
            value: function() {
                return this.primaryButton || (this.primaryButton = document.querySelector(this.selector + " .primary")),
                this.primaryButton
            }
        },
        {
            key: "getContinueButtonContainer",
            value: function() {
                return this.primaryButtonContainer || (this.primaryButtonContainer = document.querySelector(this.selector + " .primary-button")),
                this.primaryButtonContainer
            }
        },
        {
            key: "getDialogContent",
            value: function() {
                return this.dialogContent || (this.dialogContent = document.querySelector(this.selector + " .dialog-content")),
                this.dialogContent
            }
        },
        {
            key: "getBodyTextElement",
            value: function() {
                return this.bodyTextElement || (this.bodyTextElement = document.querySelector(this.selector + " .body-text")),
                this.bodyTextElement
            }
        },
        {
            key: "getTitleTextElement",
            value: function() {
                return this.titleTextElement || (this.titleTextElement = document.querySelector(this.selector + " .title-text")),
                this.titleTextElement
            }
        },
        {
            key: "setThemeColor",
            value: function() {
                this.getContinueButton().style.backgroundColor = this.themeColor,
                this.getDialogContent().style.borderTopColor = this.themeColor,
                this.getTitleTextElement().style.backgroundColor = this.themeColor
            }
        },
        {
            key: "setTitleText",
            value: function() {
                this.titleText ? this.getTitleTextElement().innerHTML = this.titleText: this.getTitleTextElement().innerHTML = ""
            }
        },
        {
            key: "setBodyText",
            value: function() {
                this.bodyText && (this.getBodyTextElement().innerHTML = this.bodyText)
            }
        },
        {
            key: "setPrimaryText",
            value: function() {
                this.primaryText && (this.getContinueButton().innerHTML = this.primaryText)
            }
        },
        {
            key: "setSecondaryText",
            value: function() {
                this.secondaryText && (this.getCloseButton().innerHTML = this.secondaryText)
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.setThemeColor(), this.initialized = !0)
            }
        },
        {
            key: "show",
            value: function() {
                T(C(t.prototype), "show", this).call(this),
                this.eventDispatcher.publish("event.dialogBoxShow", this),
                this.onDialogBoxCloseButtonClick = this.onDialogBoxCloseButtonClick.bind(this),
                this.onDialogBoxContinueButtonClick = this.onDialogBoxContinueButtonClick.bind(this),
                this.getCloseButton().addEventListener("click", this.onDialogBoxCloseButtonClick, !1),
                this.getContinueButton().addEventListener("click", this.onDialogBoxContinueButtonClick, !1),
                this.setTitleText(),
                this.setBodyText(),
                this.setPrimaryText(),
                this.setSecondaryText()
            }
        },
        {
            key: "hide",
            value: function() {
                T(C(t.prototype), "hide", this).call(this),
                this.eventDispatcher.publish("event.dialogBoxHide"),
                this.getCloseButton().removeEventListener("click", this.onDialogBoxCloseButtonClick, !1),
                this.getContinueButton().removeEventListener("click", this.onDialogBoxContinueButtonClick, !1)
            }
        },
        {
            key: "onDialogBoxCloseButtonClick",
            value: function() {
                this.eventDispatcher.publish(this.secondaryEvent),
                this.hide()
            }
        },
        {
            key: "onDialogBoxContinueButtonClick",
            value: function() {
                this.eventDispatcher.publish(this.primaryEvent),
                this.hide()
            }
        }]) && E(n.prototype, i),
        o && E(n, o),
        t
    } (),
    k = n(1);
    function A(e) {
        return (A = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function x(e, t) {
        return ! t || "object" !== A(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function D(e) {
        return (D = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function B(e, t) {
        return (B = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    function S(e, t) {
        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    function R(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function P(e, t, n) {
        return t && R(e.prototype, t),
        n && R(e, n),
        e
    }
    var _ = function() {
        function e() {
            S(this, e),
            this.mraid = null,
            this.mraidExt = null,
            this.mraidBridge = null,
            this.mraidBridgeExt = null,
            this.mraidErrorMap = null,
            this.mraidVersion = null,
            this.MIN_VUNGLE_MRAID2 = ">=4.6.0",
            this.readyCallback = null
        }
        return P(e, [{
            key: "getApiIdFromUrl",
            value: function(e) {
                if (!e) return null;
                var t = e.match(/\/id([0-9]*)/i);
                return t && t[1] ? t[1] : null
            }
        },
        {
            key: "openPrivacyURI",
            value: function(e) {
                if (this.isStandardMRAID2()) return this.VungleMRAID.open(e);
                this.VungleMRAIDBridgeExt.openPrivacy(e),
                "ios" === this.os && this.VungleMRAID.open(e)
            }
        },
        {
            key: "isConsentRequired",
            value: function() {
                return "getConsentRequired" in this.consent && this.consent.getConsentRequired()
            }
        },
        {
            key: "isStandardMRAID2",
            value: function() {
                return this.VungleMRAIDVersion && Object(k.satisfies)(this.VungleMRAIDVersion, this.MIN_VUNGLE_MRAID2)
            }
        },
        {
            key: "initCustomOperations",
            value: function() {
                this.VungleMRAID.useCustomClose(),
                this.isStandardMRAID2() || this.VungleMRAIDExt.useCustomPrivacy(!0)
            }
        },
        {
            key: "VungleMRAID",
            get: function() {
                return this.mraid || (this.mraid = window.vungle.mraid || window.mraid),
                this.mraid
            }
        },
        {
            key: "VungleMRAIDExt",
            get: function() {
                return this.mraidExt || (this.mraidExt = window.vungle.mraidExt),
                this.mraidExt
            }
        },
        {
            key: "VungleMRAIDBridge",
            get: function() {
                return this.mraidBridge || (this.mraidBridge = window.vungle.mraidBridge),
                this.mraidBridge
            }
        },
        {
            key: "VungleMRAIDBridgeExt",
            get: function() {
                return this.mraidBridgeExt || (this.mraidBridgeExt = window.vungle.mraidBridgeExt),
                this.mraidBridgeExt
            }
        },
        {
            key: "VungleMRAIDErrorMap",
            get: function() {
                return this.mraidErrorMap || (this.mraidErrorMap = window.vungle.error),
                this.mraidErrorMap
            }
        },
        {
            key: "VungleMRAIDVersion",
            get: function() {
                return "getMraidVersion" in this.VungleMRAIDExt && (this.mraidVersion = this.VungleMRAIDExt.getMraidVersion()),
                this.mraidVersion
            }
        },
        {
            key: "consent",
            get: function() {
                return this.isStandardMRAID2() ? this.VungleMRAIDExt: this.VungleMRAID
            }
        },
        {
            key: "os",
            get: function() {
                return (this.VungleMRAIDExt.getOS() || (window.navigator.userAgent.match(/Android/i) ? "Android": "Unknown")).trim().toLowerCase()
            }
        },
        {
            key: "osVersion",
            get: function() {
                return this.VungleMRAIDExt.getOSVersion().trim()
            }
        },
        {
            key: "DynamicElement",
            get: function() {
                return this.dynamicElement || (this.dynamicElement = document.querySelector("#dynamic")),
                this.dynamicElement
            }
        },
        {
            key: "VungleCTA",
            get: function() {
                if (!this.cta) {
                    var e = this.VungleMRAIDBridgeExt.getReplacementTokens();
                    this.cta = {
                        uri: e.CTA_BUTTON_URL,
                        appStoreId: e.APP_STORE_ID || this.getApiIdFromUrl(e.CTA_BUTTON_URL)
                    }
                }
                return this.cta
            }
        }]),
        e
    } (),
    L = function(e) {
        function t() {
            var e;
            return S(this, t),
            (e = x(this, D(t).call(this))).readyCallback = null,
            e
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && B(e, t)
        } (t, _),
        P(t, [{
            key: "mraidReady",
            value: function() {
                this.VungleMRAID && (this.VungleMRAID.addEventListener("error", this.mraidError), this.initCustomOperations()),
                this.readyCallback && this.readyCallback()
            }
        },
        {
            key: "mraidReadyCheck",
            value: function(e) {
                this.readyCallback = e,
                this.VungleMRAID && "loading" === this.VungleMRAID.getState() ? this.VungleMRAID.addEventListener("ready", this.mraidReady.bind(this)) : this.mraidReady()
            }
        },
        {
            key: "mraidError",
            value: function(e, t) {
                window.console && window.console.log("%cMRAID (SDK) Error Detected. time=%f, message=%s, action=%s", "color: red; font-size: x-large", Date.now(), e, t)
            }
        }]),
        t
    } ();
    n(11),
    n(12);
    function M(e) {
        return (M = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function N(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function V(e, t) {
        return ! t || "object" !== M(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function j(e, t, n) {
        return (j = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = z(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function z(e) {
        return (z = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function U(e, t) {
        return (U = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var H = function(e) {
        function t(e) {
            var n, i = e.selector;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = V(this, z(t).call(this, i))).consentButton = null,
            n.noConsentButton = null,
            n.titleTextElement = null,
            n.bodyTextElement = null,
            n.bodyTextContainer = null,
            n.bodyTextTranslateY = 0,
            n.resizeFinishedTimeout = null,
            n.mraidObject = new _,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && U(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getDialog",
            value: function() {
                return this.dialog || (this.dialog = document.querySelector(this.selector + " .dialog")),
                this.dialog
            }
        },
        {
            key: "getConsentButton",
            value: function() {
                return this.consentButton || (this.consentButton = document.querySelector(this.selector + " .consent-button button")),
                this.consentButton
            }
        },
        {
            key: "getNoConsentButton",
            value: function() {
                return this.noConsentButton || (this.noConsentButton = document.querySelector(this.selector + " .no-consent-button button")),
                this.noConsentButton
            }
        },
        {
            key: "getTitleTextElement",
            value: function() {
                return this.titleTextElement || (this.titleTextElement = document.querySelector(this.selector + " .title-text")),
                this.titleTextElement
            }
        },
        {
            key: "getBodyTextContainer",
            value: function() {
                return this.bodyTextContainer || (this.bodyTextContainer = document.querySelector(this.selector + " .body-text-container")),
                this.bodyTextContainer
            }
        },
        {
            key: "getBodyTextElement",
            value: function() {
                return this.bodyTextElement || (this.bodyTextElement = document.querySelector(this.selector + " .body-text")),
                this.bodyTextElement
            }
        },
        {
            key: "setBodyText",
            value: function() {
                this.getBodyTextElement().innerHTML = this.mraidObject.consent.getConsentBodyText()
            }
        },
        {
            key: "setConsentText",
            value: function() {
                this.getConsentButton().innerHTML = this.mraidObject.consent.getConsentAcceptButtonText()
            }
        },
        {
            key: "setNoConsentText",
            value: function() {
                this.getNoConsentButton().innerHTML = this.mraidObject.consent.getConsentDenyButtonText()
            }
        },
        {
            key: "setTitleText",
            value: function() {
                this.getTitleTextElement().innerHTML = this.mraidObject.consent.getConsentTitleText()
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.initialized = !0, this.eventDispatcher.subscribe("event.viewportChange", this.onViewportChange.uuidBind(this)))
            }
        },
        {
            key: "show",
            value: function() {
                j(z(t.prototype), "show", this).call(this),
                this.setDialogHeight(),
                this.setBodyText(),
                this.setConsentText(),
                this.setNoConsentText(),
                this.setTitleText(),
                this.onConsentButtonClick = this.onConsentButtonClick.bind(this),
                this.onNoConsentButtonClick = this.onNoConsentButtonClick.bind(this),
                this.getConsentButton().addEventListener("click", this.onConsentButtonClick),
                this.getNoConsentButton().addEventListener("click", this.onNoConsentButtonClick)
            }
        },
        {
            key: "hide",
            value: function() {
                j(z(t.prototype), "hide", this).call(this),
                this.getConsentButton().removeEventListener("click", this.onConsentButtonClick),
                this.getNoConsentButton().removeEventListener("click", this.onNoConsentButtonClick),
                this.eventDispatcher.unsubscribeAll(this._id)
            }
        },
        {
            key: "setDialogHeight",
            value: function() {
                var e = window.innerHeight / 100,
                t = window.innerWidth / 100;
                this.getDialog().style.height = "".concat(100 * e - 15 * t, "px")
            }
        },
        {
            key: "onConsentButtonClick",
            value: function() {
                this.hide(),
                this.mraidObject.VungleMRAIDBridgeExt.consentAction("opted_in"),
                this.eventDispatcher.publish("event.gdprConsent", "opted_in")
            }
        },
        {
            key: "onNoConsentButtonClick",
            value: function() {
                this.hide(),
                this.mraidObject.VungleMRAIDBridgeExt.consentAction("opted_out"),
                this.eventDispatcher.publish("event.gdprConsent", "opted_out")
            }
        },
        {
            key: "resizeInterval",
            value: function() {
                var e = this;
                this.resizeFinishedInterval && (clearInterval(this.resizeFinishedInterval), this.resizeFinishedInterval = null),
                this.resizeFinishedInterval = setInterval(function() {
                    e.setDialogHeight()
                },
                10)
            }
        },
        {
            key: "resizeTimeout",
            value: function() {
                var e = this;
                this.resizeFinishedTimeout && (clearTimeout(this.resizeFinishedTimeout), this.resizeFinishedTimeout = null),
                this.resizeFinishedTimeout = setTimeout(function() {
                    e.setDialogHeight(),
                    clearInterval(e.resizeFinishedInterval),
                    e.resizeFinishedInterval = null
                },
                500)
            }
        },
        {
            key: "onViewportChange",
            value: function() {
                this.setDialogHeight(),
                this.resizeInterval(),
                this.resizeTimeout()
            }
        }]) && N(n.prototype, i),
        o && N(n, o),
        t
    } ();
    function F(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var G = function() {
        function e() { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e)
        }
        var t, n, i;
        return t = e,
        i = [{
            key: "getViewportSize",
            value: function() {
                var e = 0,
                t = 0;
                return "number" == typeof window.innerHeight ? (e = window.innerWidth, t = window.innerHeight) : document.documentElement && document.documentElement.clientHeight ? (t = document.documentElement.clientHeight, e = document.documentElement.clientWidth) : document.body && document.body.clientHeight && (t = document.body.clientHeight, e = document.body.clientWidth),
                {
                    width: e,
                    height: t
                }
            }
        },
        {
            key: "elementAddClass",
            value: function(e, t) {
                var n = e && e.split(" ") || [];
                return - 1 === n.indexOf(t) && n.push(t),
                n.join(" ")
            }
        },
        {
            key: "elementRemoveClass",
            value: function(e, t) {
                var n = e && e.split(" ") || [],
                i = n.indexOf(t);
                return - 1 !== i && n.splice(i, 1),
                n.join(" ")
            }
        },
        {
            key: "addMultiEventListener",
            value: function(e, t, n) {
                var i, o, r = t.split(" ");
                for (o = 0, i = r.length; o < i; o++) e.addEventListener(r[o], n, !1)
            }
        },
        {
            key: "elementHasClass",
            value: function(e, t) {
                return e.classList ? e.classList.contains(t) : !!e.className.match(new RegExp("(\\s|^)" + t + "(\\s|$)"))
            }
        },
        {
            key: "findAncestor",
            value: function(e, t) {
                for (; (e = e.parentElement) && !this.elementHasClass(e, t););
                return e
            }
        }],
        (n = null) && F(t.prototype, n),
        i && F(t, i),
        e
    } ();
    function q(e) {
        return (q = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function X(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function Y(e, t) {
        return ! t || "object" !== q(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function W(e) {
        return (W = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function K(e, t) {
        return (K = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var $ = function(e) {
        function t(e) {
            var n;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = Y(this, W(t).call(this, e))).loopVideo = !1,
            n.progressBar = null,
            n.muteIconContainer = null,
            n.duration = 0,
            n.videoProgressBackgroundColor = null,
            n.videoProgressBarSpan = null,
            n.playPromise = null,
            n.muted = !0,
            n.paused = !1,
            n.mraidObject = new _,
            n.os = n.mraidObject.os,
            n.osVersion = n.mraidObject.osVersion,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && K(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getMuteIconContainer",
            value: function() {
                return this.muteIconContainer || (this.muteIconContainer = document.querySelector(".mute-icon-container")),
                this.muteIconContainer
            }
        },
        {
            key: "getProgressBar",
            value: function() {
                return this.progressBar || (this.progressBar = document.querySelector(".progress-bar")),
                this.progressBar
            }
        },
        {
            key: "getVideoProgressBackgroundColor",
            value: function() {
                return this.videoProgressBackgroundColor || (this.videoProgressBackgroundColor = document.querySelector(".progress-bar").getAttribute("data-vgl-progress-background-color")),
                this.videoProgressBackgroundColor
            }
        },
        {
            key: "getVideoProgressBarSpan",
            value: function() {
                return this.videoProgressBarSpan || (this.videoProgressBarSpan = document.querySelector(".progress-bar span")),
                this.videoProgressBarSpan
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.loopVideo = this.getElement().hasAttribute("loop"), this.addVideoListener(), this.addMuteUnmuteListener(), this.setProgressBar(), this.eventDispatcher.subscribe("event.playVideoFromTime", this.playFromTime.uuidBind(this)), this.eventDispatcher.subscribe("event.viewportChange", this.onViewportChange.uuidBind(this)), this.eventDispatcher.subscribe("event.playVideo", this.play.uuidBind(this)), this.eventDispatcher.subscribe("event.pauseVideo", this.pause.uuidBind(this)), this.initialized = !0)
            }
        },
        {
            key: "addVideoListener",
            value: function() {
                "android" === this.os && this.osVersion <= 19 && this.loopVideo ? (this.getElement().removeAttribute("loop"), this.getElement().addEventListener("ended", this.onVideoEnded.bind(this))) : this.loopVideo ? this.getElement().addEventListener("seeked", this.onVideoEnded.bind(this)) : this.getElement().addEventListener("ended", this.onVideoEnded.bind(this)),
                this.getElement().addEventListener("timeupdate", this.onVideoTimeUpdate.bind(this)),
                this.getElement().addEventListener("timeupdate", this.onVideoTimeCheckpoint.bind(this)),
                this.getElement().addEventListener("loadedmetadata", this.onVideoLoadedMetadata.bind(this)),
                this.getElement().addEventListener("durationchange", this.onVideoDurationChange.bind(this)),
                this.getElement().load()
            }
        },
        {
            key: "addMuteUnmuteListener",
            value: function() {
                var e = this,
                t = document.querySelector(".unmute-video-wrap"),
                n = document.querySelector(".mute-video-wrap");
                t.addEventListener("click",
                function() {
                    t.setAttribute("class", G.elementAddClass(t.className, "hidden")),
                    n.setAttribute("class", G.elementRemoveClass(n.className, "hidden")),
                    e.muteUnmute(!0),
                    e.eventDispatcher.publish("event.videoSoundUpdate", "mute")
                }),
                n.addEventListener("click",
                function() {
                    n.setAttribute("class", G.elementAddClass(n.className, "hidden")),
                    t.setAttribute("class", G.elementRemoveClass(t.className, "hidden")),
                    e.muteUnmute(!1),
                    e.eventDispatcher.publish("event.videoSoundUpdate", "unmute")
                })
            }
        },
        {
            key: "positionOnWindows",
            value: function() {
                if (this.isWindows()) {
                    var e = Math.abs(window.innerHeight - window.outerHeight),
                    t = this.getMuteIconContainer().getBoundingClientRect().top;
                    this.getMuteIconContainer().setAttribute("class", G[e > 5 && e <= 20 && t <= 40 ? "elementAddClass": "elementRemoveClass"](this.getMuteIconContainer().className, "windows-full-screen"))
                }
            }
        },
        {
            key: "isWindows",
            value: function() {
                return G.elementHasClass(document.querySelector("#dynamic"), "windows")
            }
        },
        {
            key: "setMuteIconContainer",
            value: function() {
                this.getMuteIconContainer().setAttribute("class", G.elementRemoveClass(this.getMuteIconContainer().className, "windows-full-screen")),
                this.getMuteIconContainer().style.marginLeft = "",
                this.getMuteIconContainer().style.marginTop = "",
                this.getProgressBar().style.marginLeft = "",
                this.videoRatio = this.getElement().videoWidth / this.getElement().videoHeight,
                this.videoOffsetWidth = this.getElement().offsetWidth,
                this.videoOffsetHeight = this.getElement().offsetHeight,
                this.elementRatio = this.videoOffsetWidth / this.videoOffsetHeight,
                this.elementRatio > this.videoRatio ? (this.videoOffsetWidth = this.videoOffsetHeight * this.videoRatio, this.getMuteIconContainer().style.marginLeft = (this.getElement().clientWidth - this.videoOffsetWidth) / 2 + "px") : (this.videoOffsetHeight = this.videoOffsetWidth / this.videoRatio, this.getMuteIconContainer().style.marginTop = (this.getElement().clientHeight - this.videoOffsetHeight) / 2 + "px"),
                this.getProgressBar().style.width = this.videoOffsetWidth + "px",
                this.getProgressBar().style.marginLeft = this.getMuteIconContainer().style.marginLeft,
                this.positionOnWindows()
            }
        },
        {
            key: "show",
            value: function() {}
        },
        {
            key: "hide",
            value: function() {
                this.pause()
            }
        },
        {
            key: "destroy",
            value: function() {
                this.eventDispatcher.unsubscribeAll(this._id)
            }
        },
        {
            key: "pause",
            value: function() {
                var e = this;
                if (!this.paused) {
                    this.clearCheckIfPayingInterval();
                    var t = function() { ! e.getElement().paused && e.getElement().pause(),
                        e.paused = !0,
                        e.eventDispatcher.publish("event.videoStateChanged", "pause")
                    };
                    this.playPromise ? this.playPromise.then(t) : t()
                }
            }
        },
        {
            key: "play",
            value: function() {
                var e = this;
                if (this.paused) {
                    this.clearCheckIfPayingInterval();
                    var t = function() {
                        e.paused = !1,
                        e.checkIfPlaying(),
                        e.eventDispatcher.publish("event.videoStateChanged", "play")
                    };
                    this.playPromise = this.getElement().play(),
                    "android" === this.os && this.osVersion <= 19 && (this.getElement().pause(), this.getElement().muted = this.muted, this.getElement().offsetHeight, this.playPromise = this.getElement().play()),
                    this.playPromise ? this.playPromise.then(t).
                    catch(t) : t()
                }
            }
        },
        {
            key: "checkIfPlaying",
            value: function() {
                var e = this;
                if (this.duration) {
                    var t = this.getElement().currentTime;
                    this.clearCheckIfPayingInterval(),
                    this.checkIfPayingInterval = setInterval(function() {
                        e.getElement().currentTime !== t ? e.clearCheckIfPayingInterval() : e.playPromise = e.getElement().play()
                    },
                    250)
                }
            }
        },
        {
            key: "clearCheckIfPayingInterval",
            value: function() {
                this.checkIfPayingInterval && (clearInterval(this.checkIfPayingInterval), this.checkIfPayingInterval = null)
            }
        },
        {
            key: "playFromTime",
            value: function(e) {
                this.getElement().currentTime = e
            }
        },
        {
            key: "progressBarUpdate",
            value: function(e) {
                e.duration >= 0 && (document.querySelector(".progress-bar span").style.width = e.currentTime / e.duration * 100 + "%")
            }
        },
        {
            key: "onViewportChange",
            value: function() {
                this.setMuteIconContainer()
            }
        },
        {
            key: "onVideoEnded",
            value: function() {
                this.eventDispatcher.publish("event.videoPlayComplete"),
                "android" === this.os && this.osVersion <= 19 && this.loopVideo && this.getElement().play()
            }
        },
        {
            key: "onVideoTimeCheckpoint",
            value: function() {
                this.eventDispatcher.publish("event.videoPlayCheckpoint", {
                    currentTime: this.getElement().currentTime,
                    duration: this.getElement().duration
                })
            }
        },
        {
            key: "onVideoTimeUpdate",
            value: function() {
                this.eventDispatcher.publish("event.videoPlayTimeupdate", {
                    currentTime: this.getElement().currentTime,
                    duration: this.getElement().duration
                }),
                this.getProgressBar() && this.progressBarUpdate(this.getElement())
            }
        },
        {
            key: "setInitialMuteValue",
            value: function() {
                this.setMuteTokenValue(),
                this.setMuteUnmuteTheme(),
                this.setMuteIconContainer()
            }
        },
        {
            key: "onVideoLoadedMetadata",
            value: function() {
                this.pause(),
                this.setInitialMuteValue(),
                this.play()
            }
        },
        {
            key: "onVideoDurationChange",
            value: function() {
                this.duration = this.getElement().duration,
                this.eventDispatcher.publish("event.videoMetadataAvailable", {
                    height: this.getElement().videoHeight,
                    width: this.getElement().videoWidth
                }),
                this.setInitialMuteValue()
            }
        },
        {
            key: "getMuteTokenValue",
            value: function() {
                return "true" === this.getMuteIconContainer().getAttribute("data-vgl-start-muted")
            }
        },
        {
            key: "muteUnmute",
            value: function(e) {
                this.getElement().muted = e,
                this.muted = e
            }
        },
        {
            key: "setMuteTokenValue",
            value: function() {
                this.muteUnmute(this.getMuteTokenValue())
            }
        },
        {
            key: "setMuteUnmuteTheme",
            value: function() {
                var e = this.getMuteTokenValue(),
                t = document.querySelector(".unmute-video-wrap"),
                n = document.querySelector(".mute-video-wrap"),
                i = this.getMuteIconContainer();
                e ? n.setAttribute("class", G.elementRemoveClass(n.className, "hidden")) : t.setAttribute("class", G.elementRemoveClass(t.className, "hidden")),
                i.setAttribute("class", G.elementAddClass(i.className, e ? "unmute-video": "mute-video"))
            }
        },
        {
            key: "setProgressBar",
            value: function() {
                "false" === this.getElement().getAttribute("data-vgl-video-timer") ? this.getProgressBar().style.visibility = "hidden": this.getVideoProgressBarSpan().style.background = this.getVideoProgressBackgroundColor()
            }
        }]) && X(n.prototype, i),
        o && X(n, o),
        t
    } ();
    function Z(e) {
        return (Z = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function J(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function Q(e, t) {
        return ! t || "object" !== Z(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function ee(e, t, n) {
        return (ee = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = te(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function te(e) {
        return (te = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function ne(e, t) {
        return (ne = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var ie = function(e) {
        function t(e) {
            var n = e.selector,
            i = e.isIncentivized;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            Q(this, te(t).call(this, {
                selector: n,
                isIncentivized: i
            }))
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && ne(e, t)
        } (t, m),
        n = t,
        (i = [{
            key: "init",
            value: function() { ! this.initialized && this.isWindows() && this.eventDispatcher.subscribe("event.viewportChange", this.onViewportChange.uuidBind(this)),
                ee(te(t.prototype), "init", this).call(this),
                window.vungle.flexFeed && (this.getElement().style.visibility = "hidden")
            }
        },
        {
            key: "isWindows",
            value: function() {
                return G.elementHasClass(document.querySelector("#dynamic"), "windows")
            }
        },
        {
            key: "positionOnWindows",
            value: function() {
                this.isWindows() && this.onViewportChange()
            }
        },
        {
            key: "onClick",
            value: function() {
                this.eventDispatcher.publish("event.closeButtonClick")
            }
        },
        {
            key: "show",
            value: function() {
                var e = this,
                n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                if (this.positionOnWindows(), n) window.vungle.flexFeed || ee(te(t.prototype), "show", this).call(this);
                else {
                    var i = this.getShowDelayMilliseconds();
                    "number" == typeof i ? window.vungle.flexFeed || (0 === i ? ee(te(t.prototype), "show", this).call(this) : (this.hide(), setTimeout(function() {
                        ee(te(t.prototype), "show", e).call(e),
                        e.showDelayMilliseconds = 0
                    },
                    i))) : this.hide()
                }
            }
        },
        {
            key: "onViewportChange",
            value: function() {
                var e = Math.abs(window.innerHeight - window.outerHeight);
                this.getElement().setAttribute("class", G[e > 5 && e <= 20 ? "elementAddClass": "elementRemoveClass"](this.getElement().className, "windows-full-screen"))
            }
        }]) && J(n.prototype, i),
        o && J(n, o),
        t
    } ();
    var oe = {
        DownloadButton: new
        function e() { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e),
            this.HardHide = null,
            this.IncentivizedTimeout = null
        }
    };
    function re(e) {
        return (re = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function se(e, t) {
        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    function ae(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function le(e, t, n) {
        return t && ae(e.prototype, t),
        n && ae(e, n),
        e
    }
    function ce(e, t) {
        return ! t || "object" !== re(t) && "function" != typeof t ? ue(e) : t
    }
    function ue(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }
    function he(e, t, n) {
        return (he = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = de(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function de(e) {
        return (de = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function pe(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }),
        t && fe(e, t)
    }
    function fe(e, t) {
        return (fe = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var ve = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.isIncentivized,
            r = void 0 !== o && o,
            s = e.buttonColor,
            a = void 0 === s ? null: s;
            se(this, t);
            var l = ue(n = ce(this, de(t).call(this, {
                selector: i,
                isIncentivized: r
            })));
            return n.uri = n.getElement().getAttribute("data-vgl-uri"),
            n.appStoreId = n.getElement().getAttribute("data-vgl-app-store-id") || n.getApiIdFromUrl(),
            n.buttonColor = a,
            n.mraidObject = new _,
            n.isIncentivized && !n.mraidObject.VungleMRAIDVersion && ( - 1 !== ["ios"].indexOf(n.mraidObject.os) && (n.hardHideDownload = new ge({
                selector: l.selector
            })), -1 !== ["ios", "android"].indexOf(n.mraidObject.os) && (n.incentivizedTimeoutDownload = new me({
                selector: l.selector
            }))),
            n
        }
        return pe(t, m),
        le(t, [{
            key: "destroy",
            value: function() {
                this.hardHideDownload && this.hardHideDownload.destroy(),
                this.incentivizedTimeoutDownload && this.incentivizedTimeoutDownload.destroy(),
                he(de(t.prototype), "destroy", this).call(this)
            }
        },
        {
            key: "getApiIdFromUrl",
            value: function() {
                if (!this.uri) return null;
                var e = this.uri.match(/\/id([0-9]*)/i);
                return e && e[1] ? e[1] : null
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (he(de(t.prototype), "init", this).call(this), this.hardHideDownload && this.hardHideDownload.init(), this.incentivizedTimeoutDownload && this.incentivizedTimeoutDownload.init(), this.buttonColor && (this.getElement().style.backgroundColor = this.buttonColor), this.initialized = !0)
            }
        },
        {
            key: "onClick",
            value: function() {
                this.eventDispatcher.publish("event.downloadButtonClick")
            }
        },
        {
            key: "show",
            value: function() {
                var e = this,
                n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                if (n) he(de(t.prototype), "show", this).call(this);
                else {
                    var i = this.getShowDelayMilliseconds();
                    "number" == typeof i ? 0 === i ? he(de(t.prototype), "show", this).call(this) : (this.hide(), setTimeout(function() {
                        he(de(t.prototype), "show", e).call(e),
                        e.showDelayMilliseconds = 0
                    },
                    i)) : this.hide()
                }
            }
        },
        {
            key: "clazz",
            get: function() {
                return "DownloadButton"
            }
        }]),
        t
    } (),
    ye = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.isIncentivized,
            r = void 0 !== o && o;
            return se(this, t),
            (n = ce(this, de(t).call(this, {
                selector: i,
                isIncentivized: r
            }))).isEnabled = "true" === n.getElement().getAttribute("data-vgl-full-cta"),
            n
        }
        return pe(t, ve),
        le(t, [{
            key: "onAdViewableChanged",
            value: function(e) {
                var t = this;
                "deny" !== oe.DownloadButton.HardHide ? setTimeout(function() {
                    t.getElement().setAttribute("class", G["maximized" === e ? "elementRemoveClass": "elementAddClass"](t.getElement().className, "hide"))
                }) : this.destroy()
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (he(de(t.prototype), "init", this).call(this), this.isEnabled && this.eventDispatcher.subscribe("event.adViewableChanged", this.onAdViewableChanged.uuidBind(this)), this.initialized = !0)
            }
        }]),
        t
    } (),
    ge = function(e) {
        function t(e) {
            var n = e.selector;
            return se(this, t),
            ce(this, de(t).call(this, n))
        }
        return pe(t, d),
        le(t, [{
            key: "bury",
            value: function() {
                this.hide(),
                this.getElement().setAttribute("class", G.elementAddClass(this.getElement().className, "hide"))
            }
        },
        {
            key: "destroy",
            value: function() {
                this.eventDispatcher.unsubscribeAll(this._id)
            }
        },
        {
            key: "onHardHideDownloadButton",
            value: function() {
                this.bury()
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || ("deny" === oe.DownloadButton.HardHide ? this.bury() : this.eventDispatcher.subscribe("event.hardHideDownloadButton", this.onHardHideDownloadButton.uuidBind(this)), this.initialized = !0)
            }
        }]),
        t
    } (),
    me = function(e) {
        function t(e) {
            var n = e.selector;
            return se(this, t),
            ce(this, de(t).call(this, n))
        }
        return pe(t, d),
        le(t, [{
            key: "destroy",
            value: function() {
                this.eventDispatcher.unsubscribeAll(this._id)
            }
        },
        {
            key: "isOnClickDisabled",
            value: function() {
                return G.elementHasClass(this.getElement(), "disable-cta")
            }
        },
        {
            key: "isDelayedShown",
            value: function() {
                return G.elementHasClass(this.getElement(), "cta-delay-show")
            }
        },
        {
            key: "activateClick",
            value: function() {
                this.getElement().setAttribute("class", G.elementRemoveClass(this.getElement().className, "disable-cta"))
            }
        },
        {
            key: "deactivateClick",
            value: function() {
                this.getElement().setAttribute("class", G.elementAddClass(this.getElement().className, "disable-cta"))
            }
        },
        {
            key: "onVideoPlayTimeupdate",
            value: function(e) {
                this.deactivateClick();
                var t = e.duration,
                n = e.currentTime;
                if ("number" == typeof t && !isNaN(t)) {
                    var i = Math.floor(80 * t / 100),
                    o = Math.ceil(i - n),
                    r = this.getElement().querySelector(".cta-button__timer"),
                    s = this.getElement().querySelector(".cta-button__text"),
                    a = this.getElement().querySelector(".cta-button__icon");
                    s && s.setAttribute("class", G.elementAddClass(s.className, "hide")),
                    a && a.setAttribute("class", G.elementAddClass(a.className, "hide")),
                    r.setAttribute("class", G.elementRemoveClass(r.className, "hide")),
                    o && (r.innerHTML = o)
                }
            }
        },
        {
            key: "onSuccessfulViewAdReached",
            value: function() {
                if (this.activateClick(), this.isDelayedShown()) {
                    this.eventDispatcher.unsubscribe("event.videoPlayTimeupdate", this.onVideoPlayTimeupdate);
                    var e = this.getElement().querySelector(".cta-button__timer"),
                    t = this.getElement().querySelector(".cta-button__text"),
                    n = this.getElement().querySelector(".cta-button__icon");
                    t && t.setAttribute("class", G.elementRemoveClass(t.className, "hide")),
                    n && n.setAttribute("class", G.elementRemoveClass(n.className, "hide")),
                    e.setAttribute("class", G.elementAddClass(e.className, "hide"))
                }
            }
        },
        {
            key: "init",
            value: function() {
                if (!this.initialized) {
                    if ("dismissed" === oe.DownloadButton.IncentivizedTimeout) this.destroy();
                    else if (this.deactivateClick(), this.eventDispatcher.subscribe("event.successfulViewAdReached", this.onSuccessfulViewAdReached.uuidBind(this)), this.eventDispatcher.subscribe("event.dismissIncentivizedAdPage", this.onSuccessfulViewAdReached.uuidBind(this)), this.isDelayedShown()) {
                        var e = this.getElement().querySelector(".cta-button__timer"),
                        t = this.getElement().querySelector(".cta-button__text"),
                        n = this.getElement().querySelector(".cta-button__icon");
                        t && t.setAttribute("class", G.elementAddClass(t.className, "hide")),
                        n && n.setAttribute("class", G.elementAddClass(n.className, "hide")),
                        e.setAttribute("class", G.elementAddClass(e.className, "hide")),
                        this.eventDispatcher.subscribe("event.videoPlayTimeupdate", this.onVideoPlayTimeupdate.uuidBind(this))
                    }
                    this.initialized = !0
                }
            }
        }]),
        t
    } ();
    function be(e) {
        return (be = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function Ee(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function we(e, t) {
        return ! t || "object" !== be(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function Te(e) {
        return (Te = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Ce(e, t) {
        return (Ce = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var Oe = function(e) {
        function t(e) {
            var n;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = we(this, Te(t).call(this, e))).privacyButton = null,
            n.privacyURI = null,
            n.showLockIconMilliseconds = 3e3,
            n.timer = null,
            n.subTimer = null,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && Ce(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getPrivacyButton",
            value: function() {
                return this.privacyButton || (this.privacyButton = document.querySelector(this.selector)),
                this.privacyButton
            }
        },
        {
            key: "getPrivacyURI",
            value: function() {
                return this.privacyURI || (this.privacyURI = this.getElement().getAttribute("data-vgl-uri")),
                this.privacyURI
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.getPrivacyButton().addEventListener("click", this.onPrivacyButtonClick.bind(this)), this.initialized = !0)
            }
        },
        {
            key: "reset",
            value: function() {
                var e = this;
                clearTimeout(this.timer),
                this.timer = setTimeout(function() {
                    e.getPrivacyButton().setAttribute("class", G.elementRemoveClass(e.getPrivacyButton().className, "extended")),
                    e.subTimer = setTimeout(function() {
                        e.getPrivacyButton().setAttribute("class", G.elementRemoveClass(e.getPrivacyButton().className, "reverse"))
                    },
                    500)
                },
                this.showLockIconMilliseconds),
                this.subTimer = setTimeout(function() {
                    e.getPrivacyButton().setAttribute("class", G.elementAddClass(e.getPrivacyButton().className, "reverse"))
                },
                1e3)
            }
        },
        {
            key: "shortenPrivacyButton",
            value: function() {
                this.getPrivacyButton().setAttribute("class", G.elementAddClass(this.getPrivacyButton().className, "extended")),
                this.reset()
            }
        },
        {
            key: "isExtended",
            value: function() {
                return G.elementHasClass(this.getPrivacyButton(), "extended")
            }
        },
        {
            key: "onPrivacyButtonClick",
            value: function() {
                this.isExtended() && this.eventDispatcher.publish("event.alertPrivacy"),
                this.shortenPrivacyButton()
            }
        }]) && Ee(n.prototype, i),
        o && Ee(n, o),
        t
    } ();
    var Ie;
    window.navigator.pointerEnabled ? (Ie = "pointerdown", "pointerup", "pointermove") : window.navigator.msPointerEnabled ? (Ie = "MSPointerDown", "MSPointerUp", "MSPointerMove") : "ontouchstart" in window ? (Ie = "touchstart", "touchend", "touchmove") : (Ie = "mousedown", "mouseup", "mousemove");
    function ke(e) {
        return function(e) {
            if (Array.isArray(e)) {
                for (var t = 0,
                n = new Array(e.length); t < e.length; t++) n[t] = e[t];
                return n
            }
        } (e) ||
        function(e) {
            if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
        } (e) ||
        function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        } ()
    }
    function Ae(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var xe = function() {
        function e() { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e),
            this.eventDispatcher = u.instance,
            this.dataAttrStr = "data-vgl-tabindex",
            this.platforms = ["windows"],
            this.clickable = ["Video"];
            var t = this.forwardKeys = ["Tab", "ArrowRight", "Right", "ArrowUp", "Up"],
            n = this.backwardKeys = ["Shift+Tab", "ArrowLeft", "Left", "ArrowDown", "Down"],
            i = this.navKeys = [].concat(t, n),
            o = this.submitKeys = ["Enter"],
            r = this.closeKeys = ["Esc", "Escape"];
            this.allKeys = [].concat(o, r, ke(i)),
            this.viewFocusIndx = -1,
            this.gdprDialogBoxIndx = -1,
            this.dialogBoxIndx = -1,
            this.dialogBoxObject = null
        }
        var t, n, i;
        return t = e,
        (n = [{
            key: "getViewHolder",
            value: function() {
                return this.viewName ? (this.viewHolder || (this.viewHolder = document.querySelector("#".concat(this.viewName))), this.viewHolder) : null
            }
        },
        {
            key: "getIndxEle",
            value: function(e, t) {
                var n = this.getTabIndex(e);
                return e.querySelector("*[".concat(this.dataAttrStr, '="').concat(n[t], '"]'))
            }
        },
        {
            key: "getIndexedElements",
            value: function(e) {
                return e.querySelectorAll("*[".concat(this.dataAttrStr, "]"))
            }
        },
        {
            key: "getTabIndex",
            value: function(e) {
                var t = this;
                return [].filter.call(this.getIndexedElements(e),
                function(e) {
                    if (t.isVisible(e)) return e
                }).map(function(e) {
                    return parseInt(e.getAttribute(t.dataAttrStr), 10)
                }).sort(function(e, t) {
                    return e - t
                })
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.onBodyTouch = this.onBodyTouch.uuidBind(this), this.onDialogBoxShow = this.onDialogBoxShow.uuidBind(this), this.onDialogBoxHide = this.onDialogBoxHide.uuidBind(this), this.onAdViewableChanged = this.onAdViewableChanged.uuidBind(this), this.onKeyDown = this.onKeyDown.uuidBind(this), this.onShowPage = this.onShowPage.uuidBind(this), window.addEventListener("keydown", this.onKeyDown, !0), document.body.addEventListener(Ie, this.onBodyTouch), this.eventDispatcher.subscribe("event.dialogBoxShow", this.onDialogBoxShow), this.eventDispatcher.subscribe("event.dialogBoxHide", this.onDialogBoxHide), this.eventDispatcher.subscribe("event.showPage", this.onShowPage), this.eventDispatcher.subscribe("event.adViewableChanged", this.onAdViewableChanged), this.initialized = !0)
            }
        },
        {
            key: "onShowPage",
            value: function(e) {
                var t = this;
                this.initialized && (this.dialogBoxIndx = -1, this.viewFocusIndx = -1, this.gdprDialogBoxIndx = -1, this.viewHolder = null, this.viewName = null, this.closeButtonObject = e.getCloseButtonObject(), this.gdprDialogBoxObject = e.getGDPRDialogBoxObject(), this.dialogBoxObject = null, document.activeElement.blur(), setTimeout(function() {
                    t.setTabIndexes(),
                    t.viewName = e.viewName
                }))
            }
        },
        {
            key: "setTabIndexes",
            value: function() {
                if (!this.isTabbed) {
                    var e = this; [].forEach.call(this.getIndexedElements(document.body),
                    function(t) {
                        t.setAttribute("tabindex", parseInt(t.getAttribute(e.dataAttrStr), 10))
                    }),
                    this.isTabbed = !0
                }
            }
        },
        {
            key: "blurCurrentElement",
            value: function() {
                var e = this;
                setTimeout(function() {
                    document.activeElement.blur(),
                    e.getViewHolder() && e.getViewHolder().click()
                })
            }
        },
        {
            key: "isVisible",
            value: function(e) {
                return "visible" === window.getComputedStyle(e).getPropertyValue("visibility") && e.offsetHeight
            }
        },
        {
            key: "focusOn",
            value: function(e, t) {
                var n = this.getIndxEle(e, t);
                n && n.focus()
            }
        },
        {
            key: "clickOn",
            value: function(e, t) {
                var n = this.getIndxEle(e, t);
                n && n.click()
            }
        },
        {
            key: "keyPressed",
            value: function(e, t, n, i, o, r) {
                var s = this.getTabIndex(n);
                if (s.length) return o = o ||
                function() {},
                r = r ||
                function() {},
                -1 !== this.closeKeys.indexOf(t) ? (r(), i) : -1 !== this.submitKeys.indexOf(t) && -1 !== i ? (this.clickOn(n, i), o(), i) : ( - 1 !== this.navKeys.indexOf(t) && i <= -1 ? i = 0 : -1 !== this.forwardKeys.indexOf(t) ? i = i === s.length - 1 ? 0 : i + 1 : -1 !== this.backwardKeys.indexOf(t) && (i = i <= 0 ? s.length - 1 : i - 1), this.focusOn(n, i, s), i)
            }
        },
        {
            key: "onKeyDown",
            value: function(e) {
                e.preventDefault(),
                e.stopPropagation();
                var t = e.key;
                if ("Tab" === e.key && e.shiftKey && (t = "Shift+".concat(e.key)), -1 !== this.allKeys.indexOf(t) && this.getViewHolder()) {
                    var n = this;
                    if (this.dialogBoxObject && this.dialogBoxObject.isVisible()) return this.dialogBoxIndx = this.keyPressed(e, t, this.dialogBoxObject.getElement(), this.dialogBoxIndx,
                    function() {},
                    function() {
                        n.dialogBoxObject.isVisible() && n.dialogBoxObject.getContinueButton().click()
                    });
                    if (this.gdprDialogBoxObject && this.gdprDialogBoxObject.isVisible()) return this.gdprDialogBoxIndx = this.keyPressed(e, t, this.gdprDialogBoxObject.getElement(), this.gdprDialogBoxIndx,
                    function() {
                        n.viewFocusIndx = -1,
                        n.gdprDialogBoxIndx = -1,
                        n.dialogBoxIndx = -1,
                        n.blurCurrentElement()
                    });
                    this.gdprDialogBoxIndx = -1,
                    this.dialogBoxObject = null,
                    this.dialogBoxIndx = -1,
                    -1 !== this.clickable.indexOf(this.viewName) && this.getViewHolder().offsetHeight && this.getViewHolder().offsetWidth && -1 === this.viewFocusIndx && this.getViewHolder().click(),
                    this.viewFocusIndx = this.keyPressed(e, t, this.getViewHolder(), this.viewFocusIndx,
                    function() {},
                    function() {
                        n.closeButtonObject && n.closeButtonObject.isVisible() && n.closeButtonObject.getElement().click()
                    })
                }
            }
        },
        {
            key: "onBodyTouch",
            value: function() {
                this.viewFocusIndx = -1,
                this.gdprDialogBoxIndx = -1,
                this.dialogBoxIndx = -1,
                this.blurCurrentElement()
            }
        },
        {
            key: "onDialogBoxShow",
            value: function(e) {
                this.dialogBoxObject = e,
                this.viewFocusIndx = -1,
                this.gdprDialogBoxIndx = -1,
                this.dialogBoxIndx = -1,
                this.blurCurrentElement()
            }
        },
        {
            key: "onDialogBoxHide",
            value: function() {
                this.dialogBoxObject = null,
                this.viewFocusIndx = -1,
                this.gdprDialogBoxIndx = -1,
                this.dialogBoxIndx = -1,
                this.blurCurrentElement()
            }
        },
        {
            key: "onAdViewableChanged",
            value: function(e) {
                "minimized" === e && (this.viewFocusIndx = -1, this.gdprDialogBoxIndx = -1, this.dialogBoxIndx = -1, this.blurCurrentElement())
            }
        }]) && Ae(t.prototype, n),
        i && Ae(t, i),
        e
    } ();
    function De(e) {
        return (De = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function Be(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function Se(e, t) {
        return ! t || "object" !== De(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function Re(e) {
        return (Re = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Pe(e, t) {
        return (Pe = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var _e = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.name,
            r = e.number,
            s = e.isIncentivized,
            a = void 0 !== s && s;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = Se(this, Re(t).call(this, i))).viewName = o,
            n.viewIndex = r,
            n.ctaBackgroundColor = null,
            n.gdprDialogBoxObject = null,
            n.closeButtonObject = null,
            n.privacyButtonObject = null,
            n.privacyDialogBoxObject = null,
            n.dialogboxSelector = "#DIALOGBOX",
            n.gdprDialogboxSelector = "#GDPRDialogBox",
            n.privacyBodyText = document.getElementById("privacy-body-text").innerHTML,
            n.privacyPrimaryText = document.getElementById("privacy-primary-text").innerHTML,
            n.privacySecondaryText = document.getElementById("privacy-secondary-text").innerHTML,
            n.isIncentivizedAd = a,
            n.appInfo = null,
            n.ctaInfo = null,
            n.getElement().style.display = "none",
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && Pe(e, t)
        } (t, d),
        n = t,
        (i = [{
            key: "getGDPRDialogBoxObject",
            value: function() {
                return this.gdprDialogBoxObject || (this.gdprDialogBoxObject = new H({
                    selector: this.gdprDialogboxSelector
                })),
                this.gdprDialogBoxObject
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.eventDispatcher.subscribe("event.alertPrivacy", this.onAlertPrivacy.uuidBind(this)), this.initialized = !0)
            }
        },
        {
            key: "show",
            value: function() {
                this.getElement().style.display = "block";
                var e = document.createEvent("HTMLEvents");
                e.initEvent("resize", !0, !1),
                window.dispatchEvent(e),
                this.eventDispatcher.publish("event.showPage", this)
            }
        },
        {
            key: "onDialogBoxPrimaryButtonClick",
            value: function() {
                this.eventDispatcher.publish("event.playVideo")
            }
        },
        {
            key: "onIncentivizedDialogBoxSecondaryButtonClick",
            value: function() {
                this.eventDispatcher.publish("event.dismissPage")
            }
        },
        {
            key: "hide",
            value: function() {
                this.getElement().style.display = "none",
                this.eventDispatcher.unsubscribeAll(this._id),
                this.getFullCTAObject().destroy(),
                this.getCTAButtonObject().destroy(),
                this.getCloseButtonObject().destroy(),
                this.getPrivacyButtonObject().destroy(),
                this.eventDispatcher.publish("event.hidePage", this)
            }
        },
        {
            key: "getCTABackgroundColor",
            value: function() {
                return this.ctaBackgroundColor || (this.ctaBackgroundColor = this.getElement().getAttribute("data-vgl-cta-background-color")),
                this.ctaBackgroundColor
            }
        },
        {
            key: "getFullCTAObject",
            value: function() {
                return this.fullCtaObject || (this.fullCtaObject = new ye({
                    selector: "#" + this.viewName + " .overlay-cta",
                    isIncentivized: this.isIncentivizedAd
                })),
                this.fullCtaObject
            }
        },
        {
            key: "getCTAButtonObject",
            value: function() {
                return this.ctaButtonObject || (this.ctaButtonObject = new ve({
                    selector: "#" + this.viewName + " .cta-button",
                    buttonColor: this.getCTABackgroundColor(),
                    isIncentivized: this.isIncentivizedAd
                })),
                this.ctaButtonObject
            }
        },
        {
            key: "getCloseButtonObject",
            value: function() {
                return this.closeButtonObject || (this.closeButtonObject = new ie({
                    selector: "#" + this.viewName + " .close",
                    isIncentivized: this.isIncentivizedAd
                })),
                this.closeButtonObject
            }
        },
        {
            key: "getPrivacyButtonObject",
            value: function() {
                return this.privacyButtonObject || (this.privacyButtonObject = new Oe("#" + this.viewName + " .privacy-button")),
                this.privacyButtonObject
            }
        },
        {
            key: "getPrivacyDialogBoxObject",
            value: function() {
                return this.privacyDialogBoxObject || (this.privacyDialogBoxObject = new I({
                    selector: this.dialogboxSelector,
                    themeColor: this.getCTABackgroundColor(),
                    bodyText: this.privacyBodyText,
                    primaryText: this.privacyPrimaryText,
                    secondaryText: this.privacySecondaryText,
                    primaryEvent: "event.dialogBoxPrimaryButtonClick",
                    secondaryEvent: "event.privacyDialogSecondaryButtonClick"
                })),
                this.privacyDialogBoxObject
            }
        },
        {
            key: "onAlertPrivacy",
            value: function() {
                this.getPrivacyDialogBoxObject().show()
            }
        },
        {
            key: "onCloseButtonClick",
            value: function() {
                this.eventDispatcher.publish("event.dismissPage")
            }
        },
        {
            key: "onPrivacyDialogBoxSecondaryButtonClick",
            value: function() {
                var e = this.getPrivacyButtonObject().getPrivacyURI();
                this.eventDispatcher.publish("event.privacyButtonClick", e)
            }
        },
        {
            key: "getAppInfo",
            value: function() {
                return this.appInfo || (this.appInfo = document.querySelector("#" + this.viewName + " .app-info")),
                this.appInfo
            }
        },
        {
            key: "getCTAInfo",
            value: function() {
                return this.ctaInfo || (this.ctaInfo = document.querySelector("#" + this.viewName + " .cta-info")),
                this.ctaInfo
            }
        },
        {
            key: "onViewportChange",
            value: function() {}
        },
        {
            key: "clazz",
            get: function() {
                return "AbstractPageView"
            }
        }]) && Be(n.prototype, i),
        o && Be(n, o),
        t
    } ();
    function Le(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var Me = function() {
        function e() { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e),
            this.eventDispatcher = u.instance,
            this.checkpoints = [0, 25, 50, 75, 100],
            this.checkpointsReached = [],
            this.successfulViewAd = 80,
            this.successfulViewAdReached = !1,
            this.videoViewedPerSecond = 0,
            this.apiMap = null
        }
        var t, n, i;
        return t = e,
        (n = [{
            key: "init",
            value: function(e) {
                this.apiMap = e,
                this.checkpointsReached.length = this.checkpoints.length,
                this.eventDispatcher.subscribe("event.endcardView", this.onEndcardView.uuidBind(this)),
                this.eventDispatcher.subscribe("event.videoPageClose", this.onVideoPageClose.uuidBind(this)),
                this.eventDispatcher.subscribe("event.downloadButtonClick", this.onDownloadButtonClick.uuidBind(this)),
                this.eventDispatcher.subscribe("event.videoPlayCheckpoint", this.onVideoCheckpoint.uuidBind(this)),
                this.eventDispatcher.subscribe("event.videoPlayTimeupdate", this.onSuccessfulViewAd.uuidBind(this)),
                this.eventDispatcher.subscribe("event.videoPlayTimeupdate", this.onVideoLength.uuidBind(this)),
                this.eventDispatcher.subscribe("event.installButtonClick", this.onDirectDownloadClick.uuidBind(this)),
                this.eventDispatcher.subscribe("event.videoSoundUpdate", this.onVideoSoundUpdate.uuidBind(this))
            }
        },
        {
            key: "toVideoCheckpointsIndex",
            value: function(e, t) {
                var n = 100 * (t - e <= .5 ? 1 : (Math.floor(e / t * 4) / 4).toFixed(2));
                return 0 === n ? 0 : 25 === n ? 1 : 50 === n ? 2 : 75 === n ? 3 : 100 === n ? 4 : void 0
            }
        },
        {
            key: "onVideoCheckpoint",
            value: function(e) {
                var t = this.toVideoCheckpointsIndex(e.currentTime, e.duration);
                e.currentTime > 0 && e.duration && "number" == typeof e.duration && this.videoViewedPerSecond <= Math.round(e.currentTime) && (this.apiMap.eventValuePair && this.apiMap.eventValuePair("videoViewed", Math.floor(1e3 * e.currentTime)), this.videoViewedPerSecond++);
                for (var n = 0; n <= t; n++) void 0 === this.checkpointsReached[n] && e.currentTime > 0 && e.duration && "number" == typeof e.duration && (this.checkpointsReached[n] = !0, this.apiMap.tpat && this.apiMap.tpat("checkpoint." + this.checkpoints[n])); ! 0 === this.checkpointsReached[this.checkpoints.length - 1] && (this.apiMap.eventValuePair && this.apiMap.eventValuePair("videoViewed", Math.floor(1e3 * e.duration)), this.eventDispatcher.unsubscribe("event.videoPlayCheckpoint", this.onVideoCheckpoint))
            }
        },
        {
            key: "onVideoSoundUpdate",
            value: function(e) {
                this.apiMap.tpat && this.apiMap.tpat("video.".concat(e))
            }
        },
        {
            key: "onVideoPageClose",
            value: function() {
                this.eventDispatcher.unsubscribe("event.videoPlayCheckpoint", this.onVideoCheckpoint),
                this.apiMap.tpat && this.apiMap.tpat("video.close")
            }
        },
        {
            key: "onEndcardView",
            value: function() {
                this.apiMap.tpat && this.apiMap.tpat("postroll.view")
            }
        },
        {
            key: "onDirectDownloadClick",
            value: function() {
                this.apiMap.tpat && this.apiMap.tpat("clickUrl"),
                this.apiMap.tpat && this.apiMap.tpat("postroll.click"),
                this.apiMap.gesture && this.apiMap.gesture("event", "download"),
                this.apiMap.eventValuePair && this.apiMap.eventValuePair("postroll.click", 1),
                this.apiMap.eventValuePair && this.apiMap.eventValuePair("download", 1)
            }
        },
        {
            key: "onDownloadButtonClick",
            value: function() {
                this.apiMap.tpat && this.apiMap.tpat("clickUrl"),
                this.apiMap.tpat && this.apiMap.tpat("postroll.click"),
                this.apiMap.gesture && this.apiMap.gesture("event", "download")
            }
        },
        {
            key: "onSuccessfulViewAd",
            value: function(e) {
                Math.floor(100 * e.currentTime / e.duration) >= this.successfulViewAd && (this.successfulViewAdReached = !0, this.apiMap.eventValuePair && this.apiMap.eventValuePair("videoViewed", Math.floor(1e3 * e.currentTime)), this.apiMap.successfulViewAd && this.apiMap.successfulViewAd()),
                !0 === this.successfulViewAdReached && (this.eventDispatcher.unsubscribe("event.videoPlayTimeupdate", this.onSuccessfulViewAd), this.eventDispatcher.publish("event.successfulViewAdReached"))
            }
        },
        {
            key: "onVideoLength",
            value: function(e) {
                var t = e.duration;
                e.currentTime > 0 && t && "number" == typeof t && (this.apiMap.eventValuePair && this.apiMap.eventValuePair("videoLength", Math.floor(1e3 * t)), this.eventDispatcher.unsubscribe("event.videoPlayTimeupdate", this.onVideoLength))
            }
        }]) && Le(t.prototype, n),
        i && Le(t, i),
        e
    } (),
    Ne = n(0),
    Ve = n.n(Ne);
    function je(e) {
        return (je = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function ze(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    var Ue = function() {
        function e() { !
            function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, e),
            this.instrument = null,
            this.keyMap = {
                pointers: "p",
                changedPointers: "cP",
                pointerType: "pT",
                isFirst: "is1",
                isFinal: "isF",
                eventType: "eT",
                center: "c",
                timeStamp: "tS",
                deltaTime: "dT",
                angle: "a",
                distance: "d",
                deltaX: "dX",
                deltaY: "dY",
                offsetDirection: "oD",
                scale: "s",
                rotation: "r",
                velocity: "v",
                velocityX: "vX",
                velocityY: "vY",
                direction: "di",
                type: "t",
                webkitForce: "wkF",
                webkitRotationAngle: "wkRA",
                webkitRadiusY: "wkRY",
                webkitRadiusX: "wkRX",
                identifier: "i",
                pageY: "pY",
                pageX: "pX",
                screenY: "sY",
                screenX: "sX",
                clientY: "cY",
                clientX: "cX",
                x: "x",
                y: "y",
                overallVelocityX: "overallVelocityX",
                overallVelocityY: "overallVelocityY",
                overallVelocity: "overallVelocity",
                maxPointers: "maxPointers",
                tapCount: "tapCount"
            },
            this.eventDispatcher = u.instance
        }
        var t, n, i;
        return t = e,
        (n = [{
            key: "getInstrument",
            value: function(e) {
                return this.instrument || (this.instrument = new Ve.a(e), this.instrument.get("pinch").set({
                    enable: !0
                }), this.instrument.get("pan").set({
                    direction: Ve.a.DIRECTION_ALL,
                    threshold: 100
                })),
                this.instrument
            }
        },
        {
            key: "attach",
            value: function(e) {
                var t = this,
                n = function(e, i) {
                    var o, r = function(e) {
                        return this.keyMap[e] || e
                    }.bind(this),
                    s = [];
                    return e && Object.keys(e).forEach(function(a) {
                        t.keyMap[a] && (Array.isArray(e[a]) ? e[a].forEach(function(e, t) {
                            s.push(n(e, r(a) + "[" + t + "]."))
                        }) : "object" === je(e[a]) ? s.push(n(e[a], r(a) + ".")) : ("number" == typeof(o = e[a]) && o % 1 != 0 && (o = o.toFixed(2)), s.push((void 0 === i ? "": i) + r(a) + "=" + o)))
                    }),
                    s.join("&")
                }.bind(this);
                this.getInstrument(e).on("pan tap press pinch",
                function(e) {
                    var t = "",
                    i = e.target.closest("*[data-vgl-page]"),
                    o = (e.target.closest("*[data-vgl-gesture]") || e.target).getAttribute("data-vgl-gesture");
                    i && o && (4 === e.eventType || "press" === e.type) && (t = "f=" + (i.getAttribute("id") || "unknownPage") + "&tt=" + o + "&" + n(e), this.eventDispatcher.publish("event.gesture", t))
                }.bind(this))
            }
        }]) && ze(t.prototype, n),
        i && ze(t, i),
        e
    } ();
    function He(e, t, n) {
        return (He = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = We(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function Fe(e) {
        return (Fe = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function Ge(e, t) {
        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    function qe(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function Xe(e, t, n) {
        return t && qe(e.prototype, t),
        n && qe(e, n),
        e
    }
    function Ye(e, t) {
        return ! t || "object" !== Fe(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function We(e) {
        return (We = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Ke(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                writable: !0,
                configurable: !0
            }
        }),
        t && $e(e, t)
    }
    function $e(e, t) {
        return ($e = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var Ze = function(e) {
        function t() {
            var e;
            return Ge(this, t),
            (e = Ye(this, We(t).call(this))).platform = null,
            e
        }
        return Ke(t, _),
        Xe(t, [{
            key: "init",
            value: function() {
                if (!this.initialized) {
                    var e = Je; - 1 !== ["ios"].indexOf(this.os) ? e = tt: -1 !== ["windows"].indexOf(this.os) ? e = et: -1 !== ["android"].indexOf(this.os) && (e = Qe),
                    (this.platform = new e).init(),
                    this.initialized = !0
                }
            }
        }]),
        t
    } (),
    Je = function(e) {
        function t() {
            var e;
            return Ge(this, t),
            (e = Ye(this, We(t).call(this))).initialized = !1,
            e
        }
        return Ke(t, _),
        Xe(t, [{
            key: "prepare",
            value: function() {}
        },
        {
            key: "downloadButtonClick",
            value: function() {
                this.VungleMRAID.open(this.VungleCTA.uri)
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (this.initialized = !0)
            }
        }]),
        t
    } (),
    Qe = function(e) {
        function t() {
            var e;
            return Ge(this, t),
            (e = Ye(this, We(t).call(this))).isIncentivizedAd = e.VungleMRAIDExt.getIncentivized(),
            e.initialized = !1,
            e
        }
        return Ke(t, Je),
        Xe(t, [{
            key: "downloadButtonClick",
            value: function() {
                this.VungleMRAID.open(this.VungleCTA.uri),
                this.VungleMRAIDVersion || u.instance.publish("event.adUnitClose")
            }
        },
        {
            key: "prepare",
            value: function(e) {
                this.isIncentivizedAd && !this.VungleMRAIDVersion && ( - 1 === ["VideoView", "DIView"].indexOf(e.clazz) ? -1 !== ["EndcardView"].indexOf(e.clazz) && (oe.DownloadButton.IncentivizedTimeout = "dismissed") : oe.DownloadButton.IncentivizedTimeout = null)
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (He(We(t.prototype), "init", this).call(this), this.initialized = !0)
            }
        }]),
        t
    } (),
    et = function(e) {
        function t() {
            var e;
            return Ge(this, t),
            (e = Ye(this, We(t).call(this))).initialized = !1,
            e.accessibility = new xe,
            e
        }
        return Ke(t, Je),
        Xe(t, [{
            key: "init",
            value: function() {
                this.initialized || (He(We(t.prototype), "init", this).call(this), this.accessibility.init(), this.initialized = !0)
            }
        }]),
        t
    } (),
    tt = function(e) {
        function t() {
            var e;
            return Ge(this, t),
            (e = Ye(this, We(t).call(this))).isIncentivizedAd = e.VungleMRAIDExt.getIncentivized(),
            e.initialized = !1,
            e.isStoreViewPrepared = !1,
            e.storeViewTypes = ["unknown", "fullscreen"],
            e.placementType = e.VungleMRAID.getPlacementType().trim().toLowerCase(),
            e
        }
        return Ke(t, Je),
        Xe(t, [{
            key: "prepare",
            value: function(e) {
                this.isIncentivizedAd && !this.VungleMRAIDVersion && ( - 1 === ["VideoView", "DIView"].indexOf(e.clazz) ? -1 !== ["EndcardView"].indexOf(e.clazz) && (oe.DownloadButton.IncentivizedTimeout = "dismissed") : oe.DownloadButton.IncentivizedTimeout = null)
            }
        },
        {
            key: "addMRAIDEventListeners",
            value: function() {
                this.DynamicElement.addEventListener("vungle.events.preparestore.finished", this.onNotifyPresentStoreViewFinished.bind(this)),
                this.DynamicElement.addEventListener("vungle.events.preparestore.success", this.onNotifyPrepareStoreViewSuccess.bind(this))
            }
        },
        {
            key: "onNotifyPrepareStoreViewSuccess",
            value: function() {
                this.isStoreViewPrepared = !0
            }
        },
        {
            key: "onNotifyPresentStoreViewFinished",
            value: function() {
                this.isStoreViewPrepared = !1,
                this.VungleCTA.appStoreId && -1 !== this.storeViewTypes.indexOf(this.placementType) && this.prepareStoreView(this.VungleCTA.appStoreId)
            }
        },
        {
            key: "prepareStoreView",
            value: function(e) {
                this.VungleMRAIDExt.prepareStoreView(e)
            }
        },
        {
            key: "downloadButtonClick",
            value: function() {
                var e = this.VungleCTA.uri,
                t = this.VungleCTA.appStoreId;
                this.VungleMRAIDVersion && t && this.isStoreViewPrepared ? this.VungleMRAIDExt.presentStoreView(t) : this.VungleMRAID.open(e),
                !this.VungleMRAIDVersion && t && this.isStoreViewPrepared && (oe.DownloadButton.HardHide = "deny", u.instance.publish("event.hardHideDownloadButton"), this.isIncentivizedAd || u.instance.publish("event.adUnitClose"))
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (He(We(t.prototype), "init", this).call(this), this.addMRAIDEventListeners(), this.VungleMRAIDVersion && this.onNotifyPresentStoreViewFinished(), this.initialized = !0)
            }
        }]),
        t
    } ();
    function nt(e, t) {
        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    function it(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function ot(e, t, n) {
        return t && it(e.prototype, t),
        n && it(e, n),
        e
    }
    var rt = function() {
        function e(t) {
            nt(this, e),
            t = t || {
                fallbackLng: "en",
                resources: {}
            },
            this.lng = (t.language || navigator.language || navigator.userLanguage).replace("-", "_"),
            this.fallbackLng = t.fallbackLng,
            this.resources = t.resources,
            this.locale = t.locale || this.lng
        }
        return ot(e, [{
            key: "transform",
            value: function(e, t) {
                return this[t] && this[t][e] ? this[t][e] : this.resources[this.fallbackLng] && this.resources[this.fallbackLng][t][e] ? this.resources[this.fallbackLng][t][e] : e
            }
        },
        {
            key: "t",
            value: function(e) {
                return this.transform(e, "translation")
            }
        },
        {
            key: "s",
            value: function(e) {
                return this.transform(e, "styling")
            }
        },
        {
            key: "translation",
            get: function() {
                if (this.resources[this.lng] && this.resources[this.lng].translation) return this.resources[this.lng].translation;
                try {
                    var e = this.lng.split("_")[0];
                    return this.resources[e] && this.resources[e].translation ? this.resources[e].translation: this.resources[this.fallbackLng].translation
                } catch(e) {
                    return null
                }
            }
        },
        {
            key: "styling",
            get: function() {
                if (this.resources[this.locale] && this.resources[this.locale].styling) return this.resources[this.locale].styling;
                try {
                    var e = this.locale.split("_")[0];
                    return this.resources[e] && this.resources[e].styling ? this.resources[e].styling: this.resources[this.fallbackLng].styling
                } catch(e) {
                    return null
                }
            }
        }]),
        e
    } (),
    st = function() {
        function e() {
            nt(this, e)
        }
        return ot(e, null, [{
            key: "createView",
            value: function(e, t) {
                return e(t)
            }
        }]),
        e
    } ();
    Handlebars.registerHelper("equalDef",
    function(e, t, n, i) {
        if (arguments.length < 4) throw new Error("Handlebars Helper equal needs 3 parameters");
        return void 0 === e && (e = n),
        e !== t ? i.inverse(this) : i.fn(this)
    }),
    Handlebars.registerHelper("equal",
    function(e, t, n) {
        if (arguments.length < 3) throw new Error("Handlebars Helper equal needs 2 parameters");
        return e !== t ? n.inverse(this) : n.fn(this)
    }),
    Handlebars.registerHelper("i18nt",
    function(e, t) {
        window.vungle.i18n || (window.vungle.i18n = new rt(window.vungle.i18nData));
        var n = window.vungle.i18n.t(t || e);
        return new Handlebars.SafeString(n === e ? t: n)
    }),
    Handlebars.registerHelper("i18ns",
    function(e, t) {
        window.vungle.i18n || (window.vungle.i18n = new rt(window.vungle.i18nData));
        var n = window.vungle.i18n.s(t || e);
        return new Handlebars.SafeString(n === e ? t: n)
    });
    var at = st,
    lt = (n(13), n(2)),
    ct = n.n(lt);
    function ut(e) {
        return (ut = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function ht(e) {
        return function(e) {
            if (Array.isArray(e)) {
                for (var t = 0,
                n = new Array(e.length); t < e.length; t++) n[t] = e[t];
                return n
            }
        } (e) ||
        function(e) {
            if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
        } (e) ||
        function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        } ()
    }
    function dt(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function pt(e, t) {
        return ! t || "object" !== ut(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function ft(e) {
        return (ft = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function vt(e, t) {
        return (vt = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var yt = function(e) {
        function t(e) {
            var n, i = e.pages,
            o = e.components,
            r = e.controllers,
            s = e.config;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = pt(this, ft(t).call(this))).initialized = !1,
            n.config = s || {
                checkConsent: !0
            },
            n.pageIndex = 0,
            n.pageControllers = [],
            n.adTracker = new Me,
            n.gestureTracker = new Ue,
            n.device = new Ze,
            n.pages = i,
            n.components = ["DialogBox", "GDPRDialogBox"].concat(ht(o || [])),
            n.controllers = r,
            n.addInitialEventListener(),
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && vt(e, t)
        } (t, L),
        n = t,
        (i = [{
            key: "showSpinner",
            value: function(e) {
                document.querySelector("#spinner").style.display = e ? "block": "none"
            }
        },
        {
            key: "addInitialEventListener",
            value: function() {
                this.onInitialViewportChange = this.onInitialViewportChange.bind(this),
                window.addEventListener("resize", this.onInitialViewportChange, !1)
            }
        },
        {
            key: "addEventListeners",
            value: function() {
                window.addEventListener("resize", this.onViewportChange.bind(this), !1)
            }
        },
        {
            key: "addMRAIDEventListeners",
            value: function() {
                this.VungleMRAID.addEventListener("viewableChange", this.onAdViewableChange.bind(this)),
                this.DynamicElement.addEventListener("vungle.events.request.close", this.onRequestCloseAd.bind(this)),
                this.DynamicElement.addEventListener("vungle.events.installationStatus.updated", this.onInstallationStatusUpdate.bind(this))
            }
        },
        {
            key: "subscribeToEvents",
            value: function() {
                u.instance.subscribe("event.videoMetadataAvailable", this.onViewportChange.uuidBind(this)),
                u.instance.subscribe("event.adUnitClose", this.onAdUnitClose.uuidBind(this)),
                u.instance.subscribe("event.privacyButtonClick", this.onPrivacyButtonClick.uuidBind(this)),
                u.instance.subscribe("event.dismissPage", this.onDismissPage.uuidBind(this)),
                u.instance.subscribe("event.dismissIncentivizedAdPage", this.onDismissIncentivizedAdPage.uuidBind(this)),
                u.instance.subscribe("event.downloadButtonClick", this.onDownloadButtonClick.uuidBind(this)),
                u.instance.subscribe("event.installButtonClick", this.onInstallButtonClick.uuidBind(this)),
                u.instance.subscribe("event.openButtonClick", this.onOpenButtonClick.uuidBind(this)),
                u.instance.subscribe("event.cancelDownloadButtonClick", this.onCancelDownloadButtonClick.uuidBind(this)),
                u.instance.subscribe("event.gesture", this.onGesture.uuidBind(this)),
                u.instance.subscribe("event.gdprConsent", this.onGDPRConsent.uuidBind(this))
            }
        },
        {
            key: "initializeAdTracker",
            value: function() {
                this.adTracker.init({
                    tpat: this.VungleMRAIDBridgeExt.notifyTPAT,
                    gesture: this.VungleMRAIDBridgeExt.notifyUserInteraction,
                    eventValuePair: this.VungleMRAIDBridgeExt.notifyEventValuePairEvent,
                    successfulViewAd: this.VungleMRAIDBridgeExt.notifySuccessfulViewAd
                })
            }
        },
        {
            key: "setHtml",
            value: function(e) {
                this.DynamicElement.innerHTML = function() {
                    for (var t, n = this.pages.concat(this.components), i = "", o = 0, r = n.length; o < r; o++) t = window.vungle.templates[n[o]].template,
                    i += at.createView(t, e);
                    return i
                }.bind(this)()
            }
        },
        {
            key: "createPageControllers",
            value: function() {
                for (var e, t = 0,
                n = this.pages.length; t < n; t++) e = new this.controllers[this.pages[t]]({
                    selector: "#" + this.pages[t],
                    name: this.pages[t],
                    number: t,
                    isIncentivized: this.isIncentivizedAd
                }),
                this.pageControllers.push(e)
            }
        },
        {
            key: "showAd",
            value: function() {
                this.isConsentRequired() && this.config.checkConsent ? this.showGDPR() : this.showPage(this.pageIndex)
            }
        },
        {
            key: "getPage",
            value: function(e) {
                return this.pageControllers[e]
            }
        },
        {
            key: "showPage",
            value: function(e) {
                var t = this.getPage(e);
                this.device.platform.prepare(t),
                t.init(),
                t.show()
            }
        },
        {
            key: "hidePage",
            value: function(e) {
                var t = this.getPage(e);
                t.init(),
                t.hide()
            }
        },
        {
            key: "navigate",
            value: function() {
                var e = this;
                this.hidePage(this.pageIndex),
                -1 !== ["VideoView", "DIView"].indexOf(this.currentPage.clazz) && u.instance.publish("event.videoPageClose"),
                setTimeout(function() {
                    if (e.pageControllers.length > 1 && e.pageIndex + 1 < e.pageControllers.length) return e.pageIndex += 1,
                    void e.showPage(e.pageIndex);
                    e.closeAdUnit()
                })
            }
        },
        {
            key: "closeAdUnit",
            value: function() {
                window.vungle.flexFeed || this.VungleMRAID.close()
            }
        },
        {
            key: "showGDPR",
            value: function() {
                this.currentPage.getGDPRDialogBoxObject().init(),
                this.currentPage.getGDPRDialogBoxObject().show()
            }
        },
        {
            key: "adUnitVisible",
            value: function() {
                document.querySelector("#dynamic").className = [document.querySelector("#dynamic").className, this.os, this.osVersion].join(" ").trim(),
                this.showSpinner(!1)
            }
        },
        {
            key: "onAdUnitClose",
            value: function() {
                this.closeAdUnit()
            }
        },
        {
            key: "onRequestCloseAd",
            value: function() {
                this.VungleMRAIDBridgeExt.getIsVungleAd() && u.instance.publish("event.requestToCloseAd")
            }
        },
        {
            key: "onInstallationStatusUpdate",
            value: function(e) {
                u.instance.publish("event.installationStatusUpdate", e.detail)
            }
        },
        {
            key: "onAdViewableChange",
            value: function() {
                u.instance.publish("event.adViewableChanged", this.VungleMRAID.isViewable() ? "maximized": "minimized")
            }
        },
        {
            key: "onInitialViewportChange",
            value: function() {
                var e = G.getViewportSize(); ! this.initialized && e.height > 1 && (this.initialized = !0, this.startAd(), window.removeEventListener("resize", this.onInitialViewportChange))
            }
        },
        {
            key: "onViewportChange",
            value: function() {
                var e = G.getViewportSize();
                u.instance.publish("event.viewportChange", e)
            }
        },
        {
            key: "onGesture",
            value: function(e) {
                this.VungleMRAIDBridgeExt.notifyUserInteraction("event", e)
            }
        },
        {
            key: "adMRAIDReady",
            value: function() {
                var e = this.VungleMRAIDBridgeExt.getReplacementTokens();
                "false" === (e.AUTO_LOCALIZE || "true") && (window.vungle.i18nData = null),
                this.isIncentivizedAd = this.VungleMRAIDExt.getIncentivized(),
                this.setHtml(e),
                this.createPageControllers(),
                "true" === (e.ACTION_TRACKING || "false") && this.gestureTracker.attach(this.DynamicElement),
                this.device.init()
            }
        },
        {
            key: "onPrivacyButtonClick",
            value: function(e) {
                this.openPrivacyURI(e)
            }
        },
        {
            key: "onDismissIncentivizedAdPage",
            value: function() {
                this.navigate()
            }
        },
        {
            key: "onDismissPage",
            value: function() {
                if ( - 1 !== ["VideoView", "DIView"].indexOf(this.currentPage.clazz) && this.isIncentivizedAd && !this.adTracker.successfulViewAdReached) return u.instance.publish("event.videoViewDismissPage");
                this.navigate()
            }
        },
        {
            key: "onDownloadButtonClick",
            value: function() {
                this.device.platform.downloadButtonClick()
            }
        },
        {
            key: "onInstallButtonClick",
            value: function() {
                this.VungleMRAIDBridgeExt.startDownloadAppOnDevice()
            }
        },
        {
            key: "onCancelDownloadButtonClick",
            value: function() {
                this.VungleMRAIDBridgeExt.cancelDownload()
            }
        },
        {
            key: "onOpenButtonClick",
            value: function() {
                this.VungleMRAIDBridgeExt.openAppInDevice()
            }
        },
        {
            key: "onGDPRConsent",
            value: function() {
                this.showPage(this.pageIndex)
            }
        },
        {
            key: "startAd",
            value: function() {
                var e = this;
                ct.a.attach(document.body),
                this.addEventListeners(),
                this.initializeAdTracker(),
                this.addMRAIDEventListeners(),
                this.subscribeToEvents(),
                this.showSpinner(!0),
                this.mraidReadyCheck(function() {
                    e.adMRAIDReady(),
                    e.adUnitVisible(),
                    e.showAd()
                })
            }
        },
        {
            key: "init",
            value: function() {
                var e = document.createEvent("HTMLEvents");
                e.initEvent("resize", !0, !1),
                window.dispatchEvent(e)
            }
        },
        {
            key: "currentPage",
            get: function() {
                return this.getPage(this.pageIndex)
            }
        }]) && dt(n.prototype, i),
        o && dt(n, o),
        t
    } ();
    function gt(e) {
        return (gt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function mt(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function bt(e) {
        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e
    }
    function Et(e, t, n) {
        return (Et = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = wt(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function wt(e) {
        return (wt = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Tt(e, t) {
        return (Tt = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var Ct = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.name,
            r = e.number,
            s = e.isIncentivized,
            a = void 0 !== s && s;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = function(e, t) {
                return ! t || "object" !== gt(t) && "function" != typeof t ? bt(e) : t
            } (this, wt(t).call(this, {
                selector: i,
                name: o,
                number: r,
                isIncentivized: a
            }))).muteIconContainer = null,
            n.progressBar = null,
            n.video = null,
            n.videoContainer = null,
            n.videoPlayerObject = null,
            n.ctaButtonObject = null,
            n.incentivizedDialogBoxObject = null,
            n.incentivizedTitleText = document.getElementById("incentivized-title-text").innerHTML,
            n.incentivizedBodyText = document.getElementById("incentivized-body-text").innerHTML,
            n.incentivizedPrimaryText = document.getElementById("incentivized-primary-text").innerHTML,
            n.incentivizedSecondaryText = document.getElementById("incentivized-secondary-text").innerHTML,
            n.onLoadMetaData = n.onLoadMetaData.bind(bt(n)),
            n.getVideoPlayerObject().getElement().addEventListener("loadedmetadata", n.onLoadMetaData),
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && Tt(e, t)
        } (t, _e),
        n = t,
        (i = [{
            key: "onLoadMetaData",
            value: function() {
                this.pauseVideo(),
                this.getVideoPlayerObject().muteUnmute(!0),
                this.getVideoPlayerObject().getElement().removeEventListener("loadedmetadata", this.onLoadMetaData)
            }
        },
        {
            key: "getMuteIconContainer",
            value: function() {
                return this.muteIconContainer || (this.muteIconContainer = document.querySelector("#" + this.viewName + " .mute-icon-container")),
                this.muteIconContainer
            }
        },
        {
            key: "getProgressBar",
            value: function() {
                return this.progressBar || (this.progressBar = document.querySelector("#" + this.viewName + " .progress-bar")),
                this.progressBar
            }
        },
        {
            key: "getVideo",
            value: function() {
                return this.video || (this.video = document.querySelector("#" + this.viewName + " video")),
                this.video
            }
        },
        {
            key: "getVideoContainer",
            value: function() {
                return this.videoContainer || (this.videoContainer = document.querySelector("#" + this.viewName + " .video-container")),
                this.videoContainer
            }
        },
        {
            key: "getVideoPlayerObject",
            value: function() {
                return this.videoPlayerObject || (this.videoPlayerObject = new $("#" + this.viewName + " video")),
                this.videoPlayerObject
            }
        },
        {
            key: "getIncentivizedDialogBoxObject",
            value: function() {
                return this.incentivizedDialogBoxObject || (this.incentivizedDialogBoxObject = new I({
                    selector: this.dialogboxSelector,
                    themeColor: this.getCTABackgroundColor(),
                    titleText: this.incentivizedTitleText,
                    bodyText: this.incentivizedBodyText,
                    primaryText: this.incentivizedPrimaryText,
                    secondaryText: this.incentivizedSecondaryText,
                    primaryEvent: "event.dialogBoxPrimaryButtonClick",
                    secondaryEvent: "event.incentivizedDialogBoxSecondaryButtonClick"
                })),
                this.incentivizedDialogBoxObject
            }
        },
        {
            key: "onVideoLoadedMetadata",
            value: function(e) {
                this.videoRatio = e.width / e.height
            }
        },
        {
            key: "onViewportChange",
            value: function() {}
        },
        {
            key: "onAdViewableChanged",
            value: function(e) {
                "minimized" !== e ? this.getIncentivizedDialogBoxObject().isVisible() || this.getGDPRDialogBoxObject().isVisible() || this.playVideo() : this.pauseVideo()
            }
        },
        {
            key: "onAlertPrivacy",
            value: function() {
                this.pauseVideo(),
                this.getPrivacyDialogBoxObject().show()
            }
        },
        {
            key: "onVideoViewDismissPage",
            value: function() {
                this.getIncentivizedDialogBoxObject().isVisible() ? this.eventDispatcher.publish("event.dismissIncentivizedAdPage") : (this.pauseVideo(), this.getIncentivizedDialogBoxObject().show())
            }
        },
        {
            key: "onRequestToCloseAd",
            value: function() {
                this.getCloseButtonObject().isVisible() && (this.getGDPRDialogBoxObject().isVisible() ? this.pauseVideo() : this.getIncentivizedDialogBoxObject().isVisible() ? (this.getIncentivizedDialogBoxObject().hide(), this.playVideo()) : this.eventDispatcher.publish("event.dismissPage"))
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (Et(wt(t.prototype), "init", this).call(this), this.eventDispatcher.subscribe("event.requestToCloseAd", this.onRequestToCloseAd.uuidBind(this)), this.eventDispatcher.subscribe("event.adViewableChanged", this.onAdViewableChanged.uuidBind(this)), this.eventDispatcher.subscribe("event.videoViewDismissPage", this.onVideoViewDismissPage.uuidBind(this)), this.initialized = !0)
            }
        },
        {
            key: "show",
            value: function() {
                var e = this;
                this.getMuteIconContainer().style.opacity = 0,
                Et(wt(t.prototype), "show", this).call(this),
                setTimeout(function() {
                    e.getMuteIconContainer().style.opacity = ""
                })
            }
        },
        {
            key: "hide",
            value: function() {
                this.getVideoPlayerObject().destroy(),
                Et(wt(t.prototype), "hide", this).call(this)
            }
        },
        {
            key: "pauseVideo",
            value: function() {
                this.getVideoPlayerObject().pause()
            }
        },
        {
            key: "playVideo",
            value: function() {
                this.getVideoPlayerObject().play()
            }
        },
        {
            key: "clazz",
            get: function() {
                return "VideoView"
            }
        }]) && mt(n.prototype, i),
        o && mt(n, o),
        t
    } ();
    function Ot(e) {
        return (Ot = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function It(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function kt(e, t) {
        return ! t || "object" !== Ot(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function At(e, t, n) {
        return (At = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = xt(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function xt(e) {
        return (xt = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Dt(e, t) {
        return (Dt = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var Bt = function(e) {
        function t(e) {
            var n = e.selector,
            i = e.name,
            o = e.number,
            r = e.isIncentivized,
            s = void 0 !== r && r;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            kt(this, xt(t).call(this, {
                selector: n,
                name: i,
                number: o,
                isIncentivized: s
            }))
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && Dt(e, t)
        } (t, _e),
        n = t,
        (i = [{
            key: "onRequestToCloseAd",
            value: function() {
                this.getCloseButtonObject().isVisible() && this.eventDispatcher.publish("event.dismissPage")
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (At(xt(t.prototype), "init", this).call(this), this.eventDispatcher.subscribe("event.requestToCloseAd", this.onRequestToCloseAd.uuidBind(this)), this.initialized = !0)
            }
        },
        {
            key: "clazz",
            get: function() {
                return "EndcardView"
            }
        }]) && It(n.prototype, i),
        o && It(n, o),
        t
    } ();
    n(14),
    n(15);
    function St(e) {
        return (St = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function Rt(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function Pt(e, t) {
        return ! t || "object" !== St(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function _t(e, t, n) {
        return (_t = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = Lt(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function Lt(e) {
        return (Lt = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Mt(e, t) {
        return (Mt = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    var Nt = function(e) {
        function t(e) {
            var n, i = e.selector,
            o = e.name,
            r = e.number,
            s = e.isIncentivized,
            a = void 0 !== s && s;
            return function(e, t) {
                if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
            } (this, t),
            (n = Pt(this, Lt(t).call(this, {
                selector: i,
                name: o,
                number: r,
                isIncentivized: a
            }))).footer = null,
            n.content = null,
            n.header = null,
            n.videoRatio = null,
            n.ctaButtonObject = null,
            n
        }
        var n, i, o;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            t && Mt(e, t)
        } (t, Ct),
        n = t,
        (i = [{
            key: "getHeader",
            value: function() {
                return this.header || (this.header = document.querySelector("#" + this.viewName + " .header")),
                this.header
            }
        },
        {
            key: "getContent",
            value: function() {
                return this.content || (this.content = document.querySelector("#" + this.viewName + " .content")),
                this.content
            }
        },
        {
            key: "getCTAButtonObject",
            value: function() {
                return this.ctaButtonObject || (this.ctaButtonObject = new ve({
                    selector: "#" + this.viewName + " .download",
                    isIncentivized: this.isIncentivizedAd
                })),
                this.ctaButtonObject
            }
        },
        {
            key: "getPrivacyDialogBoxObject",
            value: function() {
                return this.privacyDialogBoxObject || (this.privacyDialogBoxObject = new I({
                    selector: this.dialogboxSelector,
                    themeColor: this.getCTABackgroundColor(),
                    bodyText: this.privacyBodyText,
                    primaryText: this.privacyPrimaryText,
                    secondaryText: this.privacySecondaryText,
                    primaryEvent: "event.dialogBoxPrimaryButtonClick",
                    secondaryEvent: "event.privacyDialogBoxSecondaryButtonClick"
                })),
                this.privacyDialogBoxObject
            }
        },
        {
            key: "init",
            value: function() {
                this.initialized || (_t(Lt(t.prototype), "init", this).call(this), this.eventDispatcher.subscribe("event.videoPlayComplete", this.onVideoPlayComplete.uuidBind(this)), this.eventDispatcher.subscribe("event.closeButtonClick", this.onCloseButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.incentivizedDialogBoxSecondaryButtonClick", this.onIncentivizedDialogBoxSecondaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.privacyDialogBoxSecondaryButtonClick", this.onPrivacyDialogBoxSecondaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.dialogBoxPrimaryButtonClick", this.onDialogBoxPrimaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.viewportChange", this.onViewportChange.uuidBind(this)), this.getFullCTAObject().init(), this.getCloseButtonObject().init(), this.getCTAButtonObject().init(), this.getGDPRDialogBoxObject().init(), this.getPrivacyButtonObject().init(), this.getVideoPlayerObject().init(), this.getIncentivizedDialogBoxObject().init(), this.getPrivacyDialogBoxObject().init(), this.initialized = !0)
            }
        },
        {
            key: "show",
            value: function() {
                _t(Lt(t.prototype), "show", this).call(this),
                this.getFullCTAObject().show(),
                this.getVideoPlayerObject().show(),
                this.getCloseButtonObject().show(),
                this.getCTAButtonObject().show(),
                this.getPrivacyButtonObject().show()
            }
        },
        {
            key: "hide",
            value: function() {
                var e = this;
                this.getVideoPlayerObject().pause(),
                setTimeout(function() {
                    _t(Lt(t.prototype), "hide", e).call(e)
                },
                100)
            }
        },
        {
            key: "onVideoPlayComplete",
            value: function() {
                this.eventDispatcher.publish("event.dismissPage")
            }
        }]) && Rt(n.prototype, i),
        o && Rt(n, o),
        t
    } ();
    n(16),
    n(17);
    function Vt(e) {
        return (Vt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e
        }: function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
        })(e)
    }
    function jt(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1,
            i.configurable = !0,
            "value" in i && (i.writable = !0),
            Object.defineProperty(e, i.key, i)
        }
    }
    function zt(e, t) {
        return ! t || "object" !== Vt(t) && "function" != typeof t ?
        function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        } (e) : t
    }
    function Ut(e, t, n) {
        return (Ut = "undefined" != typeof Reflect && Reflect.get ? Reflect.get: function(e, t, n) {
            var i = function(e, t) {
                for (; ! Object.prototype.hasOwnProperty.call(e, t) && null !== (e = Ht(e)););
                return e
            } (e, t);
            if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value
            }
        })(e, t, n || e)
    }
    function Ht(e) {
        return (Ht = Object.setPrototypeOf ? Object.getPrototypeOf: function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }
    function Ft(e, t) {
        return (Ft = Object.setPrototypeOf ||
        function(e, t) {
            return e.__proto__ = t,
            e
        })(e, t)
    }
    new yt({
        pages: ["Video", "ShowcaseNonBrand"],
        components: ["CloseIcons", "SoundIcons", "PrivacyIcons", "DownloadIcons"],
        controllers: {
            Video: Nt,
            ShowcaseNonBrand: function(e) {
                function t(e) {
                    var n, i = e.selector,
                    o = e.name,
                    r = e.number,
                    s = e.isIncentivized,
                    a = void 0 !== s && s;
                    return function(e, t) {
                        if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    } (this, t),
                    (n = zt(this, Ht(t).call(this, {
                        selector: i,
                        name: o,
                        number: r,
                        isIncentivized: a
                    }))).cardContainer = null,
                    n.slideshowImages = null,
                    n.slideshowImageCounter = 1,
                    n.ctaAppIconObject = null,
                    n
                }
                var n, i, o;
                return function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }),
                    t && Ft(e, t)
                } (t, Bt),
                n = t,
                (i = [{
                    key: "getCTAAppIconObject",
                    value: function() {
                        return this.ctaAppIconObject || (this.ctaAppIconObject = new ve({
                            selector: "#" + this.viewName + " .app-icon",
                            isIncentivized: this.isIncentivizedAd
                        })),
                        this.ctaAppIconObject
                    }
                },
                {
                    key: "getCardContainer",
                    value: function() {
                        return this.cardContainer || (this.cardContainer = document.querySelector("#" + this.viewName + " .card-container")),
                        this.cardContainer
                    }
                },
                {
                    key: "getSlideshowImages",
                    value: function() {
                        return this.slideshowImages || (this.slideshowImages = document.querySelectorAll("#" + this.viewName + " .slideshowImages")),
                        this.slideshowImages
                    }
                },
                {
                    key: "getPrivacyDialogBoxObject",
                    value: function() {
                        return this.privacyDialogBoxObject || (this.privacyDialogBoxObject = new I({
                            selector: this.dialogboxSelector,
                            themeColor: this.getCTABackgroundColor(),
                            bodyText: this.privacyBodyText,
                            primaryText: this.privacyPrimaryText,
                            secondaryText: this.privacySecondaryText,
                            primaryEvent: "event.dialogBoxPrimaryButtonClick",
                            secondaryEvent: "event.privacyDialogBoxSecondaryButtonClick"
                        })),
                        this.privacyDialogBoxObject
                    }
                },
                {
                    key: "init",
                    value: function() {
                        this.initialized || (Ut(Ht(t.prototype), "init", this).call(this), this.eventDispatcher.subscribe("event.closeButtonClick", this.onCloseButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.incentivizedDialogBoxSecondaryButtonClick", this.onIncentivizedDialogBoxSecondaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.privacyDialogBoxSecondaryButtonClick", this.onPrivacyDialogBoxSecondaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.dialogBoxPrimaryButtonClick", this.onDialogBoxPrimaryButtonClick.uuidBind(this)), this.eventDispatcher.subscribe("event.viewportChange", this.onViewportChange.uuidBind(this)), this.getFullCTAObject().init(), this.getCTAButtonObject().init(), this.getCloseButtonObject().init(), this.getPrivacyButtonObject().init(), this.getCTAAppIconObject().init(), this.getPrivacyDialogBoxObject().init(), this.initialized = !0)
                    }
                },
                {
                    key: "show",
                    value: function() {
                        Ut(Ht(t.prototype), "show", this).call(this),
                        this.eventDispatcher.publish("event.endcardView"),
                        this.getFullCTAObject().show(),
                        this.getCloseButtonObject().show(),
                        this.getCTAButtonObject().show(),
                        this.getPrivacyButtonObject().show(),
                        this.imageSlideshow()
                    }
                },
                {
                    key: "imageSlideshow",
                    value: function() {
                        var e = this.getSlideshowImages();
                        window.setInterval(this.kenBurns.bind(this, e), 4e3),
                        e[0].setAttribute("class", G.elementAddClass(e[0].className, "showcase"))
                    }
                },
                {
                    key: "kenBurns",
                    value: function(e) {
                        var t = e.length;
                        this.slideshowImageCounter === t && (this.slideshowImageCounter = 0),
                        e[this.slideshowImageCounter].setAttribute("class", G.elementAddClass(e[this.slideshowImageCounter].className, "showcase")),
                        0 === this.slideshowImageCounter ? e[t - 2].setAttribute("class", G.elementRemoveClass(e[t - 2].className, "showcase")) : 1 === this.slideshowImageCounter ? e[t - 1].setAttribute("class", G.elementRemoveClass(e[t - 1].className, "showcase")) : e[this.slideshowImageCounter - 2].setAttribute("class", G.elementRemoveClass(e[this.slideshowImageCounter - 2].className, "showcase")),
                        this.slideshowImageCounter++
                    }
                }]) && jt(n.prototype, i),
                o && jt(n, o),
                t
            } ()
        }
    }).init()
}]);